<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Moneycontrol : Page not found</title>
</head>
<!-- Moneycontrol Common header -> Start -->
		<script type="text/javascript">
			var max_limit_interstitial_page_check = 8;
			var interstitial_page_position = [1, 3, 5, 7];
						function getCurrentDate() {

				var d = new Date();
				var month = d.getMonth()+1;
				var date = d.getDate();

				if( month <= 9 ) { month = '0' + month; }
				if( date <= 9 ) { date = '0' + date; }
				return d.getFullYear() + '' + month + '' + date;
			}
			function getInterstitialCookie( cname ) {
				var name = cname + "=";
				var ca = document.cookie.split(';');
				for( var i = 0; i < ca.length; i++ ) {
					var c = ca[i];
					while( c.charAt(0) == ' ' ) { c = c.substring( 1 ); }
					if( c.indexOf( name ) == 0 ) { return c.substring( name.length, c.length ); }
				}
				return "";
			}
			function createInterstitialCookie( name, value, days ) {
				var expires="";
				if( days ) {
					var date = new Date();
					date.setTime(date.getTime()+(days*24*60*60*1000));
					expires = "; expires="+date.toGMTString();
				} else { 
					expires = ""; 
				}
				document.cookie = name+"="+value+expires+"; path=/; domain=.moneycontrol.com;";
			}
			function initializeInterstitial() {

				var is_mc_wap_interstitial = '1';
				var width = window.innerWidth || document.documentElement.clientWidth;
				var mcpro = getInterstitialCookie( 'mcpro' );

				if( mcpro == '1' ) { is_mc_wap_interstitial = '0'; }

				/* Runs Only for WAP */
				if( width <= 768 && is_mc_wap_interstitial == '1' ) {
					var current_page = window.location.href;
					var interstitial_cookie_name = 'MC_WAP_INTERSTITIAL_NEW_LOGIC_' + getCurrentDate();
					var interstitial_cookie_object = getInterstitialCookie( interstitial_cookie_name );	/* Get Cookie Value */

					/* Checks for Cookie is exists OR not? */
					if( interstitial_cookie_object == undefined || interstitial_cookie_object == '' ) {
						interstitial_cookie_value = {};
						interstitial_cookie_value[0] = current_page;
						createInterstitialCookie( interstitial_cookie_name, JSON.stringify( interstitial_cookie_value ), '1' );	/* Create Cookie */
											} else {
						var interstitial_cookie_value = JSON.parse( interstitial_cookie_object );
						var pageCount = Object.keys( interstitial_cookie_value ).length;

						if( pageCount <= max_limit_interstitial_page_check ) {

							var is_page_exists = false;
							for( var i = 0; i < pageCount; i++ ) {
								if( current_page === interstitial_cookie_value[ i ] ) { is_page_exists = true; }
							}

							if( is_page_exists == false ) {

								if( interstitial_page_position.includes( pageCount ) ) {
									interstitial_cookie_value[ pageCount ] = current_page;
									createInterstitialCookie( interstitial_cookie_name, JSON.stringify( interstitial_cookie_value ), '1' );	/* Update Cookie */
																			window.location.href = "https://www.moneycontrol.com/promo/mc_wap_interstitial_dfp.php";
																	} else {
									interstitial_cookie_value[ pageCount ] = current_page;
									createInterstitialCookie( interstitial_cookie_name, JSON.stringify( interstitial_cookie_value ), '1' );	/* Update Cookie */
																	}
							} else {
															}
						}
					}
				}
			}
			window.onload = initializeInterstitial();
		</script>
	<meta name='dailymotion-domain-verification' content='dmpn9sdnwtvex9ltc' />
<style>
.header_desktop,.header_desktop *{margin:0;padding:0;box-sizing:border-box}.header_desktop{background-color:#fff}.header_desktop a,.lang_link,.topnav a{text-decoration:none!important;outline:0}input{outline:0}img{max-width:100%;height:auto}.mc_menu_icon{float:left;padding-top:14px;padding-right:10px;margin-right:10px}.header_desktop .arrow{vertical-align:middle}li,ul{list-style:none}.PR{position:relative}.clearfix:after{content:".";display:block;height:0;clear:both;visibility:hidden}* html .clearfix{height:1%}.clearfix{display:block}.topnav{background-color:#f6f8fb;padding-bottom:1px}.login_after>a,.special_wrapbx a{color:#333;font:400 11px Lato,sans-serif}.user_after_login a, .user_before_login a {color: #333333;font: 11px 'Lato',sans-serif;}.dropdown-menu{display:none;background-clip:border-box!important}.header_desktop .dropdown-menu>li{border-bottom:1px solid #e9e9e9}.header_desktop .dropdown-menu>li>a{display:block;padding:10px;margin:0;font:13px Roboto,sans-serif;color:#333}.header_desktop .arrow,.lang_link{display:inline-block}.header_desktop .dropdown-menu>li>a:hover{background:#30659f;color:#fff;border:none}.header_desktop .dropdown-menu>li:last-child{border:none}.lan_dropbx{float:left;padding:10px 0}.special_wrapbx{float:left;margin-left:20px}.lang_link{font:400 11px Lato,sans-serif;color:#666!important}.main_header_wrapper{width:1260px; position: relative; margin:0 auto}.searchBox{width:424px;position:absolute;left:50%;top:2px;margin-left:-212px;border:1px solid #bababa;border-radius:17px;background-color:#fff;z-index:0;height:30px;z-index:999}.searchBox .searchboxInner{background:#fff;border:0;height:27px;margin:1px;border-radius:17px}.searchBox .searchboxInner .txtsrchbox{margin-top:0px;width:100%;border:0;outline:0;height:25px;border-radius:17px;padding:2px 30px 2px 15px;font:400 13px Lato,sans-serif}.common_dropmenu.dropdown-menu{margin:0;border-radius:0}.header_desktop .dropdown-menu{border:1px solid #e2e2e2;box-shadow:0 2px 5px rgba(0,0,0,.175)}.common_dropmenu:after,.common_dropmenu:before{bottom:100%;border:solid transparent;content:" ";height:0;width:0;position:absolute;pointer-events:none;left:20px}.header_desktop .arrow,.logo_wrapper{position:relative}.common_dropmenu:after{border-color:rgba(255,255,255,0);border-bottom-color:#fff;border-width:6px;margin-left:-6px}.common_dropmenu:before{border-color:rgba(209,211,214,0);border-bottom-color:#e2e2e2;border-width:8px;margin-left:-8px}.header_desktop .arrow{border:solid #707070;border-width:0 1px 1px 0;padding:2px;margin-left:3px;top:-2px; width: auto; height: auto; margin-bottom: 0px;}.header_desktop .arrow.down{transform:rotate(45deg);-webkit-transform:rotate(45deg)}.sept{height:12px;float:left;width:1px;background-color:#333;margin-top:13px}.speacial_dropbx{padding:10px 20px 10px 0;float:left}.expert_link{padding:10px 5px;float:left}.appbanner_drop .dropdown-menu,.speacial_dropbx .dropdown-menu{left:-100px !important;width:1000px;padding:15px}.lan_dropbx .dropdown-menu{ left:0px !important;}.appbanner_drop .dropdown-menu{left:-170px}.speacial_dropbx .common_dropmenu:after,.speacial_dropbx .common_dropmenu:before{left:125px}.appbanner_drop .common_dropmenu:after,.appbanner_drop .common_dropmenu:before{left:180px}.splist li{float:left;border-right:0 solid #8c8c8c;margin-right:18px}.splist li:last-child{border-right:none;margin-right:0;padding-right:0}.top_search{width:424px;position:absolute;left:50%;top:2px;margin-left:-212px;border:1px solid #bababa;border-radius:17px;background-color:#fff;z-index:0;height:30px}.top_search_input{width:100%;border:0;outline:0;height:100%;border-radius:17px;padding:2px 30px 2px 15px;font:400 13px Lato,sans-serif}.top_search_btn{position:absolute;right:2px;top:2px;display:inline-block;border:0;background-color:#0065a1;width:24px;height:24px;border-radius:100%;cursor:pointer;display:flex;justify-content:center;align-items:center;color:#fff!important}.top_search_btn svg{width:10px;height:10px}.top_fl{float:left}.top_fr{float:right}.ad_hed_fl,.log_list{float:left}.log_list>li{float:left;padding:8px 0}.log_list>li:last-child>a{border-right:0}.hed_mid{padding:10px 0;border-bottom:1px solid #e2e2e2;min-height:90px}.ad_hed_fr{float:right}.main_nav>li{float:left;margin-bottom:-1px}.tooltipbox {position:absolute; top: 31px; padding:5px; display:none; z-index:99999999999; margin:-7px 0 0 -5px;}.tooltip_popup {border-radius: 3px; -webkit-border-radius:2px; background:#fff;}.logo_home{position:absolute;width:180px;height:70px;left:50%;margin-left:-90px;top:50%;margin-top:-35px}.navbg{border-bottom:1px solid #e5e5e5;padding-top:1px}svg{fill:currentColor}.main_nav{display:block;position:relative}.main_nav>li>a{display:inline-block}.main_nav>li>a{padding:10px 7px;font:900 12px Lato,sans-serif;color:#202020;border:1px solid transparent;border-bottom:0 solid transparent}.main_nav>li.active>a{color:#0065a1;background-color:#f7f7f7}.main_nav>li.active>a>.arrow.down{border:solid #2f669e;border-width:0 2px 2px 0}.main_nav>li:hover>a{color:#0065a1}.main_nav>li.sub_nav:hover>a{text-decoration:none;border:1px solid #d9d9d9;border-bottom:0 solid transparent;background-color:#fff;position:relative;z-index:9999;transition:.3s all;color:#0065a1}.main_nav>li.sub_nav:hover>a .arrow.down{border:solid #0065a1;border-width:0 1px 1px 0}.mega_menu{position:absolute;left:0;width:100%;background:#fff;display:none;z-index:999;border:1px solid #ccc;box-shadow:0 3px 3px 0 #898989;margin-top:-1px;color:#666;font:400 11px Lato,sans-serif}.main_nav>li.sub_nav:hover .mega_menu{display:block}.main_nav>li.sub_nav:hover .trans_wrapper{display:block}.header_desktop.expand .appbanner_drop .dropdown-menu,.header_desktop.header1024 .main_header_wrapper,.header_desktop.header1024 .speacial_dropbx .dropdown-menu{width:990px}.header_desktop.header1024 .main_nav>li>a{padding:10px 5px;font-size:11px}.header_desktop .bapro>a{color:#ef861a!important}.main_nav>li.budnav>a{color: #fff;background-color: #ef861a;}.main_nav>li.budnav>a:hover{color:#fff;}.navmenu_sub{background-color:#f7f7f7}.navlist_sub>li{float:left;padding:8px 0}.navlist_sub>li>a{display:inline-block;font:400 12px Lato,sans-serif;color:#333;padding:0 7px}.navlist_sub>li:first-child>a{padding-left:0}.navlist_sub>li:last-child>a{border-right:0}.header_desktop.header1024 .navlist_sub>li>a{padding:0 5px}.header_desktop.header1024 .navlist_sub>li:first-child>a{padding-left:0}.logo_fl{float:left;position:relative}.adright_top{float:right}.be_apro{position:absolute;right:2px;bottom:2px;font:400 11px Lato,sans-serif;color:#f08414!important;border-bottom:1px solid #f08414}.be_apro span{font-weight:700}.common_dropmenu{display:none}.droplogbox{display:none; position:absolute; width:100%; border: 1px solid #E2E2E2; box-shadow: 0 2px 5px rgba(0,0,0,0.175); width:304px; z-index:9999; background-color:#fff; left:auto; right:-2px; top:30px;}.hamburger_menu_desktop{display:none}.icpancakeblock{display:none}.new_tagtp {top: -4px; left: 2px; vertical-align:middle;}.new_tagtp svg{width:28px; height:15px;}.newtag-1{fill:#0066af;}.newtag-2{fill:#fff;}.menu_boxpd{ padding:25px 40px 25px 0px;}.market_menu{display:flex;}.market_menu.clearfix{display:flex;}.market_menu > li{float:left; width:30%; border-left:1px solid #E5E5E5; padding-left:40px;}.market_menu > li:first-child{border-left:0px;}.market_listmenu > li > a{color:#666666; font:400 11px 'Lato',sans-serif; display:block; padding:7px 0px;}.market_listmenu > li:last-child > a{ padding-bottom:0px;}.market_listmenu > li.bold{ margin-top:10px;}.market_listmenu > li.bold:first-child{ margin-top:0px;}.market_listmenu > li.bold > a{color:#000000; font:700 12px 'Lato',sans-serif;}.market_listmenu > li.bold > span{color:#000000; font:700 12px 'Lato',sans-serif; display:block; padding:7px 0px;}.market_listmenu > li > a:hover{color:#0065A1; text-decoration:underline !important;}.for_mcpro_users{display:none}.logo_home.logo_home_with_pro, .logo_fl.logo_home_with_pro{top: 80%;}.upgrade{background-color: #F8F0EB; border-radius: 3px; font: 11px/18px "Lato", sans-serif; font-weight: bold; color: #F08414; width: 58px; height: 20px; display: inline-block; text-align: center; margin-top: 6px; margin-right:6px;}.upgrade:hover{text-decoration: none; color: #F08414;}.header_desktop .bapro>a{color:#ef861a!important}.bapro.proMenu{height: 25px; line-height: 20px; color: #F08414; background-color: #F8F0EB; border-radius: 3px; padding: 4px 3px; text-align: center; margin: 4px 3px;}.header_desktop .main_nav .bapro.proMenu a {padding: 0 5px;}.header_desktop.header1024 .main_nav .bapro.proMenu a {padding: 0px 5px;}.menu-logo-top{border-bottom: 1px dotted #EAE8E8;padding-bottom:15px;margin-bottom:10px}.menu-logo-top .logo1{width: 117px;height: auto;margin-bottom: 12px}.menu-logo-top p{font-size: 11px;color: #666}.invest-top-sec{display: flex;justify-content: space-between;padding-left:10px;}.rgt-sd p{display: flex;align-items: flex-end;}.logo2{width: 72px;height: auto}.invest-top-sec .heading3{font:bold 12px/30px Lato,sans-serif;color: #000;text-transform: uppercase;}.invest-top-sec p{color:#666; font:normal 10px/12px Lato,sans-serif; align-items: center;}.invest-top-sec p img{margin-left: 5px}.invest-top-sec p svg{margin-left: 5px}.tit-txt1 {color: #000;font:bold 12px Lato,sans-serif;display: block;margin-bottom: 5px}.tit-txt2{color: #666;font:normal 11px/16px Lato,sans-serif;padding-right: 40px}.invst-menu .subc_fr .subc_list:last-child > li{margin-top: 0}.invst-menu .mcp_btn_blue_tp{top:31%;min-width: 90px;text-align: center;}
</style>
<style>
@media screen and (max-width:1279px){.header_desktop .main_header_wrapper{width:990px}.header_desktop .speacial_dropbx .dropdown-menu,.header_desktop.expand .appbanner_drop .dropdown-menu{width:990px}.header_desktop .main_nav>li>a{padding:10px 5px;font-size:11px}.navlist_sub>li>a{padding:0 5px}.searchBox .searchboxInner .txtsrchbox{margin-top:0px;width:100%;border:0;outline:0;height:25px;border-radius:17px;padding:2px 30px 2px 15px;font:400 13px Lato,sans-serif}.top_search_btn{position:absolute;right:2px;top:2px;display:inline-block;border:0;background-color:#0065a1;width:24px;height:24px;border-radius:100%;cursor:pointer;display:flex;justify-content:center;align-items:center;color:#fff!important}.top_search_btn svg{width:10px;height:10px}}@media screen and (max-width:980px){.mob-hide{display:none;}.header_desktop{display:none}.icpancakeblock{display:block}}@media screen and (max-width: 980px){.upgrade_your_exp {font: 13px/18px "robotoregular", sans-serif !important; color: #333333 !important;  background-color: #F9F1EC; border-left: 5px solid #652900; padding: 10px 25px !important; font-weight: 600 !important;}.removeads {width: 100px; height: 30px; border-radius: 30px; font: 9px/11px 'Roboto', sans-serif !important; font-weight: 500 !important; color: #FFFFFF !important; padding: 10px 22px !important; position: absolute; top: 0; right: 0; background-color: #652900; bottom: 0; margin: auto 10px !important;}}
</style>
<div style="display:none;"><table cellpadding="0" cellspacing="0" border="0"><tr><td><link rel="alternate" title="MoneyControl.com News" href="https://www.moneycontrol.com/rss/latestnews.xml" type="application/rss+xml" /></td></tr></table></div>
<script type="text/javascript">
	/* analytics functions start */
		var KEY = "A18ID", DAYS = "730";
		function _htCreate(name,value,days) {
			var expires = "";
			if (days) {
				var date = new Date();
				date.setTime(date.getTime() + (days*24*60*60*1000));
				expires = "; expires=" + date.toUTCString();
			}
			document.cookie = name + "=" + value + expires + "; path=/";
		}
		function _htGet(name) {
			var nameEQ = name + "=";
			var ca = document.cookie.split(";");
			for(var i=0;i < ca.length;i++) {
				var c = ca[i];
				while (c.charAt(0)==" ") c = c.substring(1,c.length);
				if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
			}
			return null;
		}
		function _htDel(name) { _htCreate(name,"",-1); }
		function getId() { return Date.now() + "." + Math.round(Math.random() * 1000000); }
		function create_dim_cookie(){
			ID = _htGet(KEY);
			if(null == ID || "" == ID) {
				ID = getId();
				_htCreate(KEY, ID, DAYS);
			}
		}
	/* end analytics functions */

	function getCookie(cname) {
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for(var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') { c = c.substring(1); }
			if (c.indexOf(name) == 0) { return c.substring(name.length, c.length); }
		}
		return "";
	}
	create_dim_cookie();

	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-156703-1', 'moneycontrol.com');
	ga('send', 'pageview');
	ga('require', 'GTM-PGHT597');
	var GA_USER_ID = getCookie("UIDHASH");
	var A18ID = getCookie("A18ID");
	ga('set', 'userId', GA_USER_ID); /* Set the user ID using signed-in user_id. */
	ga('set', 'dimension3', GA_USER_ID);
	ga('set', 'dimension4', A18ID);
	var mcpro = getCookie("mcpro");
	ga('set', 'dimension38', mcpro);

	function urchinTracker(pa_str) {ga(['_trackPageview', ''+pa_str+'']);}
	function GAEventTracker(category,action,opt_label) {ga('send', 'event', ''+category+'', ''+action+'', ''+opt_label+'');}
</script>
<!-- Begin comScore Tag -->
	<script>
		var _comscore = _comscore || [];
		_comscore.push({ c1: "2", c2: "6683813" });
		(function() {
			var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true;
			s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
			el.parentNode.insertBefore(s, el);
		})();
	</script>
	<noscript><img src="https://sb.scorecardresearch.com/p?c1=2&c2=6683813&cv=2.0&cj=1" alt="comScore" title="comScore" width="1" height="1" /></noscript>
<!-- End comScore Tag --><script type="text/javascript">
	var ad_delay_by = '2000';	/* Ad delay by n seconds */
</script>
<script type="text/javascript">
	function readCookie(e) {
		var t=e+"=";
		var n=document.cookie.split(";");
		for( var r=0; r < n.length; r++ ) {
			var i = n[r];
			while( i.charAt(0) == " " ) {
				i = i.substring( 1, i.length );
			}
			if( i.indexOf(t) == 0 ) {
				return i.substring( t.length, i.length )
			}
		}
		return false;
	}
	function readCookieRevamp(e) {
		var t=e+"=";
		var n=document.cookie.split(";");
		for( var r=0; r < n.length; r++ ) {
			var i = n[r];
			while( i.charAt(0) == " " ) {
				i = i.substring( 1, i.length );
			}
			if( i.indexOf(t) == 0 ) {
				return i.substring( t.length, i.length )
			}
		}
		return false;
	}
	function convertStringToCamelCase( str ) {
		str = str.toLowerCase();	/* Lower cases the string */
		/* str = str.replace(/[-_]+/g, ' ');	/* Replaces any - or _ characters with a space */
		/* str = str.replace(/[^\w\s]/g, '');	/* Removes any non alphanumeric characters */
		str = ' ' + str + ' ';

		return str.split(' ').map(function( item, index ) {
			return index !== 0 
				? item.charAt(0).toUpperCase() + item.substr(1) 
				: item.charAt(0).toLowerCase() + item.substr(1);
		}).join(' ');
	}
	var m_selected = '0';
	var JQ_IS_NEWS_SECTION = 0;

	var matrix_adunit=1;
	var usernnmc = readCookieRevamp("nnmc");

	var IE = document.all?true:false;
	var anychange=0;
	var bak_price_div;
	var matrix=0;
	var cnbc_matrix=0;

	/* Block site in Client IFrame -> Start */
		/* <meta http-equiv="X-Frame-Options" content="deny"> */
		if(top.location != window.location) {
			window.location = 'https://www.moneycontrol.com/mccode/common/iframe_blocker.php';
		}
	/* End <- Block site in Client IFrame */
</script>
<!--header start-->
<div class="trans_wrapper"></div>
<div class="over"></div>
<header class="">
	<input type="hidden" id="device_characteristics" name="device_characteristics" class="device_characteristics" value="is_mobile=false" style="width:90px;" readonly />
	<input type="hidden" id="device_type" name="device_type" class="device_type" value="desktop" style="width:40px;" readonly />
	<input type="hidden" id="is_desktop_mobile_page" name="is_desktop_mobile_page" class="is_desktop_mobile_page" value="1|1" style="width:40px;" readonly />
	<input type="hidden" id="cid" name="cid" class="cid" value="0" style="width:15px;" readonly />
	<input type="hidden" id="menu_l1_name" name="menu_l1_name" class="menu_l1_name" value="Markets" style="width:15px;" readonly />
	<input type="hidden" id="tvuid" name="tvuid" class="tvuid" value="" style="width:15px;" readonly />
	<input type="hidden" id="ppid" name="ppid" class="ppid" value="" style="width:15px;" readonly />
	<input type="hidden" id="ppuid" name="ppuid" class="ppuid" value="" style="width:15px;" readonly />
	<input type="hidden" id="page_id" name="page_id" class="page_id" value="" style="width:15px;" readonly />
	<input type="hidden" id="sec" name="sec" class="sec" value="" style="width:15px;" readonly />
	<input type="hidden" id="porter_convey" name="porter_convey" class="porter_convey" value="VDJ4a0lFMURTUT09" style="width:25px;" readonly />
	<input type="hidden" id="dfp_page" name="dfp_page" class="dfp_page" value="" style="width:15px;" readonly />
	<input type="hidden" id="is_dfp_ads_visible" name="is_dfp_ads_visible" class="is_dfp_ads_visible" value="true" style="width:25px;" readonly />
	<input type="hidden" id="last_visited_list" name="last_visited_list" class="last_visited_list" value="TDNOMGIyTnJjeTl0WVhKclpYUnBibVp2TDIxaGNtdGxkR05oY0M5aWMyVXZVRzl3YjNabGNpVXlNSEpsY1hWcGNtVnpKVEl3ZEc5dmJIUnBjQzVxY3c9PQ==" style="width:25px;" readonly />
	<input type="hidden" id="current_page_url" name="current_page_url" class="current_page_url" value="" style="width:150px;" readonly />
		<div class="header_desktop header1024">
		<div class="topnav">
			<div class="main_header_wrapper">
				<div class="clearfix">
					<div class="top_fl clearfix">
						<div class="mc_menu_icon">
							<span class="open_hamburger" title="Open">
								<svg xmlns="https://www.w3.org/2000/svg" width="16" height="9" viewBox="0 0 16 9">
									<defs> </defs>
									<g transform="translate(-286 -22)">
										<rect class="hambmenu" width="16" height="1" transform="translate(286 22)"/>
										<rect class="hambmenu" width="16" height="1" transform="translate(286 26)"/>
										<rect class="hambmenu" width="16" height="1" transform="translate(286 30)"/>
									</g>
								</svg>
							</span>
							<div class="hamburger_menu_desktop">
															</div>
						</div>
						<div class="lan_dropbx dropdown tophvr">
							<a href="https://www.moneycontrol.com/" title="English" class="lang_link">English<span class="arrow down"></span></a>
							<ul class="dropdown-menu langdrop common_dropmenu">
								<li><a href="https://hindi.moneycontrol.com" title="Hindi" target="_blank">Hindi</a></li>
								<li class="last"><a href="https://gujarati.moneycontrol.com/" title="Gujarati" target="_blank">Gujarati</a></li>
							</ul>
						</div>
						<div class="special_wrapbx">
							<div class="dropdown toptab3 speacial_dropbx">
							<input type="hidden" id="special_dropdown" value="" readonly />
								<a href="javascript:;" title="Specials">Specials<span class="arrow down"></span></a>
								<div class="dropdown-menu common_dropmenu">
									<ul class="splist clearfix" id="splist">
																			</ul>
								</div>
							</div>
						</div>
					</div>

					<!-- Web - Search box -> Start -->
					<div class="top_search_wrap">
						<div class="searchBox searchfloat clearfix FL">
							<div class="searchboxInner clearfix PR FL">
																<form name="form_topsearch" id="form_topsearch" method="get" onsubmit="javascript:return submit_search_txt('#form_topsearch');" action="">
									<input name="search_data" id="search_data" value="" type="hidden" readonly />
									<input name="cid" id="cid" value="" type="hidden" readonly />
									<input name="mbsearch_str" id="mbsearch_str" type="hidden" value="" readonly />
									<input name="topsearch_type" id="topsearch_type" value="1" type="hidden" readonly />
									<input class="txtsrchbox FL" id="search_str" onkeyup="getAutosuggesionHeader('#form_topsearch');" onclick="getAutosuggesionHeader('#form_topsearch');" placeholder="Search Quotes, News, Mutual Fund NAVs" name="search_str" value="" type="text" autocomplete="off" />
									<label for="search_str" style="display:none;">Search Quotes, News, Mutual Fund NAVs</label>

									<!-- Trending search ooptions -> Start -->
									<div class="trend_searchbx sugBox" style="display:none;">
				<div class="ausggestleft">
					<ul id="ul_srchCat_DDL"><li class="active"><a style="color:#fff !important" title="Trending Stocks">Trending Stocks</a></li></ul>
				</div>
				<div class="clearfix">
					<ul class="suglist">
						<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/india/stockpricequote/miningminerals/vedanta/SG" title="Vedanta">Vedanta&nbsp;<span>INE205A01025, VEDL, 500295</span></a></li>
						<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/india/stockpricequote/ironsteel/tatasteel/TIS" title="Tata Steel">Tata Steel&nbsp;<span>INE081A01020, TATASTEEL, 500470</span></a></li>
									<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/us-markets/stockpricequote/apple/AAPL" title="Apple">Apple&nbsp;<span>US0378331005, AAPL:US</span></a></li>
						<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/india/stockpricequote/auto-ancillaries/amararajabatteries/ARB" title="Amara Raja Batt">Amara Raja Batt&nbsp;<span>INE885A01032, AMARAJABAT, 500008</span></a></li>
									<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/us-markets/stockpricequote/microsoft/MSFT" title="Microsoft">Microsoft&nbsp;<span>US5949181045, MSFT:US</span></a></li>
					</ul>
				</div>
			</div><!-- Updated @ 2022-11-04 19:50:26 -->									<!-- End <- Trending search ooptions -->

									<!-- auto suggest box-->
									<div class="sugBox" id="autosugg_mc1" style="display:none;">
										<div class="ausggestleft">
											<ul id="ul_srchCat_DDL">
																								<li  class="active"  onclick="suggestboxdd('1', 'maintop');" id="tab1">
													<a rel="1" href="javascript:void(0);" title="Quotes"> Quotes </a>
												</li>
																								<li  onclick="suggestboxdd('2', 'maintop');" id="tab2">
													<a rel="2" href="javascript:void(0);" title="Mutual Funds"> Mutual Funds</a>
												</li>
												<li onclick="suggestboxdd('5', 'maintop');" id="tab5">
													<a rel="5" href="javascript:void(0);" title="Commodities"> Commodities </a>
												</li>
												<li onclick="suggestboxdd('9', 'maintop');" id="tab9">
													<a rel="9" href="javascript:void(0);" title="Futures">Futures &amp; Options </a>
												</li>
												<li onclick="suggestboxdd('3', 'maintop');" id="tab3">
													<a rel="3" href="javascript:void(0);" title="News"> News </a>
												</li>
												<li onclick="suggestboxdd( '11', 'maintop' );" id="tab11">
													<a rel="11" href="javascript:void(0);" title="Cryptocurrency"> Cryptocurrency </a>
												</li>
												<li onclick="suggestboxdd('4', 'maintop');" id="tab4">
													<a rel="4" href="javascript:void(0);" title="Forum"> Forum </a>
												</li>
												<li onclick="suggestboxdd('6', 'maintop');" id="tab6">
													<a rel="6" href="javascript:void(0);" title="Notices"> Notices </a>
												</li>
												<li onclick="suggestboxdd('7', 'maintop');" id="tab7">
													<a rel="7" href="javascript:void(0);" title="Videos"> Videos </a>
												</li>
												<li onclick="suggestboxdd('10', 'maintop');" id="tab10">
													<a rel="10" href="javascript:void(0);" title="Glossary"> Glossary </a>
												</li>
												<li onclick="suggestboxdd('8', 'maintop');" id="tab8">
													<a rel="8" href="javascript:void(0);" title="All"> All </a>
												</li>
											</ul>
										</div>
										<div class="top_asugscrl" id="autosuggestlist">
											<ul class="suglist scrollBar"></ul>
											<div class="brdtp CTR PT5"></div>
										</div>
									</div>
								</form>
							</div>
							<a href="javascript:void(0)" title="Submit" onclick="$('#form_topsearch').submit();"  class="top_search_btn">
								<svg version="1.1" id="Capa_1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192.904 192.904" style="enable-background:new 0 0 192.904 192.904;" xml:space="preserve">
									<path d="M190.707,180.101l-47.078-47.077c11.702-14.072,18.752-32.142,18.752-51.831C162.381,36.423,125.959,0,81.191,0C36.422,0,0,36.423,0,81.193c0,44.767,36.422,81.187,81.191,81.187c19.688,0,37.759-7.049,51.831-18.751l47.079,47.078c1.464,1.465,3.384,2.197,5.303,2.197c1.919,0,3.839-0.732,5.304-2.197C193.637,187.778,193.637,183.03,190.707,180.101z M15,81.193C15,44.694,44.693,15,81.191,15c36.497,0,66.189,29.694,66.189,66.193c0,36.496-29.692,66.187-66.189,66.187C44.693,147.38,15,117.689,15,81.193z"></path>
								</svg>
							</a> 
						</div>
					</div>
					<!-- End <- Web - Search box -->

					<div class="top_fr clearfix">
						<ul class="log_list">
							<li class="login_after dropdown tophvr">
								<div class="user_before_login blp">
									<span class="user_icon">
										<svg xmlns="https://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
											<defs></defs>
											<g transform="translate(-1125 -9)">
												<circle class="userictop" cx="8" cy="8" r="8" transform="translate(1125 9)"/>
												<g transform="translate(1127 11.21)">
													<path class="userictop1" d="M9,5.4H9a2,2,0,0,1-2-2V3A2,2,0,0,1,9,1H9a2,2,0,0,1,2,2v.4A2,2,0,0,1,9,5.4Z" transform="translate(-3.002)"/>
													<path class="userictop1"d="M9.991,17.961A1.594,1.594,0,0,0,8.819,16.42,11.084,11.084,0,0,0,6,16a11.084,11.084,0,0,0-2.823.42A1.594,1.594,0,0,0,2,17.961V18.8H9.991Z" transform="translate(0 -9.007)"/>
												</g>
											</g>
										</svg>
									</span>
									<a href="javascript:;" title="Hello, Login" class="userlink">Hello, Login</a>
								</div>
								<div class="user_after_login alp" style="display:none;">
									<span class="user_icon">
										<svg xmlns="https://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
											<defs></defs>
											<g transform="translate(-1125 -9)">
												<circle class="userictop" cx="8" cy="8" r="8" transform="translate(1125 9)"/>
												<g transform="translate(1127 11.21)">
													<path class="userictop1" d="M9,5.4H9a2,2,0,0,1-2-2V3A2,2,0,0,1,9,1H9a2,2,0,0,1,2,2v.4A2,2,0,0,1,9,5.4Z" transform="translate(-3.002)"/>
													<path class="userictop1" d="M9.991,17.961A1.594,1.594,0,0,0,8.819,16.42,11.084,11.084,0,0,0,6,16a11.084,11.084,0,0,0-2.823.42A1.594,1.594,0,0,0,2,17.961V18.8H9.991Z" transform="translate(0 -9.007)"/>
												</g>
											</g>
										</svg>
									</span>
									<a href="javascript:;" title="Hello, Login" class="userlink"><span class="usr_nm">Hello, Login</span><span class="arrow down"></span></a>
								</div>
								<div class="droplogbox langdrop common_dropmenu">
									<div class="log_signupbox">
										<div class="clearfix log_signup blp">
											<a href="javascript:;" title="Log In" class="btn_signin dropdown-toggle linkSignIn active" data-toggle="modal" data-target="#LoginModal">Log-in</a>
											<span class="or_top">or</span> 
											<a href="javascript:;" title="Sign Up" class="btn_signin dropdown-toggle linkSignUp" data-toggle="modal" data-target="#LoginModal">Sign-Up</a>
										</div>
										<div class="my_accbox">
											<p class="my_account">My Account</p>
											<div class="clearfix">
																								<ul class="my_acclist blp">
													<li>
														<a href="javascript:;" title="My Profile" class="linkSignIn" data-toggle="modal" data-target="#LoginModal">My Profile</a> <span style="color:#ff5a5a" class='verified_text'></span>
													</li>
													<li>
														<a href="javascript:;" title="My Portfolio" class="linkSignIn" data-toggle="modal" data-target="#LoginModal">My Portfolio</a>
													</li>
													<li><a href="javascript:;" title="My Watchlist" class="linkSignIn" data-toggle="modal" data-target="#LoginModal">My Watchlist</a></li>
													<li><a href="javascript:;" title="My Messages" class="linkSignIn" data-toggle="modal" data-target="#LoginModal">My Messages</a></li>
													<li>
														<a href="javascript:;" title="My Alerts" class="linkSignIn" data-toggle="modal" data-target="#LoginModal">My Alerts</a>
													</li>
												</ul>
												<ul class="my_acclist alp">
													<li>
														<a href="https://www.moneycontrol.com/portfolio-management/user/update_profile" title="My Profile">My Profile</a> <span style="color:#ff5a5a" class='verified_text'></span>
													</li>
													<li class="for_mcpro_users">
														<a href="https://www.moneycontrol.com/promos/pro.php" title="My PRO">My PRO</a>
													</li>
													<li>
														<a href="https://www.moneycontrol.com/india/bestportfoliomanager/investment-tool" title="My Portfolio">My Portfolio</a>
													</li>
													<li><a href="https://www.moneycontrol.com/bestportfolio/wealth-management-tool/stock_watchlist" title="My Watchlist" class="my_watchlist_link">My Watchlist</a></li>
													<li><a href="https://mmb.moneycontrol.com/" title="My Messages">My Messages</a></li>
													<li>
														<a href="https://www.moneycontrol.com/alerts/manage-alerts.php" title="My Alerts">My Alerts</a>
													</li>
													<li class="alp login_user_logout">
														<a href="https://www.moneycontrol.com/mcplus/portfolio/logout.php?ref=https://www.moneycontrol.com/mcplus/portfolio/loginportfolio.php" title="Logout">Logout</a>
													</li>
												</ul>
												<ul class="my_acclist last">
																										<li><a href="javascript:;" title="Chat with Us" onclick="javascript:openVerloopWidget();">Chat with Us</a></li>
													<li>Download App</li>
													<li>
														<a href="https://play.google.com/store/apps/details?id=com.divum.MoneyControl&hl=en_IN" title="Android" target="_blank" rel="noopener">
															<svg xmlns="https://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26">
																<defs></defs>
																<g transform="translate(-1129 -206)">
																	<g transform="translate(1133.008 210.026)">
																		<path class="android_a" d="M3.71,7.02a.718.718,0,0,0-.718.718v2.873a.718.718,0,0,0,1.436,0V7.738A.718.718,0,0,0,3.71,7.02Zm10.927,0a.718.718,0,0,0-.718.718v2.873a.718.718,0,1,0,1.436,0V7.738A.718.718,0,0,0,14.637,7.02Zm-1.97-3.95a.718.718,0,1,0-1.243-.718l-.441.763a4.257,4.257,0,0,0-3.62,0l-.442-.763a.718.718,0,1,0-1.243.718l.5.86A4.294,4.294,0,0,0,4.865,7.02v5.745a.718.718,0,0,0,.718.718H7.019v2.155a.718.718,0,0,0,1.436,0V13.483H9.892v2.155a.718.718,0,0,0,1.436,0V13.483h1.436a.718.718,0,0,0,.718-.718V7.02A4.294,4.294,0,0,0,12.171,3.93Zm-.621,8.977H6.3V8.456h5.745ZM6.3,7.02a2.873,2.873,0,1,1,5.745,0Z"/>
																	</g>
																	<g class="android_b" transform="translate(1129 206)">
																		<circle class="android_c" cx="13" cy="13" r="13"/>
																		<circle class="android_d" cx="13" cy="13" r="12.5"/>
																	</g>
																</g>
															</svg>
														</a>
														<a href="https://apps.apple.com/in/app/moneycontrol-markets-news/id408654600" title="IOS" target="_blank" rel="noopener">
															<svg xmlns="https://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26">
																<defs></defs>
																<g transform="translate(-1159 -206)">
																	<g transform="translate(1163.138 211.001)">
																		<path class="apple_a" d="M14.417,10.657a2.218,2.218,0,0,1-1.345-2.048,2.29,2.29,0,0,1,1.1-1.93.655.655,0,0,0,.2-.927,3.651,3.651,0,0,0-2.63-1.562,4.206,4.206,0,0,0,.632-2.6A.644.644,0,0,0,11.7,1,4.382,4.382,0,0,0,8.787,2.481a4.481,4.481,0,0,0-.969,1.9A3.448,3.448,0,0,0,6.757,4.2a3.881,3.881,0,0,0-3.268,1.97c-1.237,2.146-.48,5.363.859,7.3.537.775,1.343,1.94,2.56,1.94h.072a3.1,3.1,0,0,0,1.174-.3,2.144,2.144,0,0,1,.947-.232,1.994,1.994,0,0,1,.889.221,3.112,3.112,0,0,0,1.285.3c1.253-.024,1.993-1.1,2.533-1.895a7.887,7.887,0,0,0,.991-2.036.657.657,0,0,0-.382-.806ZM9.78,3.337a3.236,3.236,0,0,1,1.257-.866,3.18,3.18,0,0,1-.679,1.408,2.875,2.875,0,0,1-.828.682h0l-.056.022c-.122.048-.273.107-.39.146a3.16,3.16,0,0,1,.7-1.393Zm2.947,9.422c-.526.768-.94,1.314-1.476,1.324a1.55,1.55,0,0,1-.74-.191A3.255,3.255,0,0,0,9.1,13.562a3.415,3.415,0,0,0-1.46.336,1.89,1.89,0,0,1-.711.2H6.91c-.532,0-1.1-.827-1.485-1.376-.951-1.375-1.829-4.115-.8-5.9A2.565,2.565,0,0,1,6.779,5.509H6.8A3.116,3.116,0,0,1,7.876,5.8c.085.033.17.067.255.1a.562.562,0,0,0,.065.025,2.171,2.171,0,0,0,.732.155A2.905,2.905,0,0,0,9.953,5.8a3.246,3.246,0,0,1,1.455-.326,2.48,2.48,0,0,1,1.474.559A3.478,3.478,0,0,0,11.762,8.62h0a3.471,3.471,0,0,0,1.6,2.949,6.679,6.679,0,0,1-.639,1.189Z"/>
																	</g>
																	<g class="apple_b" transform="translate(1159 206)">
																		<circle class="apple_c" cx="13" cy="13" r="13"/>
																		<circle class="apple_d" cx="13" cy="13" r="12.5"/>
																	</g>
																</g>
															</svg>
														</a>
													</li>
												</ul>
											</div>
										</div>
										<div class="follow_iconbox">
											<p>Follow us on:</p>
											<div class="top_shareicon">
												<a href="https://www.facebook.com/moneycontrol" title="Facebook" target="_blank" rel="noopener">
													<svg xmlns="https://www.w3.org/2000/svg" width="34.404" height="34.404" viewBox="0 0 34.404 34.404">
														<defs></defs>
														<path class="fb_a" d="M17.2,0A17.2,17.2,0,1,1,0,17.2,17.2,17.2,0,0,1,17.2,0Z" transform="translate(0 0)"/>
														<g transform="translate(12.997 9.939)">
															<path class="fb_b" d="M13.116,4.538h1.437V2.107A19.962,19.962,0,0,0,12.459,2a3.278,3.278,0,0,0-3.5,3.593v2H6.61v2.722H8.957v6.973h2.813V10.318H14.11L14.462,7.6H11.771V5.861C11.771,5.058,11.985,4.538,13.116,4.538Z" transform="translate(-6.61 -2)"/>
														</g>
													</svg>
												</a>
												<a href="https://twitter.com/moneycontrolcom" title="Twitter" target="_blank" rel="noopener">
													<svg xmlns="https://www.w3.org/2000/svg" width="34.404" height="34.404" viewBox="0 0 34.404 34.404">
														<defs></defs>
														<path class="tw_a" d="M17.2,0A17.2,17.2,0,1,1,0,17.2,17.2,17.2,0,0,1,17.2,0Z" transform="translate(0 0)"/>
														<g transform="translate(10.703 12.232)">
															<path class="tw_b" d="M16.351,5.249a6.092,6.092,0,0,1-1.693.459,2.964,2.964,0,0,0,1.3-1.629,5.891,5.891,0,0,1-1.873.718A2.942,2.942,0,0,0,9.061,7.481,8.353,8.353,0,0,1,3,4.4,2.985,2.985,0,0,0,2.6,5.888,2.935,2.935,0,0,0,3.909,8.335a2.906,2.906,0,0,1-1.335-.366V8a2.942,2.942,0,0,0,2.368,2.87A2.82,2.82,0,0,1,4.153,11a3.516,3.516,0,0,1-.553-.05,2.949,2.949,0,0,0,2.748,2.038,5.9,5.9,0,0,1-3.631,1.263A5.691,5.691,0,0,1,2,14.2a8.3,8.3,0,0,0,4.514,1.328,8.317,8.317,0,0,0,8.4-8.381V6.77a6.049,6.049,0,0,0,1.435-1.521Z" transform="translate(-2 -3.849)"/>
														</g>
													</svg>
												</a>
												<a href="https://www.instagram.com/moneycontrolcom/" title="Instagram" target="_blank" rel="noopener">
													<svg xmlns="https://www.w3.org/2000/svg" width="34.404" height="34.404" viewBox="0 0 34.404 34.404">
														<defs></defs>
														<path class="insta_a" d="M17.2,0A17.2,17.2,0,1,1,0,17.2,17.2,17.2,0,0,1,17.2,0Z" transform="translate(0 0)"/>
														<g transform="translate(10.703 11.468)">
															<path class="insta_b" d="M8.5,6.887A1.612,1.612,0,1,0,10.11,8.5,1.612,1.612,0,0,0,8.5,6.887Zm6.453-1.592a4.243,4.243,0,0,0-.273-1.469,2.6,2.6,0,0,0-1.508-1.508A4.244,4.244,0,0,0,11.7,2.045C10.864,2,10.617,2,8.5,2s-2.365,0-3.2.045a4.244,4.244,0,0,0-1.469.273A2.6,2.6,0,0,0,2.318,3.826a4.244,4.244,0,0,0-.273,1.469C2,6.133,2,6.38,2,8.5s0,2.365.045,3.2a4.458,4.458,0,0,0,.273,1.475,2.56,2.56,0,0,0,.591.91,2.528,2.528,0,0,0,.916.591,4.243,4.243,0,0,0,1.469.273C6.133,15,6.38,15,8.5,15s2.365,0,3.2-.045a4.244,4.244,0,0,0,1.469-.273,2.528,2.528,0,0,0,.916-.591,2.56,2.56,0,0,0,.591-.91,4.289,4.289,0,0,0,.273-1.475C15,10.864,15,10.617,15,8.5S15,6.133,14.952,5.295Zm-1.651,5.2a3.724,3.724,0,0,1-.253,1.17,2.508,2.508,0,0,1-1.384,1.384,3.724,3.724,0,0,1-1.176.227H6.51a3.724,3.724,0,0,1-1.176-.227A2.419,2.419,0,0,1,3.95,11.663a3.568,3.568,0,0,1-.221-1.176V6.51A3.568,3.568,0,0,1,3.95,5.334a2.281,2.281,0,0,1,.559-.851,2.333,2.333,0,0,1,.825-.533A3.724,3.724,0,0,1,6.51,3.722h3.977a3.724,3.724,0,0,1,1.176.227,2.419,2.419,0,0,1,1.384,1.384,3.724,3.724,0,0,1,.227,1.176V8.5c0,1.339.045,1.475.026,1.989Zm-1.04-4.835a1.547,1.547,0,0,0-.916-.916,2.6,2.6,0,0,0-.9-.143h-3.9a2.6,2.6,0,0,0-.9.169,1.547,1.547,0,0,0-.916.884,2.775,2.775,0,0,0-.136.9v3.9a2.775,2.775,0,0,0,.169.9,1.547,1.547,0,0,0,.916.916,2.775,2.775,0,0,0,.864.169h3.9a2.6,2.6,0,0,0,.9-.169,1.547,1.547,0,0,0,.916-.916,2.6,2.6,0,0,0,.169-.9v-3.9a2.456,2.456,0,0,0-.169-.9ZM8.5,10.981A2.482,2.482,0,1,1,10.987,8.5,2.476,2.476,0,0,1,8.5,10.981ZM11.1,6.5a.585.585,0,0,1,0-1.163.585.585,0,0,1,0,1.163Z" transform="translate(-2 -2)"/>
														</g>
													</svg>
												</a>
												<a href="https://www.linkedin.com/company/moneycontrol" title="LinkedIn" target="_blank" rel="noopener">
													<svg xmlns="https://www.w3.org/2000/svg" width="34.404" height="34.404" viewBox="0 0 34.404 34.404">
														<defs></defs>
														<g transform="translate(0 -0.404)">
															<path class="linkden_a" d="M17.2,0A17.2,17.2,0,1,1,0,17.2,17.2,17.2,0,0,1,17.2,0Z" transform="translate(0 0.404)"/>
															<g transform="translate(9.415 7.483)">
																<path class="linkden_b" d="M11.953,6.4a3.531,3.531,0,0,0-1.671.42.651.651,0,0,0-.609-.42H7.067a.651.651,0,0,0-.651.651v7.817a.651.651,0,0,0,.651.651H9.673a.651.651,0,0,0,.651-.651V11.283a.651.651,0,0,1,1.3,0v3.583a.651.651,0,0,0,.651.651h2.606a.651.651,0,0,0,.651-.651V9.981A3.587,3.587,0,0,0,11.953,6.4Zm2.28,7.817.365-.084.149-2.492c0-1.079-.84-4.044-1.92-4.044s-5.354-.847-5.354.233l.077,6.387h.168V7.7h1.3l-1.24-.159c0,.277,1.415,1.14,1.676,1.232a.651.651,0,0,0,.724-.208,2.269,2.269,0,0,1,4.051,1.416ZM5.113,6.4H2.507a.651.651,0,0,0-.651.651v7.817a.651.651,0,0,0,.651.651H5.113a.651.651,0,0,0,.651-.651V7.049A.651.651,0,0,0,5.113,6.4ZM2.736,14.131l.422.084V7.7H2.988ZM3.82,1.54a2.106,2.106,0,1,0-.037,4.206H3.8A2.106,2.106,0,1,0,3.82,1.54Zm.76,2.569.413-.889c-.228.028-.242-.224-.413-.378s-.441.468-.438.239c0-.487-.886-.239-.321-.239.23-.03-.894-.288-.72-.135s.12.723.119.955c0,.486,1.924.446,1.36.446Z" transform="translate(-1 1.385)"/>
															</g>
														</g>
													</svg>
												</a>
												<a href="https://t.me/moneycontrolcom" title="Telegram" target="_blank" rel="noopener">
													<svg enable-background="new 0 0 24 24" height="33" viewBox="0 0 24 24" width="33" xmlns="https://www.w3.org/2000/svg">
														<circle cx="12" cy="12" fill="#039be5" r="12"/>
														<path d="m5.491 11.74 11.57-4.461c.537-.194 1.006.131.832.943l.001-.001-1.97 9.281c-.146.658-.537.818-1.084.508l-3-2.211-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.121l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953z" fill="#fff"/>
													</svg>
												</a>
												<a href="https://www.nw18.com/home" title="Network 18" target="_blank" rel="noopener">
													<img src="https://images.moneycontrol.com/images/common/headfoot/network18_33x33.png" alt="Network 18" title="Network 18" width="33" height="33" />
												</a>
											</div>
										</div>
									</div>
								</div>
							</li>
						</ul>
					</div>
					<div class="top_fr for_nonpro_users">
						<a href="https://www.moneycontrol.com/promos/pro.php" title="Upgrade" class="upgrade" >Upgrade</a>
					</div>
				</div>
			</div>
		</div>

				<script type='text/javascript'>
					var googletag = googletag || {};
					googletag.cmd = googletag.cmd || [];

									</script>
			<!-- dfpad_config|OLD MCI -> Start -->
<script type="text/javascript">
	var is_dfp_ads_visible = true; /* Use to check for DFP Ads visibility */
	var ppid_cookie_name = 'MC_PPID_LOGIC';

	/* Create DFP cookie function -> Start */
		function create_dfp_cookie( name, value, days ) {
			var expires="";
			if( days ) {
				var date = new Date();
				date.setTime(date.getTime()+(days*24*60*60*1000));
				expires = "; expires="+date.toGMTString();
			} else { 
				expires = ""; 
			}
			document.cookie = name+"="+value+expires+"; path=/; domain=.moneycontrol.com;";
		}
	/* End <- Create DFP cookie function */

	/* Read DFP cookie function -> Start */
		function get_dfp_cookie( cname ) {
			var name = cname + "=";
			var ca = document.cookie.split( ';' );
			for( var i = 0; i < ca.length; i++ ) {
				var c = ca[i];
				while( c.charAt(0) == ' ' ) {
					c = c.substring(1);
				}
				if( c.indexOf( name ) == 0 ) {
					return c.substring( name.length, c.length );
				}
			}
			return "";
		}
	/* End <- Read DFP cookie function */

	/* Load scrip file function -> Start */
		function load_script_file( src, is_async ) {
			var script = document.createElement( 'script' );
			script.src = src;
			script.async = is_async ? "async" : false;
			document.head.appendChild( script );
		}
	/* End <- Load scrip file function */

	/* Generate PPID function -> Start */
		function generate_dfp_ppid() {
			var ppid_cookie_object = get_dfp_cookie( ppid_cookie_name );	/* Get Cookie Value */

			/* Checks for Cookie is exists OR not? */
			if( ppid_cookie_object == undefined || ppid_cookie_object == '' ) {
				var ppid_normal_user = 'normaluser' + Math.floor( Math.pow( 15, 13 ) + Math.random() * 14 * Math.pow( 15, 13 ) ) + 'mcids';
				create_dfp_cookie( ppid_cookie_name, ppid_normal_user, '180' );	/* Create Cookie */
			}
		}
	/* End <- Generate PPID function */

	/* Set User Behaviour -> Start */
		function _w18sub() {
			var _w18userinfo_out = {};
			if( typeof localStorage !== "undefined" ) {
				if( localStorage.getItem( "_w18userinfo" ) !== null ) {
					_w18userinfo_out = localStorage.getItem( "_w18userinfo" );
					_w18userinfo_out = unescape( _w18userinfo_out );
					var contact = JSON.parse( _w18userinfo_out );

					for(var contactItem in contact){
						if(contactItem == 'interest_channel' || contactItem == 'interest_bucket' || contactItem == 'logged_in' || contactItem == 'extra'){
							for(var contactItemVal in contact[contactItem]){
								googletag.pubads().setTargeting( contactItemVal,contact[contactItem][contactItemVal] );
							}
						} else if(contactItem == 'vernacular' ) {
							googletag.pubads().setTargeting( contactItem,contact[contactItem] );
						} else if(contactItem == 'interest_platform' ) {
							for(var contactItemVal in contact[contactItem]) {
								googletag.pubads().setTargeting( contactItemVal,contact[contactItem][contactItemVal]);
								for(var platform_name in contact[contactItem][contactItemVal] ) {
									//googletag.pubads().setTargeting( contactItemVal,contact[contactItem][contactItemVal][platform_name] );
								}
							}
						}
					};
				}
			}
			return false;
		}
	/* End <- Set User Behaviour */

	/* Normal DFP -> Start */
		function normal_dfp() {
			(function() {
				var gads = document.createElement('script');
				gads.async = true;
				gads.type = 'text/javascript';
				var useSSL = 'https:' == document.location.protocol;
				gads.src = (useSSL ? 'https:' : 'http:') + '//securepubads.g.doubleclick.net/tag/js/gpt.js';
				var node = document.getElementsByTagName('script')[0];
				node.parentNode.insertBefore(gads, node);
			})();
		}
	/* End <- Normal DFP */

	/* send Ad server Request function -> Start */
		function sendAdserverRequest() {
			try {
				if (rtbpbjs && rtbpbjs.adserverRequestSent) return;
				googletag.cmd.push(function() {
					googletag.pubads().refresh();
				});
			} catch (e) {
				googletag.cmd.push(function() {
					googletag.pubads().refresh();
				});
			}
		}
	/* End <- send Ad server Request function */

	/* Get Page Meta List function -> Start */
		function get_page_meta_list( meta_name ) {
			const metas = document.getElementsByTagName( 'meta' );
			if( meta_name != '' ) {
				for( let i = 0; i < metas.length; i++ ) {
					if( metas[i].getAttribute( 'name' ) === meta_name ) {
						return metas[i].getAttribute( 'content' );
					}
				}
			}
			return '';
		}
	/* End <- Get Page Meta List function */

	/* Set DFP Targeting -> Start */
		function set_dfp_targeting() {
			let activate_set_targeting = false;
			let dfp_targeting_cookie_name = 'USR_DFP_TARGETING';

			/* Checks for Cookie is exists OR not? */
			if( get_dfp_cookie( 'nnmc' ) ) {
				activate_set_targeting = true;
			}

			/* Hide for MC Pro Users -> Start */
				let mcpro = get_dfp_cookie( 'mcpro' );
				if( mcpro == '1' ) {
					activate_set_targeting = false;
				}
			/* End <- Hide for MC Pro Users */

			if( activate_set_targeting == true ) {
				let dfp_targeting_cookie_object = get_dfp_cookie( dfp_targeting_cookie_name );	/* Get Cookie Value */

				/* Checks for Cookie is exists OR not? */
				if( dfp_targeting_cookie_object == '' || typeof( dfp_targeting_cookie_object ) == "undefined" ) {
					let user_token_normal = get_dfp_cookie( 'token-normal' );

					if( user_token_normal != '' ) {
						let ajax_link = 'https://www.moneycontrol.com/portfolio_plus/userdetail.php?token=' + user_token_normal + '&classic=true';
						let opts = {
							method: 'GET',
							headers: {}
						};
						fetch( ajax_link, opts ).then( function ( response ) {
							return response.json();
						})
						.then( function ( json_obj ) {

							if( Object.keys( json_obj ).length > 0 ) {
								if( json_obj.status == 'success' ) {
									let value = json_obj.data;

									let birthday = value.dob;

									/* Find out Age -> Start */
										if( birthday != '' ) {
											// Actual format YYYY-MM-YY 
											birthday = birthday.replace( /\-/g, "," );	// Convert to YYYY,MM,YY
											birthday = new Date( birthday );
											let ageDifMs = Date.now() - birthday.getTime();
											let ageDate = new Date( ageDifMs ); // miliseconds from epoch
											birthday = String( Math.abs( ageDate.getUTCFullYear() - 1970 ) );
										}
									/* End <- Find out Age */

									if( value.tvuid != '' ) {
										document.getElementById( 'tvuid' ).value = value.tvuid;
									}

									let dfp_targeting_cookie_object = {};
									dfp_targeting_cookie_object.p_value = value.p_value;
									dfp_targeting_cookie_object.dob = birthday;
									dfp_targeting_cookie_object.gender = value.gender;
									dfp_targeting_cookie_object.income_data = value.income_data;
									dfp_targeting_cookie_object.occupation = value.occupation;
									dfp_targeting_cookie_object.industry = value.industry;

									console.log( dfp_targeting_cookie_name, ' Cookie = ', dfp_targeting_cookie_object );

									googletag.pubads().setTargeting( 'p_value', dfp_targeting_cookie_object.p_value );
									googletag.pubads().setTargeting( 'dob', dfp_targeting_cookie_object.dob );
									googletag.pubads().setTargeting( 'gender', dfp_targeting_cookie_object.gender );
									googletag.pubads().setTargeting( 'income_data', dfp_targeting_cookie_object.income_data );
									googletag.pubads().setTargeting( 'occupation', dfp_targeting_cookie_object.occupation );
									googletag.pubads().setTargeting( 'industry', dfp_targeting_cookie_object.industry );

									/* Create Cookie */
									create_dfp_cookie( dfp_targeting_cookie_name, JSON.stringify( dfp_targeting_cookie_object ), '1' );
								}
							}
						});
					}
				} else {
					dfp_targeting_cookie_object = JSON.parse( dfp_targeting_cookie_object );

					googletag.pubads().setTargeting( 'p_value', dfp_targeting_cookie_object.p_value );
					googletag.pubads().setTargeting( 'dob', dfp_targeting_cookie_object.dob );
					googletag.pubads().setTargeting( 'gender', dfp_targeting_cookie_object.gender );
					googletag.pubads().setTargeting( 'income_data', dfp_targeting_cookie_object.income_data );
					googletag.pubads().setTargeting( 'occupation', dfp_targeting_cookie_object.occupation );
					googletag.pubads().setTargeting( 'industry', dfp_targeting_cookie_object.industry );
				}
			} else {
				/* Delete Cookie */
				if( get_dfp_cookie( dfp_targeting_cookie_name ) ) {
					create_dfp_cookie( dfp_targeting_cookie_name, '', 0 );
				}
			}

			/* Checks for Page Meta Attributes -> Start */
				var menu_l1_name = document.getElementById( 'menu_l1_name' ).value;
				if( menu_l1_name != '' ) {
					googletag.pubads().setTargeting( 'section_name', menu_l1_name.replace( /\s+/g, '-' ) );
					googletag.pubads().setTargeting( 'Content_Type', menu_l1_name.replace( /\s+/g, '-' ) );
				}

				var title_name = document.title;
				if( title_name != '' ) {
					googletag.pubads().setTargeting( 'title_name', title_name );
				}

				var meta_keywords = get_page_meta_list( 'keywords' );
				if( meta_keywords != '' ) {
					googletag.pubads().setTargeting( 'meta_keywords', "['" + meta_keywords + "']" );
				}

				googletag.pubads().setTargeting( 'DFP', 'okay' );

				var page_url = window.location.href;
				if( page_url != '' ) {
					googletag.pubads().setTargeting( 'page_url', page_url );
				}

				var meta_description = get_page_meta_list( 'description' );
				if( meta_description != '' ) {
					googletag.pubads().setTargeting( 'excerpt_description', meta_description );
				}
			/* End <- Checks for Page Meta Attributes */

		}
	/* End <- Set DFP Targeting */

	/* Launch dfp ads function -> Start */
		function launch_dfp_ads() {

			/*  Normal DFP -> Start */
				normal_dfp();
			/* End <- Normal DFP */

							/* Header biding -> Start */
					load_script_file( 'https://rtbcdn.andbeyond.media/prod-global-32339.js', true );
				/* End <- Header biding */
			
			/* Initialized DFP Define Slots -> Start */
				define_dfp_slot();
			/* End <- Initialized DFP Define Slots */
		}
	/* End <- Launch dfp ads function */
</script>
	<script type="text/javascript">
	/*jquery cookie*/
		var dfp_cookie_userinfo = get_dfp_cookie('_w18userinfo');
		var dfp_cookie_object = {};
		var dfp_cookie_bucket;
		var dfp_cookie_flag_floating = false;
		var dfp_cookie_floating_val;
		if(dfp_cookie_userinfo!='' && typeof(dfp_cookie_userinfo)!="undefined"){
			dfp_cookie_floating_val = get_dfp_cookie('dfp_cookie_floating');
			dfp_cookie_userinfo = unescape(dfp_cookie_userinfo);
			dfp_cookie_object = JSON.parse(dfp_cookie_userinfo);
			dfp_cookie_bucket = dfp_cookie_object['NW_Bucket'];

			if(typeof dfp_cookie_bucket != 'undefined' && dfp_cookie_bucket=='m'){
				dfp_cookie_flag_floating = false;

			}else if(typeof dfp_cookie_bucket != 'undefined' && dfp_cookie_bucket!='m'){

				if(typeof dfp_cookie_floating_val == 'undefined' || dfp_cookie_floating_val.length==0){
					dfp_cookie_flag_floating = true;
				}
			}
		}

		//dfp_cookie_flag_floating = true; //for testing
		
		//1280x800 actual
		//1240x768 testing
		
		//var dfp_flag_sticky = false;
		//var dfp_flag_gutter = false;
		var w_flag = document.documentElement.clientWidth;
		var h_flag = window.screen.height;

		//if(w_flag >= 1280 && h_flag>=600){ 
			var dfp_flag_sticky = true;
			var dfp_flag_gutter = true;
		//}

		//var dfp_flag_sticky = true;
		//var dfp_flag_gutter = true;

		/*
		console.log('dfp_cookie_floating_val >> ',dfp_cookie_floating_val); //string
		console.log('dfp_cookie_userinfo >> ',dfp_cookie_userinfo); //string
		console.log('dfp_cookie_object >> ',dfp_cookie_object); //object
		console.log('dfp_cookie_bucket >> ',dfp_cookie_bucket);
		console.log('dfp_cookie_flag_floating >> ',dfp_cookie_flag_floating);
		console.log('dfp_flag_sticky >> ',dfp_flag_sticky ,'>>',w_flag,'>>',h_flag);
		console.log('dfp_flag_gutter >> ',dfp_flag_gutter ,'>>',w_flag,'>>',h_flag);
		*/
		

	</script>
	<script type="text/javascript">
			var rhs_180x400 = false;
			var rhs_180x300_1 = false;
			var rhs_180x300_1_currencies = false;
			var rhs_180x300_2 = false;
			var news_rhs_300x600_currencies = false;
		</script>
							<script type='text/javascript'>
								function define_dfp_slot() {

									var ppid = document.getElementById( 'ppid' ).value;
									if( ppid === null || ppid === '' ) {
										ppid = get_dfp_cookie( ppid_cookie_name );	/* Get Cookie Value */
									}
									console.log( 'ppid = ', ppid );

							googletag.cmd.push(function() {googletag.defineSlot('/1039154/Moneycontrol/MC_ROS/MC_ROS_Slider_2x2', [2,2], 'Moneycontrol/MC_ROS/MC_ROS_Slider_2x2').addService(googletag.pubads());googletag.defineSlot('/1039154/Moneycontrol/MC_Market/MC_Market_Internal_728x90', [[728,90],[970,90],[768,90]], 'Moneycontrol/MC_Market/MC_Market_Internal_728x90').addService(googletag.pubads()); _w18sub();
				googletag.pubads().enableLazyLoad({ fetchMarginPercent: 200, renderMarginPercent: 200, mobileScaling: 1.5 });
				
				googletag.pubads().disableInitialLoad();
				if( ppid != '' ) {
					googletag.pubads().setPublisherProvidedId( ppid );
				}
				googletag.enableServices();

				set_dfp_targeting();

				});

				setTimeout(function() {
					sendAdserverRequest();
				}, 5000);
			}	// function define_dfp_slot()

					var user_token_normal = get_dfp_cookie( 'token-normal' );
					if( user_token_normal != '' ) {
						var ajax_link = 'https://www.moneycontrol.com/monitoring/mc_user_entitlements.php?user_token=' + user_token_normal;
						var opts = {
							method: 'GET',
							headers: {}
						};
						fetch( ajax_link, opts ).then( function ( response ) {
							return response.json();
						})
						.then( function ( json_obj ) {
							if( json_obj.hasOwnProperty( 'tvuid' ) ) {
								document.getElementById( 'tvuid' ).value = json_obj.tvuid;
							}
							if( json_obj.hasOwnProperty( 'ppid' ) ) {
								document.getElementById( 'ppid' ).value = json_obj.ppid;
							}
							if( json_obj.hasOwnProperty( 'entitlements' ) ) {
								if( !json_obj.entitlements.hasOwnProperty( 'mc_pro' ) ) {
									/* Normal User */
									setTimeout( function() { launch_dfp_ads(); }, 2000 );
								} else {
									/* MC PRO User */
									is_dfp_ads_visible = false;
									document.getElementById( 'is_dfp_ads_visible' ).value = is_dfp_ads_visible;
								}
							} else {
								/* Normal User */
								setTimeout( function() { launch_dfp_ads(); }, 2000 );
							}
						});
					} else {
						generate_dfp_ppid();	/* Generate PPID for Free Users */

						/* Free User */
						setTimeout( function() { launch_dfp_ads(); }, 2000 );
					}
				</script>
<script type="text/javascript">
function _w18setuserbehaviour(){ //_w18userinfo
	var i, x, y, cl = document.cookie.split(";");
	var _w18userinfo_out = {};
	var _w18userdetail_out = {}; _w18userdetail_out._w18userdetail='';
	var c = 0;
	for (i = 0; i < cl.length; i++) {
		x = cl[i].substr(0, cl[i].indexOf("="));
		y = cl[i].substr(cl[i].indexOf("=") + 1);
		x = x.replace(/^\s+|\s+$/g, "");
		
		if (x == "_w18userinfo") {
			_w18userinfo_out._w18userinfo = unescape(y);
			c = c + 1
		}
		
		if (x == "_w18userdetail") {
					_w18userdetail_out._w18userdetail = unescape(y);
					c = c + 1
		}
		if (c == 2) {break;}
	}

	if(c==1 || c==2){
		var contact = JSON.parse(_w18userinfo_out._w18userinfo);
		
		for (var item in contact) {
			googletag.pubads().setTargeting(item,contact[item]);
		}
		if(_w18userdetail_out._w18userdetail != '' || _w18userdetail_out._w18userdetail.length >0 ){
			var lapsed_contact = JSON.parse(_w18userdetail_out._w18userdetail);
			if(_w18userdetail_out._w18userdetail){
				for (var lapsed_item in lapsed_contact) {
					googletag.pubads().setTargeting(lapsed_item,lapsed_contact[lapsed_item]);
				}
			}
		}
	}
} 

function _w18_lc_settargeting() {
	if(typeof localStorage !== "undefined") {
		//start of code
		if(localStorage.getItem("di_consume_articles") !== null) {
			var di_consume_articles_json = localStorage.getItem("di_consume_articles");
			if(!di_consume_articles_json || di_consume_articles_json !== null){
				var di_consume_articles_old_arr = JSON.parse(di_consume_articles_json);
				var default_list_json	=  '{"2089141":1, "1624181":1, "1623461":1, "1399696":1}';
				var default_list	=  JSON.parse(default_list_json);
			    //default_list = default_list.filter(function(n){ return n != undefined }); 
				var not_consume = new Array();//send to dfp
				for(key in default_list){
					if(di_consume_articles_old_arr[key] != 1){
						not_consume.push(key);
					}
				}
				if(not_consume.length>0){
					googletag.pubads().setTargeting('di_consume_articles',not_consume);
				}
			}
		}
		//end of code
	}
}

//mctop_getCookie //dfpGutter_getCookie
//mctop_setCookie //dfpGutter_setCookie 

var dfp_date = new Date();
//var mc_mcmarketinternal_gutter_ck = "MC_GUTTER_mcmarketinternal_"+dfp_date.getFullYear()+"-"+(dfp_date.getMonth()+1)+"-"+dfp_date.getDate();

var mc_mcmarketinternal_gutter_ck = "MC_GUTTER_mcmarketinternal";


function close_mc_gutter(){
	dfpGutter_setCookie(mc_mcmarketinternal_gutter_ck,1,1);		
}


function dfpGutter_setCookie(e,t,n){
	var r=new Date;
	r.setDate(r.getDate()+n);
	var i=escape(t)+(n==null?"":"; expires="+r.toUTCString())+"; path=/; domain=.moneycontrol.com; ";
	document.cookie=e+"="+i
}
function dfpGutter_getCookie(e){
	var t,n,r,i=document.cookie.split(";");
	for(t=0;t<i.length;t++){
		n=i[t].substr(0,i[t].indexOf("="));
		r=i[t].substr(i[t].indexOf("=")+1);
		n=n.replace(/^\s+|\s+$/g,"");
		if(n==e){
			return unescape(r)
			}
		}
}

</script>
<!-- End <- dfpad_config|OLD MCI -->
<!-- OMC -->

		<div class="hed_mid" >
			<div class="main_header_wrapper">
				<div class="clearfix logo_wrapper">
											<div class="header_innerpage" style="display:block;">
																<div class="google_force_tags" style="display:none;">mcmarketinternal->Moneycontrol/MC_Market/MC_Market_Internal_728x90|~|Moneycontrol/MC_Market/MC_Market_IndianIndices_ATF_728x90|~|Moneycontrol/MC_Market/MC_Market_IndianIndices_MTF_728x90|~|Moneycontrol/MC_Market/MC_Market_IndianIndices_BTF_728x90|~|Moneycontrol/MC_Market/MC_Market_IndianIndices_Gutter-></div>
														<div class="logo_fl for_nonpro_users">
								<a href="https://www.moneycontrol.com/" title="Moneycontrol">
									<img src="https://images.moneycontrol.com/images/common/headfoot/logo.png?impolicy=mchigh" alt="Moneycontrol" title="Moneycontrol" width="180" height="70" />
								</a>
								<a href="https://www.moneycontrol.com/promos/pro.php" class="be_apro mc_logo_be_a_pro" style=" display:none;" title="Be a Pro">Be a <span>PRO</span></a>
								<a href="javascript:;" title="Pro" class="be_apro mc_logo_only_pro" style=" cursor: default; display:none; font-weight: bold; border-bottom: none !important;">PRO</a>
							</div>
							<div class="logo_fl logo_home_with_pro for_mcpro_users" style="margin-top: 20px;">
								<a href="https://www.moneycontrol.com/pro-top-stories" title="Moneycontrol PRO">
									<img src="https://images.moneycontrol.com/images/common/header/mc_pro_logo_181x28.png?impolicy=mchigh" alt="Moneycontrol PRO" title="Moneycontrol PRO" width="181" height="28" />
								</a>
							</div>
							<div class="adright_top">
								<div>
									<div class="FR" id="Moneycontrol/MC_Market/MC_Market_Internal_728x90_div">
					<div id='Moneycontrol/MC_Market/MC_Market_Internal_728x90'>
						<script type='text/javascript'>
							setTimeout(function() {
								googletag.cmd.push(function() { googletag.display('Moneycontrol/MC_Market/MC_Market_Internal_728x90'); });
							}, 2000);
						</script>
					</div></div>								</div>
							</div>
						</div>
									</div>
			</div>
		</div>

					<!-- Site Navigation Element Schema -> Start -->
			<script type="application/ld+json">[{"@context":"https:\/\/schema.org","@type":"SiteNavigationElement","name":"Home","url":"https:\/\/www.moneycontrol.com\/"},{"@context":"https:\/\/schema.org","@type":"SiteNavigationElement","name":"Markets","url":"https:\/\/www.moneycontrol.com\/stocksmarketsindia\/"},{"@context":"https:\/\/schema.org","@type":"SiteNavigationElement","name":"News","url":"https:\/\/www.moneycontrol.com\/news\/"},{"@context":"https:\/\/schema.org","@type":"SiteNavigationElement","name":"Commodities","url":"https:\/\/www.moneycontrol.com\/commodity\/"},{"@context":"https:\/\/schema.org","@type":"SiteNavigationElement","name":"Mutual Funds","url":"https:\/\/www.moneycontrol.com\/mutualfundindia\/"},{"@context":"https:\/\/schema.org","@type":"SiteNavigationElement","name":"Personal Finance","url":"https:\/\/www.moneycontrol.com\/personal-finance\/"}]</script>
			<!-- End <- Site Navigation Element Schema -->
		
		<!-- Main navbar -> Start -->
		<div class="bottom_nav">
			<nav class="navbg">
				<div class="main_header_wrapper navmenu clearfix PR">
					<ul class="clearfix main_nav">
													<li cid="17" class="menu_l1 home ">
								<a href="https://www.moneycontrol.com/" title="Home"   >
									<svg xmlns="https://www.w3.org/2000/svg" width="13.566" height="11.531" viewBox="0 0 13.566 11.531">
										<g transform="translate(-2 -3)">
											<path d="M7.426,14.531v-4.07h2.713v4.07h3.391V9.1h2.035L8.783,3,2,9.1H4.035v5.426Z" transform="translate(0 0)"/>
										</g>
									</svg>
								</a>
							</li>
														<li  cid="0" class="menu_l1 active sub_nav">
									<a href="https://www.moneycontrol.com/stocksmarketsindia/" title="Markets"   >
										Markets												<span class="arrow down"></span>
																				</a>
									<!-- MC Mega Menu - 0 - Markets -> Start -->
	<div class="mega_menu">
		<div class="clearfix menu_boxpd">
			<ul class="market_menu clearfix">
									<!-- Markets - Set 1 -->
					<li>
						<ul class="market_listmenu">
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/stocksmarketsindia/" title="Home">
												HOME											</a>
																	</li>
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/markets/indian-indices/" title="Indian Indices">
												INDIAN INDICES											</a>
																	</li>
															<li class=" bold">
																				<span>
												STOCK ACTION											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/index.php" title="All Stats">
										All Stats										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/nsegainer/index.php" title="Top Gainers">
										Top Gainers										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/nseloser/index.php" title="Top Losers">
										Top Losers										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/onlybuyers.php" title="Only Buyers">
										Only Buyers										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/onlysellers.php" title="Only Sellers">
										Only Sellers										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/nsehigh/index.php" title="52 Week High">
										52 Week High										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/nselow/index.php" title="52 Week Low">
										52 Week Low										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/nse_pshockers/index.php" title="Price Shockers">
										Price Shockers										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/nse_vshockers/index.php" title="Volume Shockers">
										Volume Shockers										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/nsemact1/index.php" title="Most Active Stocks">
										Most Active Stocks										</a>
									</li>
													</ul>
					</li>
									<!-- Markets - Set 2 -->
					<li>
						<ul class="market_listmenu">
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/markets/global-indices/" title="Global Markets">
												GLOBAL MARKETS											</a>
																	</li>
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/us-markets" title="US Markets">
												US MARKETS														<sup class="new_tagtp">
															<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
																<g id="Layer_2" data-name="Layer 2">
																	<g id="Layer_1-2" data-name="Layer 1">
																		<rect class="newtag-1" width="28" height="15" rx="7.5"/>
																		<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
																		<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
																		<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
																	</g>
																</g>
															</svg>
														</sup>
																							</a>
																	</li>
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/india-investors-portfolio/" title="Big Shark Portfolios">
												BIG SHARK PORTFOLIOS														<sup class="new_tagtp">
															<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
																<g id="Layer_2" data-name="Layer 2">
																	<g id="Layer_1-2" data-name="Layer 1">
																		<rect class="newtag-1" width="28" height="15" rx="7.5"/>
																		<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
																		<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
																		<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
																	</g>
																</g>
															</svg>
														</sup>
																							</a>
																	</li>
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/economic-calendar" title="Economic Calendar">
												ECONOMIC CALENDAR														<sup class="new_tagtp">
															<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
																<g id="Layer_2" data-name="Layer 2">
																	<g id="Layer_1-2" data-name="Layer 1">
																		<rect class="newtag-1" width="28" height="15" rx="7.5"/>
																		<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
																		<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
																		<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
																	</g>
																</g>
															</svg>
														</sup>
																							</a>
																	</li>
															<li class=" bold">
																				<span>
												MARKET ACTION											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/stocksmarketsindia/?dashboard=l2" title="Dashboard">
										Dashboard										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/markets/fno-market-snapshot" title="F&O">
										F&O										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketstats/fii_dii_activity/index.php" title="FII & DII Activity">
										FII & DII Activity										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/stocks/marketinfo/upcoming_actions/home.html" title="Corporate Action">
										Corporate Action										</a>
									</li>
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/markets/earnings/" title="Earnings">
												EARNINGS											</a>
																	</li>
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/commodity/" title="Commodity">
												COMMODITY											</a>
																	</li>
													</ul>
					</li>
									<!-- Markets - Set 3 -->
					<li>
						<ul class="market_listmenu">
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/markets/premarket/" title="Pre Market">
												PRE MARKET														<sup class="new_tagtp">
															<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
																<g id="Layer_2" data-name="Layer 2">
																	<g id="Layer_1-2" data-name="Layer 1">
																		<rect class="newtag-1" width="28" height="15" rx="7.5"/>
																		<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
																		<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
																		<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
																	</g>
																</g>
															</svg>
														</sup>
																							</a>
																	</li>
															<li class=" bold">
																				<span>
												RESEARCH											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/markets/stock-advice/" title="Advice">
										Advice										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/broker-research/" title="Broker Research">
										Broker Research										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/markets/technicals/" title="Technicals">
										Technicals										</a>
									</li>
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/mccode/currencies/" title="Currency">
												CURRENCY											</a>
																	</li>
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/webinar" title="Webinar">
												WEBINAR											</a>
																	</li>
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/pro-interviews" title="Interview Series">
												INTERVIEW SERIES											</a>
																	</li>
													</ul>
					</li>
									<!-- Markets - Set 4 -->
					<li>
						<ul class="market_listmenu">
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/ipo/" title="IPO">
												IPO											</a>
																	</li>
															<li class=" bold">
																				<span>
												OTHERS											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/fixed-income/bonds/" title="Bonds">
										Bonds										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/cryptocurrency/" title="Cryptocurrency">
										Cryptocurrency										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mccode/tools/" title="Tools">
										Tools										</a>
									</li>
													</ul>
					</li>
							</ul>
		</div>
	</div>
<!-- End <- MC Mega Menu - 0 - Markets -->
								</li>
														<li  cid="3" class="menu_l1  sub_nav">
									<a href="https://www.moneycontrol.com/news/" title="News"   >
										News												<span class="arrow down"></span>
																				</a>
									<!-- MC Mega Menu - 3 - News -> Start -->
	<div class="mega_menu">
		<div class="clearfix menu_boxpd">
			<ul class="market_menu clearfix">
									<!-- News - Set 1 -->
					<li>
						<ul class="market_listmenu">
															<li class=" bold">
																				<a href="https://www.moneycontrol.com/news/" title="Homepage">
												HOMEPAGE											</a>

																	</li>
															<li class=" bold">
																				<span>
												BUSINESS											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/news/business/" title="Home">
										Home										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/business/economy/" title="Economy">
										Economy										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/companies.html" title="Companies">
										Companies										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/business/mutual-funds/" title="Mutual Funds">
										Mutual Funds										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/business/personal-finance/" title="Personal Finance">
										Personal Finance										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/business/ipo/" title="IPO">
										IPO										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/business/startups/" title="Startups">
										Startups										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/real-estate-property/" title="Real Estate">
										Real Estate										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/sme" title="SME">
										SME										</a>
									</li>
													</ul>
					</li>
									<!-- News - Set 2 -->
					<li>
						<ul class="market_listmenu">
															<li class=" bold">
																				<span>
												GEOGRAPHY											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/news/india/" title="India">
										India										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/world/" title="World">
										World										</a>
									</li>
															<li class=" bold">
																				<span>
												MARKETS											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/news/business/markets/" title="Home">
										Home										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/business/stocks/" title="Stocks">
										Stocks										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/technical-analysis.html" title="Technical Analysis">
										Technical Analysis										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/equity-research/" title="Equity Research">
										Equity Research										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/business/commodity/" title="Commodity">
										Commodity										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/currency.html" title="Currency">
										Currency										</a>
									</li>
													</ul>
					</li>
									<!-- News - Set 3 -->
					<li>
						<ul class="market_listmenu">
															<li class=" bold">
																				<span>
												SPECIAL											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/news/trends/" title="Trends">
										Trends										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/news-all/" title="Latest News">
										Latest News										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/opinion/" title="Opinion">
										Opinion										</a>
									</li>
															<li class=" bold">
																				<span>
												TECHNOLOGY											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/news/technology/" title="Personal Tech">
										Personal Tech										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/technology/auto" title="Auto">
										Auto										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/fintech/" title="Fintech">
										Fintech										</a>
									</li>
															<li class=" bold">
																				<span>
												MEDIA											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/podcast/" title="Podcast">
										Podcast										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/slideshows.html" title="Slideshows">
										Slideshows										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/infographic/" title="Infographics">
										Infographics										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/videos/" title="Videos">
										Videos										</a>
									</li>
													</ul>
					</li>
									<!-- News - Set 4 -->
					<li>
						<ul class="market_listmenu">
															<li class=" bold">
																				<span>
												OTHERS											</span>
																	</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/mc-learn.html" title="MC Learn">
										MC Learn										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/politics/" title="Politics">
										Politics										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/sports/" title="Sports">
										Sports										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/entertainment/" title="Entertainment">
										Entertainment										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/travel.html" title="Travel">
										Travel										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/lifestyle.html" title="Lifestyle">
										Lifestyle										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/health-and-fitness.html" title="Health and Fitness">
										Health and Fitness										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/education.html" title="Education">
										Education										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/science.html" title="Science">
										Science										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/books.html" title="Books">
										Books										</a>
									</li>
													</ul>
					</li>
							</ul>
		</div>
	</div>
<!-- End <- MC Mega Menu - 3 - News -->
								</li>
														<li  cid="25" class="menu_l1 ">
									<a href="https://www.moneycontrol.com/news/tags/mc-learn.html" title="MC Learn"   >
										MC Learn									</a>
																	</li>
														<li  cid="20" class="menu_l1 ">
									<a href="https://www.moneycontrol.com/news/technology-startups" title="Tech/Startups"   >
										Tech/Startups									</a>
																	</li>
														<li  cid="1" class="menu_l1  hoverblock">
									<a href="https://www.moneycontrol.com/india/bestportfoliomanager/investment-tool" title="Portfolio"   >
										Portfolio									</a>
																	</li>
														<li  cid="11" class="menu_l1 ">
									<a href="https://www.moneycontrol.com/commodity/" title="Commodities"   >
										Commodities									</a>
																	</li>
														<li  cid="2" class="menu_l1  sub_nav">
									<a href="https://www.moneycontrol.com/mutualfundindia/" title="Mutual Funds"   >
										Mutual Funds												<span class="arrow down"></span>
																				</a>
									<!-- MC Mega Menu - 2 - Mutual Funds -> Start -->
	<div class="mega_menu">
		<div class="clearfix menu_boxpd">
			<ul class="market_menu pf clearfix">
								<!-- Mutual Funds - Set 1 -->
				<li>
					<ul class="market_listmenu">
													<li class=" bold">
																		<span>
											EXPLORE										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/mutualfundindia/" title="Home">
										Home										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/find-fund/" title="Find Fund">
										Find Fund										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/best-funds/equity.html" title="Top Ranked Funds">
										Top Ranked Funds										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/performance-tracker/returns/large-cap-fund.html" title="Performance Tracker">
										Performance Tracker										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/performance-tracker/sip-returns/large-cap-fund.html" title="SIP Performance Tracker">
										SIP Performance Tracker										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mf/etf/" title="ETF Performance">
										ETF Performance										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/new-fund-offers" title="NFO">
										NFO										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/performance-tracker/all-categories" title="Top Performing Categories">
										Top Performing Categories										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutualfundindia/learn/" title="Learn">
										Learn										</a>
									</li>
												</ul>
				</li>
								<!-- Mutual Funds - Set 2 -->
				<li>
											<ul class="market_listmenu ">
							<li class=" bold">
																		<span>
											TOOLS										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/mf/returns-calculator.php" title="Returns Calculator">
										Returns Calculator										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/tools/lumpsum-sip-balancer" title="Lumpsum SIP Balancer">
										Lumpsum SIP Balancer										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/tools/delay-cost-calculator" title="Delay Cost Calculator">
										Delay Cost Calculator										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mf/sipcalculator.php" title="SIP Return">
										SIP Return										</a>
									</li>
													</ul>
									</li>
								<!-- Mutual Funds - Set 3 -->
				<li>
											<ul class="market_listmenu ">
							<li class=" bold">
																		<a href="https://www.moneycontrol.com/mutualfundindia/mutual-fund-discussion-forum/" title="MF Forum">
											MF FORUM										</a>
															</li>
													</ul>
											<ul class="market_listmenu  MT20 ">
							<li class=" bold">
																		<span>
											TRACK										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/portfolio-management/PORTFOLIO/returns" title="Your MF Investment" >
										Your MF Investment										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/mutual-funds/portfolio-management/WATCHLIST/returns" title="MF Prices" >
										MF Prices										</a>
									</li>
													</ul>
											<ul class="market_listmenu  MT20 ">
							<li class=" bold">
																		<a href="https://www.moneycontrol.com/mutual-fund/mc-30" title="MC30 Funds">
											MC 30													<sup class="new_tagtp">
														<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
															<g id="Layer_2" data-name="Layer 2">
																<g id="Layer_1-2" data-name="Layer 1">
																	<rect class="newtag-1" width="28" height="15" rx="7.5"/>
																	<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
																	<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
																	<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
																</g>
															</g>
														</svg>
													</sup>
																					</a>
															</li>
													</ul>
									</li>
							</ul>
		</div>
	</div>
<!-- End <- MC Mega Menu - 2 - Mutual Funds -->
								</li>
														<li  cid="8" class="menu_l1  sub_nav">
									<a href="https://www.moneycontrol.com/personal-finance/" title="Personal Finance"   >
										Personal Finance												<span class="arrow down"></span>
																				</a>
									<!-- MC Mega Menu - 8 - Personal Finance -> Start -->
	<div class="mega_menu">
		<div class="clearfix menu_boxpd">
			<ul class="market_menu pf clearfix">
								<!-- Personal Finance - Set 1 -->
				<li>
					<ul class="market_listmenu">
													<li class=" bold">
																		<span>
											EXPLORE										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/" title="Home">
										Home										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/investing/" title="Investing">
										Investing										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/insurance/" title="Insurance">
										Insurance										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/banking/" title="Banking">
										Banking										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/financialplanning/" title="Financial Planning">
										Financial Planning										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/real-estate-property/" title="Property">
										Property										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/" title="Tools">
										Tools										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/videos/" title="Video">
										Video										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/forum-topics/ask-the-expert/" title="Ask Expert">
										Ask Expert										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/explainer/" title="Explainer">
										Explainer										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/income-tax-filing" title="Tax Filing">
										Tax Filing										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/nps-national-pension-scheme" title="National Pension Scheme">
										NPS										</a>
									</li>
												</ul>
				</li>
								<!-- Personal Finance - Set 2 -->
				<li>
											<ul class="market_listmenu ">
							<li class=" bold">
																		<span>
											FIXED DEPOSIT										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/fixed-income/calculator/fixed-deposit-calculator.html" title="Fixed Deposit Interest Calculator">
										Fixed Deposit Interest Calculator										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/company-fixed-deposits.html" title="Corporate Deposits">
										Corporate Deposits										</a>
									</li>
													</ul>
											<ul class="market_listmenu  MT20 ">
							<li class=" bold">
																		<span>
											TAX										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/income-tax-filing/" title="Tax-filing Guide">
										Tax-filing Guide												<sup class="new_tagtp">
													<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
														<g id="Layer_2" data-name="Layer 2">
															<g id="Layer_1-2" data-name="Layer 1">
																<rect class="newtag-1" width="28" height="15" rx="7.5"/>
																<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
																<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
																<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
															</g>
														</g>
													</svg>
												</sup>
																				</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/income-tax-calculator" title="Income Tax Calculator">
										Income Tax Calculator										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/emergency-fund-calculator.html" title="Emergency Fund Calculator">
										Emergency Fund Calculator										</a>
									</li>
													</ul>
											<ul class="market_listmenu  MT20 ">
							<li class=" bold">
																		<span>
											LOANS & CREDIT CARDS										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/loans" title="Home">
										Home										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/carloan-emi-calculator.html" title="Car Loan Calculator">
										Car Loan Calculator										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/emi-calculator.html" title="Home Loan Calculator">
										Home Loan Calculator										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/education-loan-emi-calculator.html" title="Education Loan Calculator">
										Education Loan Calculator										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/credit-card-debt-payoff-calculator.html" title="Credit Card Debit Payoff Calculator">
										Credit Card Debit Payoff Calculator										</a>
									</li>
													</ul>
									</li>
								<!-- Personal Finance - Set 3 -->
				<li>
					<ul class="market_listmenu">
													<li class=" bold">
																		<span>
											TOOLS										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/provident-fund-calculator.html" title="Provident Fund Calculator">
										Provident Fund Calculator										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/asset-allocation-calculator.html" title="Assets Allocation Planning">
										Assets Allocation Planning										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/debt-reduction-plan-calculator.html" title="Debt Reduction Planner">
										Debt Reduction Planner										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/debt-evaluation-calculator.html" title="Debt Evaluation Calculator">
										Debt Evaluation Calculator										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/personal-finance/tools/current-expenses-calculator.html" title="Current Expense Calculator">
										Current Expense Calculator										</a>
									</li>
														<li class=" bold">
																		<a href="https://www.moneycontrol.com/mutual-fund/mc-30" title="MC30 Funds">
											MC 30													<sup class="new_tagtp">
														<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
															<g id="Layer_2" data-name="Layer 2">
																<g id="Layer_1-2" data-name="Layer 1">
																	<rect class="newtag-1" width="28" height="15" rx="7.5"/>
																	<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
																	<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
																	<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
																</g>
															</g>
														</svg>
													</sup>
																					</a>
															</li>
														<li class=" bold">
																		<a href="https://www.moneycontrol.com/personal-finance/health-insurance-ratings" title="MC Health Insurance Ratings">
											MC HEALTH INSURANCE RATINGS													<sup class="new_tagtp">
														<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
															<g id="Layer_2" data-name="Layer 2">
																<g id="Layer_1-2" data-name="Layer 1">
																	<rect class="newtag-1" width="28" height="15" rx="7.5"/>
																	<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
																	<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
																	<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
																</g>
															</g>
														</svg>
													</sup>
																					</a>
															</li>
												</ul>
				</li>
							</ul>
		</div>
		<!-- Upcoming Chat -> Start -->
			<div class="upcoming_expert_chat_box expert_box clearfix" style="display:none;">
				<div class="expert_left"></div>
				<div class="expert_right" style="width:auto !important;">
					<a href="https://www.moneycontrol.com/news/mgmtinterviews/chats/detail_new.php?type=upcoming" title="Upcoming Chat">Upcoming Chat</a> | <a href="https://www.moneycontrol.com/news/mgmtinterviews/chats/archives_new.php" title="Previous Transcripts">Previous Transcripts</a>
				</div>
			</div>
		<!-- End <- Upcoming Chat -->
		<!-- Live Chat -> Start -->
			<div class="live_expert_chat_box expert_box clearfix" style="display:none;">
				<div class="expert_left"></div>
				<div class="expert_right" style="width:auto !important;">
					<a href="https://www.moneycontrol.com/news/mgmtinterviews/chats/detail_new.php" title="All Schedule">All Schedule</a> | <a href="https://www.moneycontrol.com/news/mgmtinterviews/chats/archives_new.php" title="Previous Transcript">Previous Transcript</a>
				</div>
			</div>
		<!-- End <- Live Chat -->
	</div>
<!-- End <- MC Mega Menu - 8 - Personal Finance -->
								</li>
														<li  cid="4" class="menu_l1  sub_nav">
									<a href="https://mmb.moneycontrol.com/" title="Forum"   target="_blank"  >
										Forum												<span class="arrow down"></span>
																				</a>
									<!-- MC Mega Menu - 4 - Forum -> Start -->
	<div class="mega_menu">
		<div class="clearfix menu_boxpd">
			<ul class="market_menu pf clearfix">
								<!-- Forum - Set 1 -->
				<li>
					<ul class="market_listmenu">
														<li  class=" bold">
																				<span>
												EXPLORE FORUM											</span>
																	</li>
															<li class="">
										<a href="https://mmb.moneycontrol.com/" title="Homepage" >
										Homepage										</a>
									</li>
																<li class="">
										<a href="https://mmb.moneycontrol.com/membership-rules/" title="Membership Rules" >
										Membership Rules										</a>
									</li>
																<li class="">
										<a href="https://mmb.moneycontrol.com/forum-topics/" title="Forum Topics" >
										Forum Topics										</a>
									</li>
																<li class="">
										<a href="https://mmb.moneycontrol.com/forum-topics/ask-the-expert/" title="Ask the Expert" >
										Ask the Expert										</a>
									</li>
																<li class="">
										<a href="https://mmb.moneycontrol.com/top-boarders/" title="Top Boarders" >
										Top Boarders										</a>
									</li>
															<li id="forum_user_profile" class=" bold">
									<a href="javascript:;" title="User Profile" class="linkSignIn" data-toggle="modal" data-target="#LoginModal">USER PROFILE</a>
								</li>
											</ul>
				</li>
								<!-- Forum - Set 2 -->
				<li>
											<ul class="market_listmenu ">
							<li class=" bold">
																		<span>
											FORUM TOPICS										</span>
															</li>
																<li>
										<a href="https://mmb.moneycontrol.com/forum-topics/latest-threads.html" title="Latest Threads">
										Latest Threads										</a>
									</li>
																<li>
										<a href="https://mmb.moneycontrol.com/forum-topics/stocks-1.html" title="Stocks">
										Stocks										</a>
									</li>
																<li>
										<a href="https://mmb.moneycontrol.com/forum-topics/market-view/index-246280.html" title="Index">
										Index										</a>
									</li>
																<li>
										<a href="https://mmb.moneycontrol.com/forum-topics/commodity/gold-509313.html" title="Gold">
										Gold										</a>
									</li>
																<li>
										<a href="https://mmb.moneycontrol.com/forum-topics/personal-finance-5.html" title="Personal Finance">
										Personal Finance										</a>
									</li>
																<li>
										<a href="https://mmb.moneycontrol.com/forum-topics/market-view/just-posted-509249.html" title="Just Posted">
										Just Posted										</a>
									</li>
													</ul>
											<ul class="market_listmenu  MT20 ">
							<li class=" bold">
																		<a href="https://www.moneycontrol.com/mutualfundindia/mutual-fund-discussion-forum/" title="MF Forum">
											MF FORUM										</a>
															</li>
													</ul>
									</li>
								<!-- Forum - Set 3 -->
				<li>
											<ul class="market_listmenu ">
							<li class=" bold">
																		<span>
											POLLS										</span>
															</li>
																<li>
										<a href="https://mmb.moneycontrol.com/poll/" title="Latest Polls" >
										Latest Polls										</a>
									</li>
																<li>
										<a href="https://mmb.moneycontrol.com/poll/historical-polls/" title="Historical Polls" >
										Historical Polls										</a>
									</li>
																<li>
										<a href="https://mmb.moneycontrol.com/poll/market-sentiments/" title="Market Sentiments" >
										Market Sentiments										</a>
									</li>
													</ul>
											<ul class="market_listmenu  MT20 ">
							<li class=" bold">
																		<span>
											SUPPORT										</span>
															</li>
																<li>
										<a href="https://mmb.moneycontrol.com/faq/" title="FAQs" >
										FAQs										</a>
									</li>
																<li>
										<a href="https://mmb.moneycontrol.com/code-of-conduct/" title="Code of Conduct" >
										Code of Conduct										</a>
									</li>
																<li>
										<a href="https://mmb.moneycontrol.com/forum-topics/feedback/about-mmb-160978.html" title="Feedback" >
										Feedback										</a>
									</li>
																<li>
										<a href="mailto:forum@moneycontrol.com" title="Write to us"  target="_blank" >
										Write to us										</a>
									</li>
													</ul>
									</li>
							</ul>
		</div>
	</div>
<!-- End <- MC Mega Menu - 4 - Forum -->
								</li>
														<li  cid="5" class="menu_l1  sub_nav">
									<a href="https://www.moneycontrol.com/video-shows/" title="Videos"   >
										Videos												<span class="arrow down"></span>
																				</a>
									<!-- MC Mega Menu - 5 - Videos -> Start -->
	<div class="mega_menu">
		<div class="clearfix menu_boxpd">

			<!-- Video List -> Start -->
				<div class="mega_menu_video_list_block" style="display:none;"></div>
			<!-- End <- Video List -->

			<ul class="market_menu pf clearfix">
								<!-- Media - Set 1 -->
				<li>
					<ul class="market_listmenu">
													<li class=" bold">
																		<span>
											VIDEOS										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/video-shows/" title="Homepage">
										Homepage										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/videos/" title="Videos on Demand">
										Videos on Demand										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/markets-with-santo-&-cj/" title="Markets with Santo & CJ">
										Markets with Santo & CJ										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/morning-trade/" title="Morning Trade">
										Morning Trade										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/bits-to-billions/" title="Bits to Billions">
										Bits to Billions										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/ideas-for-profit/" title="Ideas for Profit">
										Ideas for Profit										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/managing-market-turns/" title="Managing Market Turns">
										Managing Market Turns										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/bajar-gupshup/" title="Bajar Gupshup">
										Bajar Gupshup										</a>
									</li>
												</ul>
				</li>
								<!-- Media - Set 2 -->
				<li>
											<ul class="market_listmenu ">
							<li class=" bold">
																		<span>
											PODCAST										</span>
															</li>
																<li>
										<a href="https://www.moneycontrol.com/podcast/" title="Homepage">
										Homepage										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/news/tags/podcast.html" title="Podcast on Demand">
										Podcast on Demand										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/the-market-podcast/" title="The Market Podcast">
										The Market Podcast										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/future-wise/" title="Future Wise">
										Future Wise										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/simply-save/" title="Simply Save">
										Simply Save										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/stock-picks-of-the-day/" title="Stock Picks of the Day">
										Stock Picks of the Day										</a>
									</li>
																<li>
										<a href="https://www.moneycontrol.com/shows/coronavirus-essential/" title="Coronavirus Essential">
										Coronavirus Essential										</a>
									</li>
													</ul>
									</li>
								<!-- Media - Set 3 -->
				<li>
											<ul class="market_listmenu ">
							<li class=" bold">
																		<span>
											LIVE TV										</span>
															</li>
																<li>
										<a href="https://hindi.moneycontrol.com/tv/" title="Hindi">
										Hindi										</a>
									</li>
																<li>
										<a href="https://gujarati.moneycontrol.com/tv/" title="Gujarati">
										Gujarati										</a>
									</li>
													</ul>
									</li>
							</ul>
		</div>
	</div>
<!-- End <- MC Mega Menu - 5 - Videos -->
								</li>
														<li  cid="18" class="menu_l1  sub_nav">
									<a href="javascript:;" title="Invest Now"   >
										Invest Now												<span class="arrow down"></span>
																				</a>
									<!-- MC Mega Menu - 18 - Invest Now -> Start -->
	<div class="mega_menu investNW">
		<div class="clearfix subscribe_wrap">
			<div>
				<div class="menu-logo-top">
					<a href="https://www.moneycontrol.com" title="Moneycontrol" ><img src="https://images.moneycontrol.com/images/common/headfoot/moneycontrol-logo_234x48.png" alt="Moneycontrol  PRO" title="Moneycontrol" class="logo1" width="234" height="48" /></a>
				</div>

				<div class="header_subscbx clearfix invst-menu">
					<div class="subc_fl">
													<ul class="subc_list first">
								<div class="invest-top-sec">
									<div><h3 class="heading3">INVEST IN CURATED STOCK & ETF PORTFOLIOS</h3></div>
									<div class="rgt-sd">
										<p>
											Powered By 
																						<svg width="72px" height="24px" viewBox="0 0 386 98" version="1.1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink">
												<defs><polygon id="path-1" points="0 0 386.538462 0 386.538462 100 0 100"></polygon></defs>
												<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
													<g id="_standard_blue" transform="translate(-1.000000, -1.000000)">
														<g id="Group-3-Copy-6">
															<mask id="mask-2" fill="white"><use xlink:href="#path-1"></use></mask>
															<g id="Clip-2"></g>
															<path d="M380.108022,46.3907979 C379.960817,42.7661349 377.039076,39.5742124 372.654601,39.5742124 C367.832238,39.5742124 365.055838,42.6200388 364.61795,46.3889486 L380.108022,46.3889486 L380.108022,46.3907979 Z M372.801806,34.0650946 C380.691253,34.0650946 386.538462,39.8645553 386.538462,47.840663 C386.538462,48.4231982 386.538462,49.434775 386.391256,49.871214 C386.391256,50.5942973 385.660821,51.1768324 385.075728,51.1768324 L364.178198,51.1768324 C364.178198,55.2379343 367.979443,59.297187 373.239695,59.297187 C376.746529,59.297187 378.792494,57.9934179 380.691253,56.8338956 C381.27821,56.3974566 381.863303,56.2513605 382.446533,56.9781424 L384.196224,59.7354753 C384.783181,60.3124625 384.930386,60.8912989 384.052746,61.7641769 C381.859576,63.6504811 377.914853,65.534936 372.801806,65.534936 C363.593104,65.534936 357.749622,58.4298569 357.749622,49.871214 C357.749622,41.3162698 363.596831,34.0650946 372.801806,34.0650946 Z M331.888114,62.4872602 C331.450226,62.1987666 331.00861,61.6180808 331.303021,60.8912989 L332.618549,58.1376647 C332.909233,57.5588282 333.786873,57.2703346 334.515445,57.7049243 C336.272589,58.7183505 338.460168,59.8778728 341.967003,59.8778728 C344.450856,59.8778728 345.913589,58.7146519 345.913589,56.9781424 C345.913589,54.9494408 343.575079,53.6438224 339.485014,51.7575182 C334.806129,49.7251179 331.303021,47.2636759 331.303021,42.3315452 C331.303021,38.5589369 333.930352,34.207492 341.238431,34.207492 C345.475701,34.207492 348.544647,35.5131104 350.003654,36.3841391 C350.735953,36.9629756 351.030363,37.8340043 350.588748,38.5589369 L349.567629,40.5876385 C349.129741,41.4586672 348.2521,41.4586672 347.667007,41.1701737 C345.622906,40.299145 343.575079,39.7221578 341.238431,39.7221578 C338.609237,39.7221578 337.440913,41.0240775 337.440913,42.3315452 C337.440913,44.2141508 339.628492,45.3736731 342.55396,46.6829901 C348.104895,49.0001853 352.345892,51.0307363 352.345892,56.5417034 C352.345892,61.1834911 348.2521,65.2445931 341.529114,65.2445931 C337.001161,65.534936 333.639668,63.6504811 331.884387,62.4872602 L331.888114,62.4872602 Z M310.696174,60.1663663 C313.766984,60.1663663 316.83593,57.9934179 317.71357,56.5435527 L317.71357,51.6114221 C317.273819,51.3210792 314.931581,50.5942973 312.160772,50.5942973 C308.65021,50.5942973 305.873811,52.4843001 305.873811,55.5264279 C306.021016,58.1376647 307.630955,60.1663663 310.696174,60.1663663 Z M311.722883,45.8101121 C314.788103,45.8101121 317.857049,46.6792915 317.857049,46.6792915 C318.004254,41.8951062 316.83593,39.8682539 313.034685,39.8682539 C309.527851,39.8682539 306.168221,40.8816801 304.562009,41.3162698 C303.684368,41.4586672 303.099275,40.8816801 302.808591,40.0106514 L302.221635,37.5455107 C302.078156,36.5302352 302.516045,36.0956455 303.24648,35.801604 C303.827847,35.6592065 308.068843,34.0650946 313.619779,34.0650946 C323.264506,34.0650946 324.142146,39.8645553 324.142146,47.2599772 L324.142146,63.2121928 C324.089972,63.9907556 323.463885,64.6121264 322.679412,64.6639073 L320.488106,64.6639073 C319.90115,64.6639073 319.610466,64.3754137 319.316056,63.6504811 L318.589347,61.6180808 C316.109222,64.0739749 312.738412,65.4332235 309.237167,65.3869906 C303.537163,65.3869906 299.445235,61.6180808 299.445235,55.3840305 C299.59244,50.0173101 303.976915,45.8138107 311.722883,45.8138107 L311.722883,45.8101121 Z M283.371932,34.0650946 C288.050818,34.0650946 291.555789,35.801604 294.332188,39.2820202 C294.917282,40.0106514 294.76635,40.8779814 294.041505,41.4586672 L291.702994,43.6371636 C290.825354,44.3602469 290.24026,43.7795611 289.800508,43.3449714 C288.488706,41.8951062 286.00299,40.299145 283.519137,40.299145 C278.406091,40.299145 274.310436,44.506343 274.310436,49.7251179 C274.310436,55.0918382 278.258885,59.297187 283.228454,59.297187 C287.173177,59.297187 288.779389,57.1242385 290.387465,55.5264279 C290.968832,54.9457421 291.702994,54.9457421 292.429702,55.3803318 L294.479393,56.9781424 C295.207965,57.5588282 295.500512,58.2837608 295.06076,59.1529402 C292.576908,62.9218499 288.488706,65.3869906 283.228454,65.3869906 C274.752051,65.3869906 267.736518,58.7183505 267.736518,49.7251179 C267.883723,41.0240775 275.042734,34.0650946 283.375659,34.0650946 L283.371932,34.0650946 Z M253.856385,20.7204172 C253.856385,19.9973339 254.439615,19.2724013 255.315392,19.2724013 L258.969431,19.2724013 C259.752041,19.3260315 260.374401,19.9437037 260.428439,20.7204172 L260.428439,63.3619875 C260.374401,64.138701 259.752041,64.7563732 258.969431,64.8100034 L255.319118,64.8100034 C254.512286,64.8100034 253.856385,64.1590435 253.856385,63.3582889 L253.856385,20.7204172 Z M237.781218,20.7204172 C237.781218,19.9973339 238.366312,19.2724013 239.242089,19.2724013 L242.896129,19.2724013 C243.678738,19.3260315 244.301099,19.9437037 244.355136,20.7204172 L244.355136,63.3619875 C244.301099,64.138701 243.678738,64.7563732 242.896129,64.8100034 L239.245816,64.8100034 C238.438983,64.8100034 237.781218,64.1590435 237.781218,63.3582889 L237.781218,20.7204172 Z M215.27934,60.1663663 C218.346423,60.1663663 221.413506,57.9934179 222.291146,56.5435527 L222.291146,51.6114221 C221.855121,51.3210792 219.514746,50.5942973 216.738347,50.5942973 C213.231512,50.5942973 210.456976,52.4843001 210.456976,55.5264279 C210.456976,58.1376647 212.063189,60.1663663 215.27934,60.1663663 Z M216.15698,45.8101121 C219.224063,45.8101121 222.291146,46.6792915 222.291146,46.6792915 C222.438351,41.8951062 221.270027,39.8682539 217.468782,39.8682539 C213.963811,39.8682539 210.604181,40.8816801 208.997969,41.3162698 C208.118466,41.4586672 207.533372,40.8816801 207.242689,40.0106514 L206.655732,37.5455107 C206.512253,36.5302352 206.946415,36.0956455 207.680577,35.801604 C208.263807,35.6592065 212.502941,34.0650946 218.053876,34.0650946 C227.698603,34.0650946 228.721585,39.8645553 228.721585,47.2599772 L228.721585,63.2121928 C228.667548,63.9907556 228.045187,64.6102771 227.260714,64.6639073 L225.067545,64.6639073 C224.484315,64.6639073 224.193632,64.3754137 223.755743,63.6504811 L223.021581,61.6180808 C220.541455,64.0739749 217.172509,65.4313742 213.673128,65.3869906 C207.97126,65.3869906 203.881196,61.6180808 203.881196,55.3840305 C204.028401,50.0173101 208.411012,45.8138107 216.15698,45.8138107 L216.15698,45.8101121 Z M151.861906,36.238043 C151.861906,35.5131104 152.443273,34.7900272 153.320913,34.7900272 L154.781784,34.7900272 C155.512219,34.7900272 155.953834,35.0785207 156.097312,35.6592065 L156.974953,38.268594 C157.55632,37.5455107 160.772471,34.0650946 166.61968,34.0650946 C171.002291,34.0650946 173.631486,35.801604 175.824655,38.8511291 C176.702295,37.9801004 180.20913,34.0650946 186.050749,34.0650946 C195.261314,34.0650946 197.597962,40.4452411 197.597962,48.2771021 L197.597962,63.3582889 C197.597962,64.1590435 196.94206,64.8100034 196.135228,64.8100034 L192.484915,64.8100034 C191.607274,64.8100034 191.020317,64.2293176 191.020317,63.3582889 L191.020317,47.9867592 C191.020317,43.2007246 189.123422,40.299145 185.031493,40.299145 C180.499813,40.299145 178.308508,43.3449714 177.723414,43.7795611 C177.870619,44.3602469 178.014097,46.2447018 178.014097,47.840663 L178.014097,63.3619875 C178.014097,64.0813722 177.430867,64.8100034 176.702295,64.8100034 L172.90105,64.8100034 C172.02341,64.8100034 171.442043,64.2293176 171.442043,63.3582889 L171.442043,47.9867592 C171.442043,43.0546285 169.686763,40.299145 165.447629,40.299145 C160.919676,40.299145 158.581165,43.6371636 158.290482,44.6542884 L158.290482,63.3582889 C158.238308,64.1368517 157.61222,64.7582225 156.827748,64.8100034 L153.177435,64.8100034 C152.368739,64.8100034 151.714701,64.1590435 151.714701,63.3582889 L151.714701,36.238043 L151.861906,36.238043 Z M124.24139,62.4872602 C123.805365,62.1987666 123.36375,61.6180808 123.65816,60.8912989 L124.971826,58.1376647 C125.266236,57.5588282 126.143876,57.2703346 126.874311,57.7049243 C128.624002,58.7183505 130.819035,59.8778728 134.324006,59.8778728 C136.809722,59.8778728 138.268729,58.7146519 138.268729,56.9781424 C138.268729,54.9494408 135.932081,53.6438224 131.840153,51.7575182 C127.164995,49.7251179 123.65816,47.2636759 123.65816,42.3315452 C123.65816,38.5589369 126.287354,34.207492 133.593571,34.207492 C137.830841,34.207492 140.90165,35.5131104 142.360657,36.3841391 C143.091093,36.9629756 143.385503,37.8340043 142.947614,38.5589369 L141.922769,40.5876385 C141.486744,41.4586672 140.610967,41.4586672 140.02401,41.1701737 C137.981772,40.299145 135.932081,39.7221578 133.593571,39.7221578 C130.96624,39.7221578 129.794189,41.0240775 129.794189,42.3315452 C129.794189,44.2141508 131.987358,45.3736731 134.910963,46.6829901 C140.463762,49.0001853 144.699168,51.0307363 144.699168,56.5417034 C144.699168,61.1834911 140.610967,65.2445931 133.884254,65.2445931 C129.358164,65.534936 125.996671,63.6504811 124.24139,62.4872602 Z M43.5711497,13.3786254 L60.3748877,21.4823361 C61.2059441,21.8836381 61.5543916,22.8767217 61.1481801,23.7015175 C60.9897949,24.0269974 60.7307885,24.2932992 60.4047014,24.4578885 L44.1040693,32.7391337 C43.6214602,32.9758464 43.0550002,32.9758464 42.5723912,32.7391337 L25.7705165,24.6391216 C24.9394601,24.2378197 24.5910126,23.2428867 24.9953607,22.4180909 C25.1537459,22.092611 25.4146157,21.8300079 25.7388395,21.6654186 L42.0394716,13.382324 C42.5220806,13.143762 43.0885406,13.1419127 43.5711497,13.3786254 Z M43.6922677,44.1549726 L83.4655865,23.9474768 C84.2854628,23.5276816 84.6096866,22.5272007 84.1848416,21.7098022 C84.0208664,21.3898702 83.7562699,21.1346643 83.4301827,20.9774723 L43.9997214,1.96463579 C43.5189757,1.72607379 42.9543791,1.72607379 42.4736334,1.96463579 L2.70031466,22.1628851 C1.87857497,22.5826802 1.5524878,23.5831611 1.97360609,24.3987103 C2.13944471,24.7204916 2.40590452,24.9812454 2.73385505,25.1384374 L42.1810866,44.1475754 C42.6562422,44.3805894 43.2152488,44.3805894 43.6922677,44.1475754 L43.6922677,44.1549726 Z M77.1134083,58.7146519 C76.8134081,65.610758 73.0363869,71.8928907 67.0661965,75.4287863 C61.530168,78.2526947 57.0394817,75.3585123 57.0432084,68.9469274 C57.3394819,62.0526705 61.1165031,55.7668392 67.0904202,52.2309436 C72.6245854,49.4070352 77.1134083,52.3141629 77.1134083,58.7109532 L77.1134083,58.7146519 Z M88.8525466,76.0631024 L88.8525466,31.1191313 C88.8450932,30.1907737 88.0811175,29.4436493 87.1457132,29.4510466 C86.87739,29.4528959 86.6127936,29.517622 86.3742841,29.639677 L46.2469279,50.1282692 C45.6860579,50.4093655 45.3338838,50.9789554 45.3320204,51.6021755 L45.3320204,96.5461466 C45.3394738,97.4745041 46.1034495,98.2216285 47.0388539,98.2142313 C47.307177,98.2123819 47.5717735,98.1476558 47.8102829,98.0256008 L87.9506827,77.538858 C88.5059625,77.2522137 88.8525466,76.6844731 88.8525466,76.0631024 Z M26.7990887,80.0095466 L8.73758581,71.3343967 C7.90466599,70.934944 7.5543552,69.9437097 7.95311323,69.1170646 C7.98851698,69.0486399 8.02578408,68.9820644 8.06864126,68.9191876 L17.1096411,55.6244418 C17.638834,54.8514269 18.6990832,54.6498513 19.4779657,55.1750575 C19.7518789,55.3599893 19.9661648,55.6188938 20.092873,55.9221819 L29.1357362,77.8772831 C29.5084073,78.7168734 29.1245561,79.6988612 28.2785928,80.0687248 C27.8015738,80.2776977 27.2537474,80.2536565 26.7990887,80.005848 L26.7990887,80.0095466 Z" id="Fill-1" fill="#1F7CE0" mask="url(#mask-2)"></path>
														</g>
													</g>
												</g>
											</svg>
										</p>
									</div>
								</div>
																		<li class="" style="min-height:82px">
											<a href="https://www.moneycontrol.com/msite/smallcase" title="Invest in smallcases" onclick="javascript:GAEventTracker( 'Invest Now CTA', 'invest in mutual fund', 'Invest in smallcases' );"  >
												<span class="tit-txt1">Invest in smallcases</span>
																										<p class="tit-txt2">Learn, discover & invest in smallcases across different types to build your long term portfolio.</p>
																								<p class="MT5"><span class="mcp_btn_blue_tp" title="Invest Now">Invest Now</span></p>
											</a>
										</li>
																		<li class="sepInvsli" style="">
											<a href="https://www.moneycontrol.com/msite/smallcase#smallcases_managers" title="Top and trending managers" onclick="javascript:GAEventTracker( 'Invest Now CTA', 'invest in mutual fund', 'Top and trending managers' );"  style="padding-bottom: 46px !important;"  >
												<span class="tit-txt1">Top and trending managers</span>
																										<p class="tit-txt2">Explore from India`s leading investment managers and advisors curating their strategies as smallcases.</p>
																								<p class="MT5"><span class="mcp_btn_blue_tp" title="Invest Now">Invest Now</span></p>
											</a>
										</li>
															</ul>
											</div>

					<div class="subc_fr">
													<ul class="subc_list">

								<div class="invest-top-sec">
									<div><h3 class="heading3">Global Investment</h3></div>
									<div class="rgt-sd">
										<p>
											Powered By 
											<img src="https://images.moneycontrol.com/images/common/headfoot/stockal_logo_144x48.png" alt="stockal" title="stockal" class="logo2" width="144" height="48" />
										</p>
									</div>
								</div>

																		<li class="">
											<a href="https://www.moneycontrol.com/msite/global-investing" title="Invest in U.S. Stocks From India" onclick="javascript:GAEventTracker( 'Invest Now CTA', 'invest in curated stock & etf portfolios', 'Invest in U.S. Stocks From India' );">
												<span class="tit-txt1">Invest in U.S. Stocks From India</span>
																										<p class="tit-txt2">Diversify your portfolio by investing in Global brands.</p>
																								<p class="MT5"><span class="mcp_btn_blue_tp" title="Invest Now">Invest Now</span></p>
											</a>
										</li>
																		<li class="sepInvsli">
											<a href="https://www.moneycontrol.com/msite/global-investing#curatedPortfolios" title="Invest in Stacks (Expert curated portfolio using <br />U.S. Stocks)" onclick="javascript:GAEventTracker( 'Invest Now CTA', 'invest in curated stock & etf portfolios', 'Invest in Stacks (Expert curated portfolio using <br />U.S. Stocks)' );">
												<span class="tit-txt1">Invest in Stacks (Expert curated portfolio using <br />U.S. Stocks)</span>
																										<p class="tit-txt2">Pre-configured baskets of stocks & ETFs that you can invest <br />in with a single click. Developed by hedge funds, global <br />asset management companies, experienced wealth <br />management firms and portfolio managers.</p>
																								<p class="MT5"><span class="mcp_btn_blue_tp" title="Invest Now">Invest Now</span></p>
											</a>
										</li>
															</ul>
											</div>
				</div>

			</div>
		</div>
	</div>
<!-- End <- MC Mega Menu - 18 - Invest Now -->
								</li>
														<li  cid="16" class="menu_l1  sub_nav">
									<a href="https://www.moneycontrol.com/subscription/" title="Subscription"   target="_blank"  onclick="javascript:GAEventTracker( 'Pro-Discount', 'Menu', document.title );">
										Subscription												<span class="arrow down"></span>
																				</a>
									<!-- MC Mega Menu - 16 - Subscription -> Start -->
	<div class="mega_menu">
		<div class="clearfix subscribe_wrap">
			<div>
				<div class="header_subscbx clearfix">
					<div class="subc_fl">
						<p>
							<a href="https://www.moneycontrol.com/subscription/" title="Gamechangers">
								<img src="https://images.moneycontrol.com/images/common/headfoot/gc_logo_57x22.png" alt="Gamechangers" title="Gamechangers" width="57" height="22" />
							</a>
						</p>
												<ul class="subc_list first">
															<li>
									<a href="https://www.moneycontrol.com/gamechangers/ambareeshbaliga" title="Ambareesh Baliga">
										<p><span class="subc_link UC">AMBAREESH BALIGA</span></p>
										<p>Fundamental, Stock Ideas, Multibaggers & Insights</p>
										<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
									</a>
								</li>
															<li>
									<a href="https://www.moneycontrol.com/gamechangers/cknarayan" title="CK Narayan">
										<p><span class="subc_link UC">CK NARAYAN</span></p>
										<p>Stock & Index F&O Trading Calls & Market Analysis</p>
										<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
									</a>
								</li>
															<li>
									<a href="https://www.moneycontrol.com/gamechangers/?mc_source=MC_Eng_DT_Sudarshan_Sukhani_Subscription" title="Sudarshan Sukhani">
										<p><span class="subc_link UC">SUDARSHAN SUKHANI</span></p>
										<p>Technical Call, Trading Calls & Insights</p>
										<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
									</a>
								</li>
															<li>
									<a href="https://www.moneycontrol.com/gamechangers/tgnanasekar" title="T Gnanasekar">
										<p><span class="subc_link UC">T GNANASEKAR</span></p>
										<p>Commodity Trading Calls & Market Analysis</p>
										<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
									</a>
								</li>
															<li>
									<a href="https://www.moneycontrol.com/gamechangers/mecklai" title="Mecklai Financials">
										<p><span class="subc_link UC">MECKLAI FINANCIALS</span></p>
										<p>Currency Derivatives Trading Calls & Insights</p>
										<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
									</a>
								</li>
															<li>
									<a href="https://www.moneycontrol.com/gamechangers/shubham-agarwal" title="Shubham Agarwal">
										<p><span class="subc_link UC">SHUBHAM AGARWAL</span></p>
										<p>Options Trading Advice and Market Analysis</p>
										<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
									</a>
								</li>
															<li>
									<a href="https://www.moneycontrol.com/gamechangers/marketsmith-india?mc_source=MC_Eng_DT_MarketSmith_Subscription" title="Market Smith India">
										<p><span class="subc_link UC">MARKET SMITH INDIA</span></p>
										<p>Model portfolios, Investment Ideas, Guru Screens and Much More</p>
										<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
									</a>
								</li>
															<li>
									<a href="https://www.moneycontrol.com/gamechangers/tradersmith?mc_source=MC_Eng_DT_TraderSmith_Subscription " title="TraderSmith">
										<p><span class="subc_link UC">TraderSmith</span></p>
										<p>Proprietary system driven Rule Based Trading calls</p>
										<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
									</a>
								</li>
													</ul>
											</div>
					<div class="subc_fr">
						<p class="for_nonpro_users">
							<a href="https://www.moneycontrol.com/promos/pro.php" title="Moneycontrol PRO" >
								<img src="https://images.moneycontrol.com/images/common/headfoot/MC_Pro_Logo.png" alt="Moneycontrol  PRO" title="Moneycontrol  PRO" width="153" height="25" />
							</a>
						</p>
						<p class="for_mcpro_users">
							<a href="https://www.moneycontrol.com/pro-top-stories" title="Moneycontrol PRO">
								<img src="https://images.moneycontrol.com/images/common/headfoot/MC_Pro_Logo.png" alt="Moneycontrol  PRO" title="Moneycontrol  PRO" width="153" height="25" />
							</a>
						</p>
						<ul class="subc_list MT10">
							<li class="for_nonpro_users">
								<a href="https://www.moneycontrol.com/promos/pro.php" title="Moneycontrol PRO">
									<p>Curated markets data, exclusive trading recommendations, Independent equity analysis & actionable investment ideas</p>
									<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
								</a>
							</li>
							<li class="for_mcpro_users">
								<a href="https://www.moneycontrol.com/pro-top-stories" title="Moneycontrol PRO">
									<p>Curated markets data, exclusive trading recommendations, Independent equity analysis & actionable investment ideas</p>
									<p class="MT5"><span class="mcp_btn_blue_tp" title="Explore">Explore</span></p>
								</a>
							</li>
						</ul>
																				<ul class="subc_list">
																	<li>
										<a href="https://www.moneycontrol.com/stock-reports" title="Stock reports by Thomson Reuters">
											<p><span class="subc_link black">STOCK REPORTS BY THOMSON REUTERS</span></p>
											<p>Details stock report and investment recommendation</p>
											<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
										</a>
									</li>
																	<li>
										<a href="https://poweryourtrade.moneycontrol.com/plus/login/login.php" title="Power Your trade">
											<p><span class="subc_link black">POWER YOUR TRADE</span></p>
											<p>Technical and Commodity Calls</p>
											<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
										</a>
									</li>
																	<li>
										<a href="https://investmentwatch.moneycontrol.com/" title="Investment Watch">
											<p><span class="subc_link black">INVESTMENT WATCH</span></p>
											<p>Set price, volume and news alerts</p>
											<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
										</a>
									</li>
																	<li>
										<a href="https://www.moneycontrol.com/gamechangers/stockaxis" title="StockAxis Emerging Market Leaders">
											<p><span class="subc_link black">STOCKAXIS EMERGING MARKET LEADERS</span></p>
											<p>15-20 High Growth Stocks primed for price jumps</p>
											<p class="MT5"><span class="mcp_btn_blue_tp" title="Subscribe">Subscribe</span></p>
										</a>
									</li>
															</ul>
											</div>
				</div>
			</div>
		</div>
	</div>
<!-- End <- MC Mega Menu - 16 - Subscription -->
								</li>
														<li  id="menu_l1_be_a_pro"  cid="12" class="menu_l1  bapro proMenu">
									<a href="https://www.moneycontrol.com/promos/pro.php" title="Be a PRO"   onclick="javascript:GAEventTracker( 'Pro-Discount', 'Menu', document.title );">
										Be a PRO									</a>
																	</li>
											</ul>

					<!-- Floating search menu -> Start -->
					<div class="search_float">
						<a href="javascript:void(0)" title="Submit" class="btn_black_float top_search_btn">
							<svg version="1.1" id="Capa_1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192.904 192.904" style="enable-background:new 0 0 192.904 192.904;" xml:space="preserve">
								<path d="M190.707,180.101l-47.078-47.077c11.702-14.072,18.752-32.142,18.752-51.831C162.381,36.423,125.959,0,81.191,0C36.422,0,0,36.423,0,81.193c0,44.767,36.422,81.187,81.191,81.187c19.688,0,37.759-7.049,51.831-18.751l47.079,47.078c1.464,1.465,3.384,2.197,5.303,2.197c1.919,0,3.839-0.732,5.304-2.197C193.637,187.778,193.637,183.03,190.707,180.101z M15,81.193C15,44.694,44.693,15,81.191,15c36.497,0,66.189,29.694,66.189,66.193c0,36.496-29.692,66.187-66.189,66.187C44.693,147.38,15,117.689,15,81.193z"></path>
							</svg>
						</a>
					</div>
					<!-- End <- Floating search menu --> 
				</div>
			</nav>
							<!-- L2 Menu -->
								<div class=" navmenu_sub">
					<div class="main_header_wrapper">
						<div class="clearfix">
							<ul class="clearfix navlist_sub">
																	<li class="menu_l2 ">
										<a href="https://www.moneycontrol.com/mccode/globalmarkets/index.html" title="Global Markets"    >
											Global Markets										</a>
																			</li>
																	<li class="menu_l2 ">
										<a href="https://www.moneycontrol.com/markets/indian-indices/" title="Indian Indices"    >
											Indian Indices										</a>
																			</li>
																	<li class="menu_l2 ">
										<a href="https://www.moneycontrol.com/economic-calendar" title="Economic Calendar"    >
											Economic Calendar										</a>
																			</li>
																	<li class="menu_l2 ">
										<a href="https://www.moneycontrol.com/ipo/" title="IPO"    >
											IPO										</a>
																			</li>
																	<li class="menu_l2 ">
										<a href="https://www.moneycontrol.com/stocks/marketstats/index.php" title="All Stats"    >
											All Stats										</a>
																			</li>
																	<li class="menu_l2 ">
										<a href="https://www.moneycontrol.com/markets/earnings/" title="Earnings"    >
											Earnings										</a>
																			</li>
																	<li class="menu_l2 ">
										<a href="https://www.moneycontrol.com/markets/fno-market-snapshot" title="F&O"    >
											F&O										</a>
																			</li>
																	<li class="menu_l2 ">
										<a href="https://www.moneycontrol.com/india-investors-portfolio/" title="Big Shark Portfolios"    >
											Big Shark Portfolios										</a>
																			</li>
																	<li class="menu_l2 ">
										<a href="https://www.moneycontrol.com/us-markets" title="US Markets"    >
											US Markets												<sup class="new_tagtp">
													<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
														<g id="Layer_2" data-name="Layer 2">
															<g id="Layer_1-2" data-name="Layer 1">
																<rect class="newtag-1" width="28" height="15" rx="7.5"/>
																<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
																<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
																<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
															</g>
														</g>
													</svg>
												</sup>
																					</a>
																			</li>
															</ul>
						</div>
					</div>
				</div>
					</div>
		<!-- End <- Main navbar --> 
	</div>
<!-- Mobile header -> Start -->
	<link rel="stylesheet" type="text/css" href="https://stat2.moneycontrol.com/mccss/headfoot/mobile_header.css?v=0.6" />
	<script>
		var JQ_IS_NEWS_SECTION = 0 
		function trackAndRedirect( srcUrl, trackUrl ) {
			$.ajax({
				url:trackUrl,
				type:"GET",
				cache:true,
				dataType:"jsonp",
				crossDomain:true,
				timeout:3000,
				success:function(x,t,m){
					window.location=srcUrl;
				},
				error: function (xhr, ajaxOptions, thrownError) {
					window.location=srcUrl;
				}
			});
		}
	</script>
		<div class="icpancakeblock" id="fixedheader">
		<!-- Get MC App Strip -> Start -->
			<div class="mcApp_strip header_get_app_strip" id="mcApp_strip">
				<div class="mcApp_strip_container">
					<span class="close_btn">
						<svg xmlns="https://www.w3.org/2000/svg" width="7.414" height="7.414" viewBox="0 0 7.414 7.414">
							<g id="Group_2" data-name="Group 2" transform="translate(0.707 0.707)">
								<line id="Line_1" data-name="Line 1" x2="6" y2="6" fill="none" stroke="#555657" stroke-linecap="round" stroke-width="1"/>
								<line id="Line_2" data-name="Line 2" x1="6" y2="6" fill="none" stroke="#555657" stroke-linecap="round" stroke-width="1"/>
							</g>
						</svg>
					</span>
					<a href="https://www.moneycontrol.com/" title="Moneycontrol" alt="Moneycontrol" class="mid_info_wrap">
						<div class="app_img_wrap">
							<img src="https://images.moneycontrol.com/images/common/header/mcapp_logo_24x24.png" class="app_img" title="Moneycontrol" alt="Moneycontrol" width="24" height="24" />
						</div>
						<div class="app_txt_wrap">
							<div class="line1">Enjoy seamless experience on APP</div><span class="line2">10x faster & More Feature</span>
						</div>
					</a>
					<a href="https://play.google.com/store/apps/details?id=com.divum.MoneyControl" onclick="GAEventTracker( 'Get App', 'Click', window.location.href );" title="Get App" class="get_app_btn">Get App</a>
				</div>
			</div>
		<!-- End <- Get MC App Strip -->

		<div class="iconpancake"></div>

		<div class="FL mc_moblogo for_nonpro_users" >
			<a href="https://www.moneycontrol.com/" title="Moneycontrol">
									<img src="https://images.moneycontrol.com/images/common/header/logo_105x22.png?impolicy=mchigh" width="105" height="22" alt="Moneycontrol" title="Moneycontrol" />
							</a>
		</div>

		<div class="FL mc_moblogo for_mcpro_users" >
			<a href="https://www.moneycontrol.com/pro-top-stories" title="Moneycontrol PRO">
									<img src="https://images.moneycontrol.com/images/common/header/logo_with_pro_144x22.png?impolicy=mchigh" width="144" height="22" alt="Moneycontrol PRO" title="Moneycontrol PRO" />
							</a>
		</div>

		<!-- Telegram icon -> Starts --> 
		<a href="https://t.me/moneycontrolcom" title="Telegram" onclick="GAEventTracker( 'Telegram', 'Header', 'Header' );" target="blank" class="header_telegram_icon for_nonpro_users">
			<svg xmlns="https://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
				<g transform="translate(0.35 0.593)">
					<circle class="circle_a" cx="9" cy="9" r="9" transform="translate(-0.35 -0.593)"/>
					<path class="circle_b" d="M5.311,10.4l8.14-3.139c.378-.136.708.092.585.663h0l-1.386,6.53c-.1.463-.378.576-.763.357L9.778,13.257l-1.018.981a.532.532,0,0,1-.426.208l.15-2.148L12.4,8.763c.17-.15-.038-.234-.262-.085L7.3,11.722l-2.084-.65c-.452-.144-.462-.452.1-.67Z" transform="translate(-1.404 -2.148)"/>
				</g>
			</svg>
		</a> 
		<!-- End <- Telegram icon -->

		<div class="mc-text FL"></div>
		<div class="searchblock PR"><span class="ic-search"></span></div>

		<!-- Open App button -> Start -->
			<a href="https://wz7ux.app.goo.gl/?link=https://www.moneycontrol.com/&utm_source=MC_OpeninApp&utm_medium=MC_WAP&utm_campaign=OpeninApp_Button&apn=com.divum.MoneyControl&ibi=com.moneycontrol.mc&isi=408654600" title="Open App" onclick="GAEventTracker( 'Open App', 'Click', window.location.href );" class="open_app_btn header_open_app_icon" id="header_open_app_button">Open App</a>
		<!-- End <- Open App button -->

		<!-- mobile search start here -->
		<div class="searchBox clearfix" id="autosugg_mc_mobile" style="display:none;">
			<div class="FR">
				<div class="searchboxInner clearfix PR FL">
					<form name="form_mobile_topsearch" id="form_mobile_topsearch" method="get" onsubmit="javascript:return submit_search_txt('#form_mobile_topsearch');" action="">
						<input name="search_data" id="search_data" value="" type="hidden" readonly />
						<input name="cid" id="cid" value="" type="hidden"  readonly="readonly" />
						<input name="mbsearch_str" id="mbsearch_str" type="hidden" value=""  readonly="readonly" />
						<input name="topsearch_type" id="topsearch_type" value="1" type="hidden" readonly />
						<input class="txtsrchbox FL" id="search_str" onkeyup="getAutosuggesionHeader('#form_mobile_topsearch');" onclick="getAutosuggesionHeader('#form_mobile_topsearch'); GAEventTracker( 'SEARCHUSAGE', 'MCTRENDS', 'WAPSTKCLICK' );" placeholder="Search Quotes, News, Mutual Fund NAVs" name="search_str" value="" type="text" autocomplete="off" />
						<label for="search_str" style="display:none;">Search Quotes, News, Mutual Fund NAVs</label>

						<!-- trending search ooptions start -->
						<div class="PR" style="z-index:100000;">
							<div class="trend_searchbx sugBox" style="display:none;">
				<div class="ausggestleft">
					<ul id="ul_srchCat_DDL"><li class="active"><a style="color:#fff !important" title="Trending Stocks">Trending Stocks</a></li></ul>
				</div>
				<div class="clearfix">
					<ul class="suglist">
						<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/india/stockpricequote/miningminerals/vedanta/SG" title="Vedanta">Vedanta&nbsp;<span>INE205A01025, VEDL, 500295</span></a></li>
						<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/india/stockpricequote/ironsteel/tatasteel/TIS" title="Tata Steel">Tata Steel&nbsp;<span>INE081A01020, TATASTEEL, 500470</span></a></li>
									<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/us-markets/stockpricequote/apple/AAPL" title="Apple">Apple&nbsp;<span>US0378331005, AAPL:US</span></a></li>
						<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/india/stockpricequote/auto-ancillaries/amararajabatteries/ARB" title="Amara Raja Batt">Amara Raja Batt&nbsp;<span>INE885A01032, AMARAJABAT, 500008</span></a></li>
									<li><a onclick='GAEventTracker("SEARCHUSAGE", "MCTRENDS", "STKCLICK" )' href="https://www.moneycontrol.com/us-markets/stockpricequote/microsoft/MSFT" title="Microsoft">Microsoft&nbsp;<span>US5949181045, MSFT:US</span></a></li>
					</ul>
				</div>
			</div><!-- Updated @ 2022-11-04 19:50:26 -->						</div>
						<!-- trending search ooptions end --> 

						<!-- auto suggest box-->
						<div class="sugBox" id="autosugg_mc1" style="display:none;">
							<div class="ausggestleft">
								<ul class="nav-tabs" id="ul_srchCat_DDL">
																		<li  class="active"  onClick="suggestboxdd('1', 'mobile_top');" id="tab1">
										<a rel="1" href="javascript:void(0);" title="Quotes"> Quotes </a>
									</li>
																		<li  onClick="suggestboxdd('2', 'mobile_top');" id="tab2">
										<a rel="2" href="javascript:void(0);" title="Mutual Funds"> Mutual Funds</a>
									</li>
									<li onClick="suggestboxdd('5', 'mobile_top');" id="tab5">
										<a rel="5" href="javascript:void(0);" title="Commodities"> Commodities </a>
									</li>
									<li onClick="suggestboxdd('9', 'mobile_top');" id="tab9">
										<a rel="9" href="javascript:void(0);" title="Futures">Futures &amp; Options </a>
									</li>
									<li onClick="suggestboxdd('3', 'mobile_top');" id="tab3">
										<a rel="3" href="javascript:void(0);" title="News"> News </a>
									</li>
									<li onclick="suggestboxdd( '11', 'mobile_top' );" id="tab11">
										<a rel="11" href="javascript:void(0);" title="Cryptocurrency"> Cryptocurrency </a>
									</li>
									<li onClick="suggestboxdd('4', 'mobile_top');" id="tab4">
										<a rel="4" href="javascript:void(0);" title="Forum"> Forum </a>
									</li>
									<li onClick="suggestboxdd('6', 'mobile_top');" id="tab6">
										<a rel="6" href="javascript:void(0);" title="Notices"> Notices </a>
									</li>
									<li onClick="suggestboxdd('7', 'mobile_top');" id="tab7">
										<a rel="7" href="javascript:void(0);" title="Videos"> Videos </a>
									</li>
									<li onClick="suggestboxdd('10', 'mobile_top');" id="tab10">
										<a rel="10" href="javascript:void(0);" title="Glossary"> Glossary </a>
									</li>
									<li onClick="suggestboxdd('8', 'mobile_top');" id="tab8">
										<a rel="8" href="javascript:void(0);" title="All"> All </a>
									</li>
								</ul>
							</div>
							<div class="top_asugscrl">
								<div class="tab-content">
									<div class="tab-pane in active" id="autosuggestlist">
										<ul class="suglist scrollBar">
											<li><a href="javascript:;" target="_parent"><span><b>Auri</b>ferous</span> Aqua Farma&nbsp;, 519363</a></li>
										</ul>
									</div>
								</div>
								<div class="brdtp CTR PT5 view_all_element">
									<a href="https://www.moneycontrol.com/news/tags/mf-experts.html" title="View All" class="ssMore">View All <span class="ic_seemore"></span></a>
								</div>
							</div>
						</div>
					</form>
				</div>
				<a href="javascript:void(0)" title="Submit" onclick="$('#form_topsearch').submit();" class="top_search_btn">
					<svg version="1.1" id="Capa_1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 192.904 192.904" style="enable-background:new 0 0 192.904 192.904;" xml:space="preserve">
						<path d="M190.707,180.101l-47.078-47.077c11.702-14.072,18.752-32.142,18.752-51.831C162.381,36.423,125.959,0,81.191,0
						C36.422,0,0,36.423,0,81.193c0,44.767,36.422,81.187,81.191,81.187c19.688,0,37.759-7.049,51.831-18.751l47.079,47.078
						c1.464,1.465,3.384,2.197,5.303,2.197c1.919,0,3.839-0.732,5.304-2.197C193.637,187.778,193.637,183.03,190.707,180.101z M15,81.193
						C15,44.694,44.693,15,81.191,15c36.497,0,66.189,29.694,66.189,66.193c0,36.496-29.692,66.187-66.189,66.187
						C44.693,147.38,15,117.689,15,81.193z"></path>
					</svg>
				</a>
			</div>
		</div>
		<div id="get_open_app_result" class="get_open_app_result" style="display:none;">
			<strong>Get App / Open App</strong>
			<div id="mobile_operating_system"></div>
			<div id="cookie_object"></div>
			<div id="is_mc_app_installed"></div>
			<div id="final_output"></div>
		</div>
		<!-- mobile search END here -->
		<div class="pancakemenu">
			<div class="menu_tab_block">
				<div class="blp">
					<ul class="menu_tabs wap_three_tabs clearfix">
						<li class="clearfix popuplink">
							<a id="wap_popup_menu_login" href="https://m.moneycontrol.com/login.php" title="Login" class="gd18 wap_popup_menu_login">
								<div class="without_pic"> <span class="propic"> <img src="https://images.moneycontrol.com/images/common/header/icon_profile.png" width="16" height="16" alt="User Profile" title="User Profile" /> </span><span class="textblok">Login</span> </div>
							</a>
						</li>
						<li class="clearfix popuplink"> <a href="https://m.moneycontrol.com/mcreg.php" title="Sign-Up" class="gd18"><span class="textblok">Sign-Up</span></a> </li>
						<li class="clearfix searchlang">
							<a href="javascript:;" title="English" class="gd18"><span></span><span class="textblok">English</span><span class="menu_tab_arw"></span></a>
							<div class="hamburger_tabs_content srchCat_DDLbx">
								<div class=" ">
									<ul>
										<li><a href="https://m.moneycontrol.com/hi/" title="हिंदी" target="_blank">हिंदी</a></li>
										<li><a href="https://m.moneycontrol.com/gu/" title="ગુજરાતી" target="_blank">ગુજરાતી</a></li>
									</ul>
								</div>
							</div>
						</li>
					</ul>
				</div>
				<ul class="menu_tabs clearfix alp">
					<li class="mobile_user_name clearfix searchlang">
						<a href="javascript:;" title="MC Login User Name" class="a_tag gd18">
							<div class="with_pic"> <span class="propic"> <img src="https://images.moneycontrol.com/images/common/header/icon_profile.png" width="16" height="16" alt="MC Login User Name" title="MC Login User Name" class="image_tag" /> </span><span class="span_tag textblok">MC Login User Name</span> <span class="menu_tab_arw"></span> </div>
						</a>
						<div class="hamburger_tabs_content srchCat_DDLbx">
							<div>
																<ul>
									<li>
										<a href="https://www.moneycontrol.com/portfolio-management/user/update_profile" title="My Profile">My Profile</a>
									</li>
									<li class="for_mcpro_users"><a href="https://www.moneycontrol.com/promos/pro.php" title="My PRO">My PRO</a></li>
									<li><a href="https://m.moneycontrol.com/portfolio.php?type=today" title="My Portfolio">My Portfolio</a></li>
									<li>
										<a href="https://m.moneycontrol.com/watchlist.php" title="My Watchlist" class="my_wap_watchlist_link">My Watchlist</a>
									</li>
									<li><a href="https://m.moneycontrol.com/mmb/" title="My Messages">My Messages</a></li>
									<li><a id="wap_login_user_logout" class="wap_login_user_logout" href="https://m.moneycontrol.com/logout.php?red_url=index.html" title="Logout">Logout</a></li>
								</ul>
							</div>
						</div>
					</li>
					<li class="clearfix searchlang">
						<a href="javascript:;" title="English" class="gd18"><span></span><span class="textblok">English</span><span class="menu_tab_arw"></span></a>
						<div class="hamburger_tabs_content srchCat_DDLbx">
							<div>
								<ul>
									<li><a href="https://m.moneycontrol.com/hi/" title="हिंदी" target="_blank">हिंदी</a></li>
									<li><a href="https://m.moneycontrol.com/gu/" title="ગુજરાતી" target="_blank">ગુજરાતી</a></li>
								</ul>
							</div>
						</div>
					</li>
				</ul>
			</div>
			<div class="pancakScrl">
				<ul class="menutable">
													<li class="">
									<a href="https://www.moneycontrol.com/" title="Home" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Home' );"  >
									Home									</a>
								</li>
													<li class="for_nonpro_users PR">
									<a href="https://www.moneycontrol.com/promos/pro.php" title="Upgrade your experience" class="gd18 upgrade_your_exp" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Upgrade your experience' );"  >
									Upgrade your<br /> experience											<a href="https://www.moneycontrol.com/promos/pro.php" title="Remove ads" class="removeads">Remove ads</a>
																		</a>
								</li>
													<li class="clearfix hamburger_more_menu for_mcpro_users">
									<span class="hamburger_more_menu_arw"></span>
									<a href="javascript:;" title="Moneycontrol PRO" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Moneycontrol PRO' );"   class="gd18 submenu_div">
										Moneycontrol <span class="moneycontrolPro">PRO</span>									</a>
									<ul class="hamburger_submenu">
																				<li>
																							<a href="https://www.moneycontrol.com/pro-top-stories" title="Top Stories"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Top Stories' );"   >
													Top Stories 												</a>
																							<a href="https://www.moneycontrol.com/pro-financial-times" title="Financial Times"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Financial Times' );"   >
													Financial Times 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/pro-opinion" title="Opinion"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Opinion' );"   >
													Opinion 												</a>
																							<a href="https://www.moneycontrol.com/pro-markets-learn" title="Learn"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Learn' );"   >
													Learn 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/pro-market-guru" title="GuruSpeak"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'GuruSpeak' );"   >
													GuruSpeak 												</a>
																							<a href="https://www.moneycontrol.com/webinar" title="Webinar"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Webinar' );"   >
													Webinar 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/pro-interviews" title="Interview Series"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Interview Series' );"   >
													Interview Series 												</a>
																							<a href="https://www.moneycontrol.com/pro-business-in-week-ahead" title="Business In The Week Ahead"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Business In The Week Ahead' );"   >
													Business In The Week Ahead 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/pro-market-research" title="Research"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Research' );"   >
													Research 												</a>
																							<a href="https://www.moneycontrol.com/pro-technical-analysis" title="Technical Analysis"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Technical Analysis' );"   >
													Technical Analysis 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/pro-personalfinance" title="Personal Finance"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Personal Finance' );"   >
													Personal Finance 												</a>
																							<a href="https://www.moneycontrol.com/promos/pro.php" title="My Subscription"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'My Subscription' );"   >
													My Subscription 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/pro-offers" title="My Offers"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'My Offers' );"   >
													My Offers 												</a>
																					</li>
																			</ul>
																	</li>
													<li class="clearfix hamburger_more_menu">
									<span class="hamburger_more_menu_arw"></span>
									<a href="javascript:;" title="Markets" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Markets' );"   class="gd18 submenu_div">
										Markets									</a>
									<ul class="hamburger_submenu">
																				<li>
																							<a href="https://www.moneycontrol.com/stocksmarketsindia/" title="Markets"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Markets' );"   >
													Home 												</a>
																							<a href="https://www.moneycontrol.com/stocks/marketstats/fii_dii_activity/index.php" title="FII & DII Activity"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'FII & DII Activity' );"   >
													FII & DII Activity 												</a>
																					</li>
																				<li>
																							<a href="https://m.moneycontrol.com/markets/corporate-action/" title="Corporate Action"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Corporate Action' );"   >
													Corporate Action 												</a>
																							<a href="https://www.moneycontrol.com/stocksmarketsindia/?dashboard=l2" title="Dashboard"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Dashboard' );"   >
													Dashboard 												</a>
																					</li>
																				<li>
																							<a href="https://m.moneycontrol.com/markets/earnings/" title="Earnings"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Earnings' );"   >
													Earnings 												</a>
																							<a href="https://m.moneycontrol.com/webinar" title="Webinar"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Webinar' );"   >
													Webinar 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/pro-interviews" title="Interview Series" style="padding-right:0px !important;" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Interview Series' );"   >
													Interview Series 														&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="Interview Series" alt="Interview Series" width="22" height="10" /></sup>
																									</a>
																							<a href="https://www.moneycontrol.com/markets/premarket/" title="Pre Market" style="padding-right:0px !important;" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Pre Market' );"   >
													Pre Market 														&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="Pre Market" alt="Pre Market" width="22" height="10" /></sup>
																									</a>
																					</li>
																			</ul>
																	</li>
													<li class="">
									<a href="https://www.moneycontrol.com/news/t20-world-cup/" title="T20 World Cup" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'T20 World Cup' );"  >
									T20 World Cup											&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="T20 World Cup" alt="T20 World Cup" width="22" height="10" /></sup>
																		</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/news/investing-abroad-the-essential-guide" title="Invest Abroad" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Invest Abroad' );"  >
									Invest Abroad											&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="Invest Abroad" alt="Invest Abroad" width="22" height="10" /></sup>
																		</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/news/diwali-muhurat-trading-samvat-2079/" title="Muhurat Trading" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Muhurat Trading' );"  >
									Muhurat Trading											&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="Muhurat Trading" alt="Muhurat Trading" width="22" height="10" /></sup>
																		</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/msite/mc-explains-mutual-fund-simplified" title="MF Simplified" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'MF Simplified' );"  >
									MF Simplified									</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/news/overseas-education/" title="Study Abroad" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Study Abroad' );"  >
									Study Abroad									</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/news/tags/mc-learn.html" title="MC Learn" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'MC Learn' );"  >
									MC Learn									</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/news/rakesh-jhunjhunwala-archives" title="Rakesh Jhunjhunwala Archives" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Rakesh Jhunjhunwala Archives' );"  >
									RJ Archives									</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/economic-calendar" title="Economic Calendar" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Economic Calendar' );"  >
									Economic Calendar											&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="Economic Calendar" alt="Economic Calendar" width="22" height="10" /></sup>
																		</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/markets/global-indices/" title="Global Markets" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Global Markets' );"  >
									Global Markets									</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/us-markets" title="US Markets" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'US Markets' );"  >
									US Markets											&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="US Markets" alt="US Markets" width="22" height="10" /></sup>
																		</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/markets/indian-indices/?classic=true" title="Indian Indices" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Indian Indices' );"  >
									Indian Indices									</a>
								</li>
													<li class="clearfix hamburger_more_menu">
									<span class="hamburger_more_menu_arw"></span>
									<a href="javascript:;" title="News" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'News' );"   class="gd18 submenu_div">
										News									</a>
									<ul class="hamburger_submenu">
																				<li>
																							<a href="https://www.moneycontrol.com/news/" title="News"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'News' );"   >
													Home 												</a>
																							<a href="https://www.moneycontrol.com/news/tags/coronavirus.html" title="Coronavirus"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Coronavirus' );"   >
													Coronavirus 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/news/technology-startups" title="Tech/Startups"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Tech/Startups' );"   >
													Tech/Startups 												</a>
																							<a href="https://www.moneycontrol.com/news/technology/auto" title="Auto"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Auto' );"   >
													Auto 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/equity-research/" title="Research"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Research' );"   >
													Research 												</a>
																							<a href="https://www.moneycontrol.com/news/opinion/" title="Opinion"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Opinion' );"   >
													Opinion 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/news/politics/" title="Politics"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Politics' );"   >
													Politics 												</a>
																							<a href="https://www.moneycontrol.com/news/business/personal-finance/" title="Personal Finance"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Personal Finance' );"   >
													Personal Finance 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/news/personal-finance/epfo/" title="EPF Guide"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'EPF Guide' );"   >
													EPF Guide 														&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="EPF Guide" alt="EPF Guide" width="22" height="10" /></sup>
																									</a>
																					</li>
																			</ul>
																	</li>
													<li class="">
									<a href="https://www.moneycontrol.com/news/mcminis" title="MC Minis" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'MC Minis' );"  >
									MC Minis											&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="MC Minis" alt="MC Minis" width="22" height="10" /></sup>
																		</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/india-investors-portfolio/" title="Big Shark Portfolios" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Big Shark Portfolios' );"  >
									Big Shark Portfolios											&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="Big Shark Portfolios" alt="Big Shark Portfolios" width="22" height="10" /></sup>
																		</a>
								</li>
													<li class="">
									<a href="https://m.moneycontrol.com/portfolio.php?type=today" title="Portfolio" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Portfolio' );"  >
									Portfolio									</a>
								</li>
													<li class="">
									<a href="https://m.moneycontrol.com/watchlist.php" title="Watchlist" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Watchlist' );"  >
									Watchlist									</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/personal-finance/" title="Personal Finance" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Personal Finance' );"  >
									Personal Finance									</a>
								</li>
													<li class="">
									<a href="https://www.moneycontrol.com/personal-finance/health-insurance-ratings" title="MC Health Insurance Ratings" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'MC Health Insurance Ratings' );"  >
									MC Health Insurance Ratings											&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="MC Health Insurance Ratings" alt="MC Health Insurance Ratings" width="22" height="10" /></sup>
																		</a>
								</li>
													<li class="clearfix hamburger_more_menu">
									<span class="hamburger_more_menu_arw"></span>
									<a href="javascript:;" title="Mutual Funds" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Mutual Funds' );"   class="gd18 submenu_div">
										Mutual Funds									</a>
									<ul class="hamburger_submenu">
																				<li>
																							<a href="https://www.moneycontrol.com/mutualfundindia/" title="Mutual Funds"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Mutual Funds' );"   >
													Home 												</a>
																							<a href="https://www.moneycontrol.com/mutual-funds/performance-tracker/returns/large-cap-fund.html" title="Performance Tracker"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Performance Tracker' );"   >
													Performance Tracker 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/mutual-funds/best-funds/equity.html" title="Top ranked funds"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Top ranked funds' );"   >
													Top ranked funds 												</a>
																							<a href="https://m.moneycontrol.com/portfolio.php?type=today" title="My Portfolio"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'My Portfolio' );"   >
													My Portfolio 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/mutual-funds/performance-tracker/all-categories?order=default&dur=1y" title="Top performing Categories"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Top performing Categories' );"   >
													Top performing Categories 												</a>
																							<a href="https://www.moneycontrol.com/mutualfundindia/mutual-fund-discussion-forum" title="Forum"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Forum' );"   >
													Forum 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/mutual-fund/mc-30" title="MC30 Funds"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'MC30 Funds' );"   >
													MC 30 														&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="MC30 Funds" alt="MC30 Funds" width="22" height="10" /></sup>
																									</a>
																					</li>
																			</ul>
																	</li>
													<li class="">
									<a href="https://www.moneycontrol.com/commodity/" title="Commodities" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Commodities' );"  >
									Commodities									</a>
								</li>
													<li class="">
									<a href="https://m.moneycontrol.com/mccode/currencies/" title="Currencies" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Currencies' );"  >
									Currencies									</a>
								</li>
													<li class="">
									<a href="https://m.moneycontrol.com/mmb/" title="Forum" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Forum' );"  >
									Forum									</a>
								</li>
													<li class="clearfix hamburger_more_menu">
									<span class="hamburger_more_menu_arw"></span>
									<a href="javascript:;" title="Videos" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Videos' );"   class="gd18 submenu_div">
										Videos									</a>
									<ul class="hamburger_submenu">
																				<li>
																							<a href="https://m.moneycontrol.com/live_tv.php" title="Live TV & Shows"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Live TV & Shows' );"   >
													Live TV & Shows 												</a>
																							<a href="https://www.moneycontrol.com/video-shows/?classic=true" title="Video"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Video' );"   >
													Video 														&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="Video" alt="Video" width="22" height="10" /></sup>
																									</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/podcast/?classic=true" title="Podcast"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Podcast' );"   >
													Podcast 														&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="Podcast" alt="Podcast" width="22" height="10" /></sup>
																									</a>
																							<a href="https://www.moneycontrol.com/stock-premier-league/?classic=true" title="Stock Premier League"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Stock Premier League' );"   >
													Stock Premier League 												</a>
																					</li>
																			</ul>
																	</li>
													<li class="clearfix hamburger_more_menu">
									<span class="hamburger_more_menu_arw"></span>
									<a href="javascript:;" title="Invest Now" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Invest Now' );"   class="gd18 submenu_div">
										Invest Now												&nbsp;<sup><img src="https://images.moneycontrol.com/images/common/header/new_icon_animated.gif" title="Invest Now" alt="Invest Now" width="22" height="10" /></sup>
																			</a>
									<ul class="hamburger_submenu">
																				<li>
																							<a href="https://www.moneycontrol.com/msite/smallcase" title="Smallcase"  onclick="javascript:GAEventTracker( 'Invest Now', 'Menu', 'smallcase' );"   >
													Smallcase 												</a>
																							<a href="https://www.moneycontrol.com/msite/global-investing" title="U.S. Stocks & ETFs"  onclick="javascript:GAEventTracker( 'Invest Now', 'Menu', 'U.S. Stocks & ETFs' );"   >
													U.S. Stocks & ETFs 												</a>
																					</li>
																			</ul>
																	</li>
													<li class="">
									<a href="https://www.moneycontrol.com/subscription" title="Subscriptions" class="gd18 " onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Subscriptions' );"  >
									Subscriptions									</a>
								</li>
													<li class="clearfix hamburger_more_menu last_accordion_menu">
									<span class="hamburger_more_menu_arw"></span>
									<a href="#accord_last_div" title="Specials" onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L1', 'Specials' );"   class="gd18 submenu_div">
										Specials									</a>
									<ul class="hamburger_submenu">
																				<li>
																							<a href="https://www.moneycontrol.com/msite/sahi-hai-pathshala" title="Aditya Birla MF"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Aditya Birla MF' );"   >
													Aditya Birla MF 												</a>
																							<a href="https://www.moneycontrol.com/msite/badlaav-humse-hai#hometop" title="Badlaav Humse Hai"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Badlaav Humse Hai' );"   >
													Badlaav Humse Hai 												</a>
																					</li>
																				<li>
																							<a href="https://www.sustainability100plus.com/?utm_source=specials" title="Sustainability 100+"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Sustainability 100+' );"   >
													Sustainability 100+ 												</a>
																							<a href="https://www.moneycontrol.com/msite/india-invest-karo" title="India Invest Karo"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'India Invest Karo' );"   >
													India Invest Karo 												</a>
																					</li>
																				<li>
																							<a href="https://www.moneycontrol.com/msite/pharma-industry-conclave" title="Pharma Industry Conclave"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Pharma Industry Conclave' );"   >
													Pharma Industry Conclave 												</a>
																							<a href="https://www.moneycontrol.com/msite/unlocking-opportunities-in-metal-mining" title="Unlocking opportunities in Metal and Mining"  onclick="javascript:GAEventTracker( 'Navigation', 'Hb_L2', 'Unlocking opportunities in Metal and Mining' );"   >
													Unlocking opportunities in Metal and Mining 												</a>
																					</li>
																			</ul>
																		<div id="accord_last_div"></div>
																	</li>
									</ul>

				<div class="menu_bottom_block">
					<ul class="menu_tabs clearfix">
						<li class="bottom_get_app">
							<a href="javascript:;" title="Get app" id="getAppModel" class="gd18 getAppModel"><span class="getapp"></span> Get app</a>
						</li>
						<li class="bottom_be_a_pro">
							<a href="https://www.moneycontrol.com/promos/pro.php" title="Be a pro" class="gd18">
								<span class="bepro"></span> <span class="bea for_nonpro_users">Be a</span> <span>pro</span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		var mcpro = readCookieRevamp( 'mcpro' );
		var current_page_url = window.location.href;
		if( current_page_url != '' && current_page_url != undefined ) {
			document.getElementById( 'wap_popup_menu_login' ).setAttribute( 'href', 'https://m.moneycontrol.com/login.php?cpurl=' + current_page_url );
		}
	</script>
		<!-- Logout Link Change -> Start -->
		<script type="text/javascript">
			if( readCookieRevamp( 'nnmc' ) ) {
				var is_activate_logout_link = true;
				if( is_activate_logout_link == true ) {
					var current_page_url = window.location.href;
					if( current_page_url != '' && current_page_url != undefined ) {
						document.getElementById( 'wap_login_user_logout' ).setAttribute( 'href', 'https://m.moneycontrol.com/logout.php?red_url=' + current_page_url );
					}
				}
			}
		</script>
		<!-- End <- Logout Link Change -->
<!-- End <- Mobile header --></header>
		<script type="text/javascript" src="https://stat3.moneycontrol.com/mcjs/common/jquery-1.12.0.min.js"></script>
<script language="Javascript">
	var mcpro = readCookieRevamp( 'mcpro' );
	if( mcpro == '1' ) {
		$( '.for_mcpro_users' ).show();
		$( '.for_nonpro_users' ).hide();
	} else {
		$( '.for_mcpro_users' ).hide();
		$( '.for_nonpro_users' ).show();
	}

	if( readCookieRevamp( 'nnmc' ) ) {
		var usernnmc = readCookieRevamp( 'nnmc' );
		usernnmc = $.trim(usernnmc);
		let nnmc = usernnmc;

		if( $.trim( usernnmc ) == 'Guest' || $.trim( usernnmc ) == 'guest' ) {
			$( 'div.myaccpop' ).remove();
		}

		usernnmc = usernnmc.replace("%40","@");
		usernnmc = usernnmc.replace(/\+/g, " ");

		/* let display_name = convertStringToCamelCase( nnmc ); */
		let display_name = convertStringToCamelCase( usernnmc );
		$( '.user_after_login .userlink' ).attr( "title", display_name );
		$( '.user_after_login .usr_nm' ).text( "Hi " + display_name );

		if( usernnmc != false && usernnmc != 'false' && usernnmc != '' ) {

			if( $( '.mobile_user_name' ).length ) {
				var dispnm = usernnmc;
				if( usernnmc.length > 6 ) {
					dispnm = usernnmc.substr( 0, 6 ) + '..';
				}

				$( 'a#mobile_usr_nm' ).text( "Hi " + dispnm );
				$( '.mobile_user_name .a_tag' ).attr( 'title', usernnmc );

				$( '.mobile_user_name .image_tag' ).attr({
					alt: usernnmc,
					title: usernnmc
				});

				$( '.mobile_user_name .span_tag' ).text( usernnmc );
			}

			$( 'div.blp, ul.blp' ).hide();
			$( 'div.blp, ul.blp' ).remove();
			$( 'div.alp' ).show();
		} else {
			$( 'div.alp, ul.alp, li.alp' ).remove();
		}

		/* Ad Block in MC website for Pro users -> Start */
			var mcpro = readCookieRevamp( 'mcpro' );

			if( $( '.mc_logo_be_a_pro' ).length ) {
				if( mcpro == '1' ) {
					$( '.mc_logo_only_pro' ).show();
					$( '.for_mcpro_users' ).show();
				} else {
					$( '.mc_logo_be_a_pro' ).show();
				}
			}

			if( $( '#menu_l1_be_a_pro' ).length ) {
				if( mcpro == '1' ) {
					$( '#menu_l1_be_a_pro a' ).text( 'PRO' );
					$( '#menu_l1_be_a_pro a' ).attr({
						href: 'https://www.moneycontrol.com/pro-top-stories',
						title: 'PRO'
					});
				} else {
					$( '#menu_l1_be_a_pro a' ).attr( 'href', 'https://www.moneycontrol.com/pro-top-stories' );
				}
			}
		/* End <- Ad Block in MC website for Pro users */

		/* WAP - Bottom menu block -> Start */
			if( $( '.menu_bottom_block' ).length ) {
				if( mcpro == '1' ) {
					$( '.menu_bottom_block .bottom_be_a_pro a' ).attr({
						href: 'https://www.moneycontrol.com/pro-top-stories',
						title: 'Pro'
					});
				}
			}
		/* End <- WAP - Bottom menu block */

		/* My Watchlist link -> Start */
			let def_view = readCookieRevamp( 'DEF_VIEW' );

			if( def_view != '' && def_view != undefined ) {
				let my_watchlist_link = 'https://www.moneycontrol.com/bestportfolio/wealth-management-tool/stock_watchlist';
				let my_wap_watchlist_link = 'https://m.moneycontrol.com/watchlist.php';
				if( def_view == '4' ) {
					my_watchlist_link = 'https://www.moneycontrol.com/portfolio-management/portfolio-investment-dashboard/stock/watchlist';
					my_wap_watchlist_link = my_watchlist_link;

					if( $( '.my_watchlist_link' ).length ) {
						$( '.my_watchlist_link' ).attr( 'href', my_watchlist_link );
					}
				}
				$( '.verified_text' ).attr( 'src', my_watchlist_link );

				if( $( '.mobile_user_name' ).length ) {
					$( '.mobile_user_name .my_wap_watchlist_link' ).attr( 'src', my_wap_watchlist_link );
				}
			}
		/* End -> My Watchlist link */

		/* Check for User Email and Mobile verification -> Start */
			let verification_flag = readCookieRevamp( 'verify' );
			if( verification_flag != '' && verification_flag != undefined ) {
				let verification_list = null;

				verification_flag = decodeURIComponent( verification_flag );
				verification_list = verification_flag.split( '$$##$$' );

				if( verification_list[1] == "0" || verification_list[0] == "0" ) { /* [1] => Email , [0] => Mobile ,  */
					$( '.verified_text' ).html( '(Unverified)' );
				} else {
					$( '.verified_text' ).html( '' );
				}
			}
		/* End <- Check for User Email and Mobile verification */

	} else {
		$( 'div.alp, ul.alp, li.alp' ).remove();
		$( '.mc_logo_be_a_pro' ).show();
	}
</script>
	<!-- Logout Link Change -> Start -->
	<script type="text/javascript">
		if( readCookieRevamp( 'nnmc' ) ) {
			var is_activate_logout_link = true;
			if( is_activate_logout_link == true ) {
				var current_page_url = window.location.href;
				if( current_page_url != '' && current_page_url != undefined ) {
					$( '.my_acclist .login_user_logout a' ).attr( 'href', 'https://www.moneycontrol.com/mcplus/portfolio/logout.php?ref=' + current_page_url );
				}
			}
		}
	</script>
	<!-- End <- Logout Link Change -->
<!--header end-->
<link rel="stylesheet" type="text/css" href="https://stat3.moneycontrol.com/mccss/common/googlefonts.css?v=0.2" />
		<link href="https://accounts.moneycontrol.com/assets/css/mclogin/bootstrap.min.css?v=0.1" rel="stylesheet" />
<script type='text/javascript' src="https://stat2.moneycontrol.com/mcjs/common/jquery.cookie.js"></script>
<script type="text/javascript" src="https://stat3.moneycontrol.com/mcjs/common/bootstrap.min.js"></script>
<script type="text/javascript" src="https://stat2.moneycontrol.com/mcjs/common/jquery.bxslider-min.js"></script>

<script type="text/javascript" src="https://stat2.moneycontrol.com/mcjs/common/moneycontrol_header.js?v=1.12" async="async"></script>

<script type="text/javascript" src="https://stat2.moneycontrol.com/mcjs/common/slick.min.js?v=1.0"></script>
				<link rel="stylesheet" type="text/css" href="https://stat4.moneycontrol.com/mccss/common/mainStyle_other.css?v=2.03" />
		<link rel="stylesheet" type="text/css" href="https://stat2.moneycontrol.com/mccss/headfoot/mc_header.css?v=1.6" />
		<link rel="stylesheet" type="text/css" href="https://stat2.moneycontrol.com/mccss/headfoot/mc_footer.css?v=1.2" />
		<link rel="stylesheet" type="text/css" href="https://stat2.moneycontrol.com/mccss/headfoot/mobile_footer.css?v=1.6" />
				<link rel="stylesheet" type="text/css" href="https://stat3.moneycontrol.com/mccss/markets/market_style12.css?ver=2.03" />
	<!-- commonstore|commonfiles|header_tag_manager  -->
	<!-- Facebook Pixel Code -> Start -->
	<script>
	!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
	n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
	n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
	t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
	document,'script','https://connect.facebook.net/en_US/fbevents.js');
	fbq('init', '482038382136514');
	fbq('track', 'PageView');
	</script>
	<!-- End -> Facebook Pixel Code -->
			<!--  Jacket -> Start -->
			<div align="center" style="width:990px; margin:12px auto 0px;">
				<div id="budget_adDiv" class="cls_budget_adDiv mob-hide">
					<style>
						.closeadpr{width:970px; margin:0 auto; text-align:right;}
						.closeadpr a{font:700 12px Arial, sans-serif; color:#043c74; display:inline-block; padding:0; text-decoration: underline;}
						@media only screen and (max-width:980px) {
							.closeadpr{width:100%; margin:0 auto; text-align:right;}
						}
					</style>
								</div>
			</div>
			<script type="text/javascript">
				$(document).ready(function() {
					if( $( '.ad_google_shhide' ).length ) {
						$( '.sh_clad' ).click( function() {
							var $this = $(this);
							$( '.addhide_show' ).slideToggle();
							$this.toggleClass( 'sh_clad' );
							if( $this.hasClass( 'sh_clad' ) ) {
								$this.attr( 'title', 'Close Ad' );
								$this.text( 'Close Ad' );
															} else {
								$this.attr( 'title', 'Show Ad' );
								$this.text( 'Show Ad' );
							}
						})
					}
				});
			</script>
			<!--  End <- Jacket -->
		<!--  Jacket -> Start -->
		<!--  End <- Jacket -->
<!-- Gutter Slot -> Start -->
		<div id="gggl_gutter" style="line-height:0;">
		</div>
<!-- End <- Gutter Slot -->
		<div class="main" id="mc_mainWrapper">
			<!--Error element start-->
<style>
	.disc_messagebx_error{ background:#f8d0c8; border-radius:3px; border:1px solid #ecb1a6; padding:7px 20px; color:#333333; margin-bottom:10px; margin-top: 12px; font:400 16px 'Open Sans',arial; position:relative; text-align:center;}
	.disc_messagebx_error .ic_attention{display:inline-block; width:18px; height:18px; background:url(images/ic_alert.png) 0 0 no-repeat; margin:3px 10px 0 0;}
	.disc_messagebx_error .col_red{color:#333333; font-weight:bold; font-size:18px;}
	.disc_messagebx_error .ohidden{overflow:hidden;}
	.disc_messagebx_error .bldlink{font-weight:600; color:#0065a1; display:inline-block; border:1px solid #1a6da3; border-radius:2px; padding:6px 15px; font-size:12px; text-decoration:none !important; margin-left:15px;}
	.disc_messagebx_error .close_txt{color:#333; font:700 16px Arial, sans-serif; display:inline-block; cursor:pointer; right:3px; top:3px; position:absolute; display:inline-block; width:10px; height:10px; background:url(https://images.moneycontrol.com/images/common/close_arw.gif) 0 0 no-repeat;}
</style>

<div class="disc_messagebx_error clearfix" id="errorClosedv" style="display:none;">
	<span class="close_txt" onclick="close_verify_account();"></span>
	<div>
		<span style="vertical-align: top;">
			<svg fill="#E63512" height="22" viewBox="0 0 24 24" width="22" xmlns="https://www.w3.org/2000/svg">
				<path d="M0 0h24v24H0z" fill="none" />
				<path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z" />
			</svg>
		</span>
		<span class="col_red">Verify your Moneycontrol account.</span> Please verify your <span id="verification_label"></span> today. <a href="https://www.moneycontrol.com/bestportfolio/wealth-management-tool/update_profile" title="Verify Now" class="bldlink">Verify Now</a>
	</div>
	<div class="CL"></div>
</div>
<script type="text/javascript">
	$(document).ready(function(e){  
		var cookieval = $.cookie('verify');

		if( cookieval != '' && cookieval != undefined ) {
			var verify_list = cookieval.split('$$##$$');

			/* [0] => email, [1] => mobile, */
			if( verify_list[0] == "0" || verify_list[1] == "0") {
				if( verify_list[0] == "1" ) {	/* For Email` */
					document.getElementById( 'verification_label' ).innerHTML = 'Email ID';
				} else if( verify_list[1] == "1" ) {	/* For Mobile */
					document.getElementById( 'verification_label' ).innerHTML = 'Mobile Number';
				} else {
					document.getElementById( 'verification_label' ).innerHTML = 'Email ID and Mobile Number';
				}
				document.getElementById( 'errorClosedv' ).setAttribute( "style", "display:block" );
			}
		}
	});

	function close_verify_account () {
		document.getElementById( 'errorClosedv' ).setAttribute( "style", "display:none" );
	}
</script>
<!--Error elemend end-->								<div class="PA10">
						
							<div class="FL" style="width:775px;">
			<!-- Chartbeat Tracking -> Start -->
<script type="text/javascript">
	/* Read Chartbeat cookie function -> Start */
		function get_chartbeat_cookie( cname ) {
			var name = cname + "=";
			var ca = document.cookie.split( ';' );
			for( var i = 0; i < ca.length; i++ ) {
				var c = ca[i];
				while( c.charAt(0) == ' ' ) { c = c.substring(1); }
				if( c.indexOf( name ) == 0 ) { return c.substring( name.length, c.length ); }
			}
			return "";
		}
	/* End <- Read Chartbeat cookie function */

	(function() {
		var _sf_async_config = window._sf_async_config = (window._sf_async_config || {});
		_sf_async_config.uid = 20831;
		_sf_async_config.domain = 'moneycontrol.com';
		_sf_async_config.flickerControl = false;

		let canonical_url =  $.trim( $( "link[rel='canonical']" ).attr( "href" ) );
		if( canonical_url !== "" ) {
			_sf_async_config.useCanonical = true;
			_sf_async_config.useCanonicalDomain = true;
		} else {
			let location_path = window.location.href;
			location_path = location_path.replace(/^http:\/\//, '').replace(/^https:\/\//, '').replace(/^www./, '');
			_sf_async_config.path = location_path;
		}
		_sf_async_config.sections = 'Moneycontrol,Markets';
		_sf_async_config.authors = 'Moneycontrol';
		/* User Subscriber Status -> Start */
			var user_type = 'anon';	/* Subscriber Status - Guest */
			if( get_chartbeat_cookie( 'nnmc' ) ) {
				user_type = 'lgdin';	/* Subscriber Status - Registered */
				var mcpro = get_chartbeat_cookie( 'mcpro' );
				if( mcpro != undefined && mcpro == '1' ) {
					user_type = 'paid';	/* Subscriber Status - Subscriber */
				}
			}
			var _cbq = window._cbq = (window._cbq || []);
			_cbq.push( ['_acct', user_type] );
		/* End <- User Subscriber Status */

		function loadChartbeat() {
			var e = document.createElement('script');
			var n = document.getElementsByTagName('script')[0];
			e.type = 'text/javascript';
			e.async = true;
			e.src = '//static.chartbeat.com/js/chartbeat.js';;
			n.parentNode.insertBefore(e, n);
		}
		loadChartbeat();
	})();
</script>
<script async src="//static.chartbeat.com/js/chartbeat_mab.js"></script>
<!-- End <- Chartbeat Tracking -->	<div id="Moneycontrol/MC_ROS/MC_ROS_Slider_2x2">
		<script>
			setTimeout(function() {
				googletag.cmd.push( function() { 
					googletag.display( 'Moneycontrol/MC_ROS/MC_ROS_Slider_2x2' );
				});
			}, ad_delay_by);
		</script>
	</div>
	<div id='Moneycontrol/MC_ROS/MC_ROS_1x1'>
		<script>
			setTimeout(function() {
				googletag.cmd.push(function() { 
					googletag.display( 'Moneycontrol/MC_ROS/MC_ROS_1x1' ); 
				});
			}, ad_delay_by);
		</script>
	</div>
<script type="text/javascript">
	$(document).ready(function() {
		var mcpro = readCookieRevamp( 'mcpro' );

		if( $( '.tooltiplink' ).length ) {
			if( mcpro == '1' ) {
				/* Ad Block in MC website for Pro users */
				$( '.tooltipbox' ).html( '' );
			} else {
				$('.tooltiplink a.tip').mouseover( function(){
					$(this).next('.tooltipbox').show();
				});
				$('.tooltiplink').mouseout(function(){
					$('.tooltipbox').hide();
				})
			}
		}

		if( $( '.tooltipbox' ).length ) {
			$('.tooltipbox').mouseover(function() {
				$(this).show();
			})
			$('.tooltipbox').mouseout(function() {
				$(this).hide();
			})
		}

		/* Find out current page url */
		if( $( '.current_page_url' ).length ) {
			var current_page_url = window.location.href;
			$( '.current_page_url' ).val( current_page_url );
		}

		/* Hide all elements for MC Pro Users, having class name as dfp_ads_block */
		if( $( '.dfp_ads_block' ).length ) {
			if( mcpro == '1' ) {
				$( '.dfp_ads_block' ).hide();
			}
		}

		/* When User mouseover on Special bar */
		$( ".speacial_dropbx" ).mouseover(function () {
			var isSpecialMenuLoaded = $("#special_dropdown").val();
			if (isSpecialMenuLoaded == '') {
				$("#special_dropdown").val(1);
				ajax_link = "https://www.moneycontrol.com/commonstore/commonfiles/specials_logo_data.html?classic=true";

				special_dropdown_call = $.ajax({
					type: "GET",
					url: ajax_link,
					dataType: 'html',
					error: function (obj, errorMsg, d) {
					},
					success: function (html_body) {
						if (html_body != '') {
							$("#splist").html(html_body);
							var spec_slider = $('.splist').bxSlider({
								pager: false,
								slideMargin: 15,
								minSlides: 6,
								maxSlides: 6,
								slideWidth: 145,
								infiniteLoop: true,
								moveSlides: 1,
							});
						}
					},
					beforeSend: function () {
					},
					complete: function () {
					}
				});
			}
			
		});

	});
</script>
<!-- End <- Moneycontrol Common header -->
<script>
	function redirect() {
		window.location="http://www.moneycontrol.com"
	}
	setInterval("redirect()",35000);
</script>

<style>
.headline{
	text-align:justify; font-family:arial ; font-size:15; text-decoration:none; color:#244B8E;
}
.headline:hover{
	text-align:justify; font-family:arial ; font-size:15; text-decoration:underline;
}
</style>
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-156703-1";
urchinTracker("/404.html?page=" + _udl.pathname + _udl.search);
</script>
<body>
	<table width=770  style="padding-left:5">
		<tr>
			<td align="center">
				<script type="text/javascript"><!--
				google_ad_client = "ca-money_test_js";
				google_alternate_color = "FFFFFF";
				google_ad_width = 728;
				google_ad_height = 90;
				google_ad_format = "728x90_as";
				google_ad_type = "text";
				google_ad_channel ="1943430168";
				google_color_border = "FFFFFF";
				google_color_bg = "FFFFFF";
				google_color_link = ["CE0000","21498C"];
				google_color_url = "000066";
				google_color_text = "000000";
				//--></script>
				<script type="text/javascript" src="https://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
			</td>
		</tr>
	</table>
	<table>
		<tr>
			<td width="10px"></td>
			<td>
				<table border='0' width='720' style="border: solid 5px #EFEFEF">
					<tr>
						<td height="20px"></td>
						<td style="color:#244B8E">
							<p style="text-align:justify; font-family:arial ; font-size:15;">
								<h1>Not Found.</h1>
								Sorry, the requested page or object does not exist on this server. The link you followed is either outdated, inaccurate, or forbidden.<br><br>
								<b>
									<a href='https://moneycontrol.com/news/sitemap/sitemap.php' title="Site Map" class="headline">Site Map</a>
								</b><br><br>
								Our site map lists all the sections on Moneycontrol.com <br><a href="http://www.moneycontrol.com/news/sitemap/sitemap.php">Click here</a> to see our sitemap.<br><br>
								<b>
									<a href='https://www.moneycontrol.com/cdata/feedback.php' title="Feedback / Error" class="headline">Feedback / Error</a>
								</b><br><br>
								If you reached this page from a link on our site, please let us know at <a href="mailto:feedback@moneycontrol.com">feedback@moneycontrol.com</a> <br>Please mention the page you came from and the link you were trying to access.<br><br>
								<b><a href='https://www.moneycontrol.com' title="Homepage" class="headline">Homepage</a></b><br><br>
								<a href="https://www.moneycontrol.com" title="Click here">Click here</a> to go back to the homepage. <br><br>
								<br><br>
							</p>
						</td>
					</tr>
					<tr><td id="goto"></td></tr>
				</table>
			</td>
		</tr>
	</table>
	<table width="770" style="padding-left:5">
		<tr>
			<td align=center>
				<script type="text/javascript"><!--
				google_ad_client = "ca-money_test_js";
				google_alternate_color = "FFFFFF";
				google_ad_width = 728;
				google_ad_height = 90;
				google_ad_format = "728x90_as";
				google_ad_type = "text";
				google_ad_channel ="4311163670";
				google_color_border = "FFFFFF";
				google_color_bg = "FFFFFF";
				google_color_link = "0000FF";
				google_color_url = "000066";
				google_color_text = "000000";
				//--></script>
				<script type="text/javascript" src="https://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
			</td>
		</tr>
	</table>
</div>
<!-- Moneycontrol Common Footer -> Start -->
<script type="text/javascript">
	function readCookieFooter(e) {
		var t=e+"=";
		var n=document.cookie.split(";");
		for( var r=0; r < n.length; r++ ) {
			var i = n[r];
			while( i.charAt(0) == " " ) {
				i = i.substring( 1, i.length );
			}
			if( i.indexOf(t) == 0 ) {
				return i.substring( t.length, i.length )
			}
		}
		return false;
	}
</script>
	<script>
	var google_ad_code = "MC_180x600_Market";
	</script>
<script type="text/javascript" src="https://partner.googleadservices.com/gampad/google_service.js"></script>
<script type="text/javascript" src="https://stat2.moneycontrol.com/mcjs/common/https_mc_rhs_promo.js?ver=2"></script>
<link href="https://stat2.moneycontrol.com/mccss/markets/https_mkt_promo.css?v1" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://stat2.moneycontrol.com/mcjs/budget2013/jquery.jscrollpane.min.js"></script> 
<script type="text/javascript" src="https://stat2.moneycontrol.com/mcjs/budget2013/jquery.mousewheel.js"></script>
 
<style type="text/css">
.PA10{padding:10px;}
.PA3{padding:3px;}
.PT10{padding-top:10px;}
.PL5 {padding-left:5px;}
.PT2{padding-top:2px;}
.PT5{padding-top:5px;}
.PB5{padding-bottom:5px;}
.PB10{padding-bottom:10px;}
.FL {float:left;}
.FR {float:right;}
.CL {clear:both;}
.b_15{font:15px/18px arial; color:#000; text-decoration:none;}
.gL_15{font:15px/16px arial; color:#646464; text-decoration:none;}
.bl_15{font:14px/15px arial; color:#02536c; text-decoration:none;}
.gL_13{font:13px/16px arial; color:#646464; text-decoration:none;}
.googleinput1{padding:3px 2px; color:#333; border:1px solid #fff; font:bold 12px/16px Arial;width:115px;  background-position:1px 2px; filter:alpha(opacity=50); -moz-opacity:.5; opacity:.5;}
.googleinput2{padding:3px 2px; color:#333; border:1px solid #fff; font:bold 12px/16px Arial;width:115px; background:#fff;}
.brdb{border-bottom:1px solid #e9e9e9;}
.brd{border:1px solid #e9e9e9;}
.sms_track_16{font-family:arial; font-size:16px; color:#000000; font-weight:bold;}
.sms_track_13{font-family:arial; font-size:13px; color:#000000; font-weight:bold;}
.sms_track_12{font-family:arial; font-size:12px; color:#009CDA; font-weight:bold;}
.sms_track_19{font-family:arial; font-size:19px; color:#244D92; font-weight:bold;}
</style>

<script type="text/javascript">
function validation()
{
	if(document.login.login_id.value=="" || document.login.login_id.value=="User Id")
	{
		alert("Please enter your Login");
		document.login.login_id.focus();
		return false;
	}
	if(document.login.password.value=="")
	{
		alert("Please enter your Password");
		document.login.password.focus();
		return false;
	}
	document.login.action="https://www.moneycontrol.com/portfolio_plus/sso/login_verify_mc_new.php";
	document.login.submit();
}


function validate_mp_rhspoll()
{
	// set var radio_choice to false
	var radio_choice = false;

	// Loop from zero to the one minus the number of radio button selections
	for (counter = 0; counter < document.form_mp_rhspoll.radio_mp_poll.length; counter++)
	{
	// If a radio button has been selected it will return true
	// (If not it will return false)
		if (document.form_mp_rhspoll.radio_mp_poll[counter].checked)
		{
			radio_choice = true; 
			var check_var=counter+1;
		}
	}

	if (!radio_choice)
	{
		// If there were no selections made display an alert box 
		alert("Please select a option.")
		return (false);
	}
	
	if(check_var==1)
		pass_val="opt1";
	if(check_var==2)
		pass_val="opt2";
	if(check_var==3)
		pass_val="opt3";

	pollid=document.getElementById('pollid').value;
	window.open('https://mmb.moneycontrol.com/india/messageboard/poll_inter_all.php?op=poll&poll_id='+pollid+'&radio_mp_poll='+pass_val,'Polldetails'); 
	//window.open('poll_graph.php?op=poll&pollid='+pollid+'&radio_mp_poll='+pass_val,'Polldetails'); 
	//return true;
	return false;
}
</script>

<div class="FR" style="width:180px;">
	<!-- rotation widgets club with GE -->
	
	
	<div class="MT25" id="Moneycontrol/MC_Ros_Footer/MC_Ros_Footer_180x400_div">
		<div id='Moneycontrol/MC_Ros_Footer/MC_Ros_Footer_180x400'>
			<script type='text/javascript'>
				if(rhs_180x400 == true){
					googletag.cmd.push(function() { googletag.display('Moneycontrol/MC_Ros_Footer/MC_Ros_Footer_180x400'); });
				}
			</script>
		</div>	
	</div>




	<!-- rotation widgets club with GE -->
		

	<!--START: Terminal & Sherkhan -->

	<div id="LUXURY_WIDGET"></div>


	<div class="PB10">
		<div id="STKMF_LV"></div>
		<div id="backInner1_rhsPop"></div>
		<div id="backInner1_rhsLogin" style="display:none;z-index:99999;"></div>
	</div>

	<div style="display:none;">
	  		 		 		
	</div> 

		
	

		<div class="PB10">
		
				<script type='text/javascript'>
					   if(rhs_180x300_1 == true){
						if(rhs_180x300_1_currencies == true){ //Mecklai prmotion requirment
							document.write('<div id="Moneycontrol/MC_Market/MC_Market_Currencies_180x300_1_div"><div id="Moneycontrol/MC_Market/MC_Market_Currencies_180x300_1">');
							googletag.cmd.push(function() { googletag.display('Moneycontrol/MC_Market/MC_Market_Currencies_180x300_1'); });
							document.write('</div></div>');
						}else{
							document.write('<div id="Moneycontrol/MC_Ros_Footer/MC_Ros_Footer_180x300_1_div"><div id="Moneycontrol/MC_Ros_Footer/MC_Ros_Footer_180x300_1">');
							googletag.cmd.push(function() { googletag.display('Moneycontrol/MC_Ros_Footer/MC_Ros_Footer_180x300_1'); });
							document.write('</div></div>');
						}
					}
				</script>
	</div>	

	
		


	
	<div class="PB10">
	<link href="https://stat.moneycontrol.co.in/mccss/markets/https_mkt_promo.css?v3" rel="stylesheet" type="text/css" />
 	<style>.pyt_org_13 {  color: #f15804;  font: bold 13px Trebuchet MS,Arial; } #pytfot_rhs .our_pack h3 {font: 15px/33px Arial;}</style>
 	<script type="text/javascript">
 		$(document).ready(function() {		
 			$(".pyt_opc").hide();
 			$(".our_pack h3:eq(0)").addClass("act").next().show();
 			
 			$(".our_pack h3").click( function(){
 				if($(this).next().is(":hidden")){
 					$(".our_pack h3").removeClass("act").next().slideUp("slow");
 					$(this).addClass("act").next().slideDown("slow");				
 				}
 				else{
 					$(this).removeClass("act").next().slideUp("slow");		
 				}
 			});
 		});
 
 		var cnt_round = 0;
 		var cnt_winner_round = 0;
 
 		var str_intraday_picks = "buy_btn|TVS Motor|519.95|INTRADAY HIGH (Rs)|532.70|ar_grn|13###buy_btn|Century|911.30|INTRADAY HIGH (Rs)|932.95|ar_grn|22###buy_btn|Arvind|419.70|INTRADAY HIGH (Rs)|434.90|ar_grn|15###buy_btn|Hindalco|211.60|INTRADAY HIGH (Rs)|216.80|ar_grn|5###buy_btn|Kesoram|84.00|INTRADAY HIGH (Rs)|86.80|ar_grn|3###buy_btn|Jamna Auto|85.70|INTRADAY HIGH (Rs)|87.40|ar_grn|2###buy_btn|HBL Power|37.40|INTRADAY HIGH (Rs)|38.95|ar_grn|2###buy_btn|Time Techno|150.00|INTRADAY HIGH (Rs)|153.40|ar_grn|3###buy_btn|IRB Infra|203.00|INTRADAY HIGH (Rs)|206.65|ar_grn|4";
 		var cnt_rec = 9;
 
 		var str_alltime_winner = "Eicher Motors|354|30 Jul 2007|33484|ar_grn|9370.78###Hawkins Cooker|119|23 Jun 2007|5540|ar_grn|4545.66###Ricoh India Ltd|29|23 Jul 2007|1072|ar_grn|3591.05###Hitachi Home and Life Sol|102|02 Jul 2007|3375|ar_grn|3205.58###Venkys|157|04 Sep 2007|4711|ar_grn|2899.84###Balaji Amines|29|29 Dec 2009|781|ar_grn|2618.41###Kovai Medical Centre & Ho|55|01 Jun 2007|1480|ar_grn|2590.91###GMM Pfaudler|160|24 Apr 2006|4090|ar_grn|2456.25###3M India|1150|05 Sep 2006|26679|ar_grn|2219.93";
 		var cnt_winner = 9;
 
 		function load_picks(str_all_time_win, cnt_rec){
 			if(cnt_round==cnt_rec){
 				cnt_round = 0;
 			}
 
 			if(cnt_round>0){
 				$("#intraday_picks").hide();
 			}
 			
 			var arr_intraday_picks = new Array();
 			var arr_intraday_elements = new Array();
 
 			arr_intraday_picks = str_intraday_picks.split("###");			
 			arr_intraday_elements = arr_intraday_picks[cnt_round].split("|");
 			//sell_btn||Larsen|1230.50|INTRADAY LOW (Rs)|1220.00|ar_grn|11
 	
 			$("#buy_sell").removeClass();
 			$("#gain_div").removeClass();
 
 			$("#buy_sell").addClass(arr_intraday_elements[0]);
 			if(arr_intraday_elements[0]=="buy_btn"){
 				$("#buy_sell").text("buy");
 			}else if(arr_intraday_elements[0]=="sell_btn"){
 				$("#buy_sell").text("sell");
 			}
 
 			$("#sc_comp_name").html(arr_intraday_elements[1]);
 
 			if(arr_intraday_elements[1].length>14){
 				$("#sc_comp_name").css("font","13px Arial");
 			}
 
 			$("#opening_price").html(arr_intraday_elements[2]);
 			$("#heading").html(arr_intraday_elements[3]);
 			$("#record").html(arr_intraday_elements[4]);
 			$("#gain_div").addClass(arr_intraday_elements[5]);
 			$("#gainloass").html(arr_intraday_elements[6]);
 			if(cnt_round==0){
 				$("#intraday_picks").show("slow");
 			}else{
 				$("#intraday_picks").fadeIn("slow");
 			}
 			cnt_round++;
 		}
 		function load_winner(str_alltime_winner, cnt_rec){
 			if(cnt_winner_round==cnt_rec){
 				cnt_winner_round = 0;
 			}
 
 			if(cnt_winner_round>0){
 				$("#all_time_win").hide();
 			}
 			$("#dir_img").removeClass();
 			var arr_alltime_winner = new Array();
 			arr_alltime_winner = str_alltime_winner.split("###");
 			arr_winner_elements = arr_alltime_winner[cnt_winner_round].split("|");
 			
 			$("#win_sc_comp").html(arr_winner_elements[0]);
 			$("#rec_price").html(arr_winner_elements[1]);
 			$("#call_date").html(arr_winner_elements[2]);
 			$("#peak_price").html(arr_winner_elements[3]);
 			$("#dir_img").addClass(arr_winner_elements[4]);
 			$("#tot_perc").html(arr_winner_elements[5]);
 			if(cnt_winner_round==0){
 				$("#all_time_win").show("slow");
 			}else{
 				$("#all_time_win").fadeIn("slow");
 			}
 			cnt_winner_round++;
 		}
 		setInterval("load_picks(str_intraday_picks,cnt_rec);load_winner(str_alltime_winner,cnt_winner)", 5000);
 		setTimeout("load_picks(str_intraday_picks,cnt_rec);load_winner(str_alltime_winner,cnt_winner)", 5);
 	</script>
 	<div class="brd MT15" id="pytfot_rhs" style="width:178px; background:#FFF;">
 		<div onclick="javascript:window.open('https://poweryourtrade.moneycontrol.com/plus/login/login.php?utm_source=PYTRHS_MC')" style="cursor:pointer;">
 			<div class="pulogo"></div>
 			<div class="win_strip">
 				<div class="ourwin_txt">OUR WINNING PICKS</div>
 				<p><span class="gray_txt">DID YOU INVEST?</span></p>
 			</div>
 			
 			<div class="pyt_content">
 				<h3 class="org_14">INTRADAY <span class="gry_14">PICKS!</span></h3>
 				<p><span class="gry_10">(August 06, 2018)</span></p>
 				<div class="area" style="position: relative; height:87px;">				
 					<div class="pyt_area">
 						<div class="curv_top"></div>
 						<div class="curv_bg" id="intraday_picks">
 							<div class="head_txt clearfix">
 								<a id="buy_sell"></a>
 								<span class="gry_15_r ML10 FL MT5" id="sc_comp_name"></span>		
 							</div>
 
 							<div>
 								<table border="0" cellspacing="0" cellpadding="0">
 									<tr>
 										<td class="brdr ar_9 PA5" align="center" valign="top" height="50">
 											<p>AT (Rs)<br />
 												<span class="gry_15_b" id="opening_price"></span>
 											</p>
 										</td>
 
 										<td class="PL3 PT5 ar_9" valign="top">
 											<p>
 												<span id="heading"></span><br />
 												<span class="gry_15_b" id="record"></span>
 												<br />GAIN (Rs)
 												<span id="gain_div"></span>
 												<span id="gainloass"></span>
 											</p>
 										</td>
 									</tr>
 								</table>
 							</div>
 						</div>
 						<div class="curv_bottom"></div>
 					</div>	 			
 				</div>
 				<h3 class="org_15 MT20"><span class="gry_15">ALL TIME</span> WINNERS</h3>
 				<div id="all_time_win">
 					<div class="pyt_area">
 						<div class="curv_top"></div>
 						<div class="curv_bg">
 							<div class="head_txt gry_15_r clearfix">
 								<span class="PL5" id="win_sc_comp"></span>
 							</div>
 							
 							<div>
 								<table border="0" cellspacing="0" cellpadding="0">
 									<tr>
 										<td class="brdr ar_9 PT5 PL5 PR5" align="center" valign="top" height="52">
 											<p>RECO PRICE<br />
 												<span class="gry_15_b" id="rec_price"></span><br />
 												<span id="call_date"></span>
 											</p>
 										</td>
 										
 										<td class="PL3 PT5 ar_9" valign="top">
 											<p>PEAK PRICE<br />
 												<span class="gry_15_b" id="peak_price"></span>
 												<span id="dir_img"></span>
 												<span id="tot_perc"></span>
 											</p>
 										</td>
 									</tr>
 								</table>
 							</div>
 						</div>
 						<div class="curv_bottom"></div>
 					</div>
 								
 				</div>
 			</div>
 		</div>
 		<div class="CL"></div>
 		<div class="PA5 MT10">
 			<h3 class="org_15 MB5"><span class="gry_15">OUR</span> PACKAGES</h3>
 			<div class="our_pack">
 				<h3><span class="pyt_arw"></span>Super Combo <br /></h3>
 				<div class="pyt_opc">
 					<img src="https://images.moneycontrol.com/images/promo/thumb.jpg" width="41" height="40" alt="" class="FL MR10" />
 					<p class="gD_12">Powerful mix of both trader and investor packs with timely expert advice.</p>
 				</div>
 				<h3><span class="pyt_arw"></span>Technical<br /></h3>
 				<div class="pyt_opc">
 					<img src="https://images.moneycontrol.com/images/promo/technical_thumb.jpg" width="41" height="40" alt="" class="FL MR10" />
 					<p class="gD_12">Designed especially for traders looking to tap the profit opportunities of volatile markets.</p>
 				</div>
 				<h3 class="MT5"><span class="pyt_arw"></span>Fundamental<br /></h3>
 				<div class="pyt_opc" style="border-bottom:1px solid #cacaca">
 					<img src="https://images.moneycontrol.com/images/promo/fundamental_thumb.jpg" width="41" height="40" alt="" class="FL MR10" />
 					<p class="gD_12">For all investors looking to unearth stocks that are poised to move.</p>
 				</div>
 			</div>
 		</div>
 		 <div class="pyt_btm"><input name="s" type="button" class="subs_now" onclick="javascript:window.open('https://poweryourtrade.moneycontrol.com/plus/login/login.php?utm_source=PYTRHS_MC')"/></div> 
 	</div>	</div>
		<div id="Moneycontrol/MC_Ros_Footer/MC_Ros_Footer_180x300_2_div">
		<div id='Moneycontrol/MC_Ros_Footer/MC_Ros_Footer_180x300_2'>
			<script type='text/javascript'>
				if(rhs_180x300_2 == true){
					googletag.cmd.push(function() { googletag.display('Moneycontrol/MC_Ros_Footer/MC_Ros_Footer_180x300_2'); });
				}
			</script>
		</div>	
	</div>

	<div id="moneybhai_rhs_widget"></div>
	<div id="pyt_rhs_widget"></div>

	<div class="PB10">
			</div>

           <script>
			   var mobile_promo_pricehcart;
			   if(mobile_promo_pricehcart=="companypromo")
			   {
				   document.write('<div class="PB10"><table cellpadding=0 cellspacing=0 border=0 style="border: 1px solid #D5D5D5;" width=180px><tr bgcolor=E7E7E7><td align=left valign=top class=sms_track_13 style="padding-left:5;padding-right:5; padding-top:5; padding-bottom:5;">Get <font class=sms_track_16>daily SMS</font> updates on<br><font class=sms_track_19> '+companyname+' </font></td></tr> <tr><td align=right valign=top style="padding-left:5;padding-right:5; padding-top:2; padding-bottom:2;"><img src="https://images.moneycontrol.com/images/stock_track/promo/poweredby.gif" vspace=0 hspace=0 border=0></td></tr>						<tr><td height=10px></td></tr><tr>  <td align=left valign=top class=sms_track_12 style="padding-left:5;padding-right:5; padding-top:2; padding-bottom:2;"><img src="https://images.moneycontrol.com/images/stock_track/promo/green_tick.gif" vspace=0 hspace=0 border=0> 3 Price alerts</td>  </tr> <tr><td align=left valign=top class=sms_track_12 style="padding-left:5;padding-right:5; padding-top:2; padding-bottom:2;"><img src="https://images.moneycontrol.com/images/stock_track/promo/green_tick.gif" vspace=0 hspace=0 border=0> Price trigger cutoffs</td> </tr>  <tr>  <td align=left valign=top class=sms_track_12 style="padding-left:5;padding-right:5; padding-top:2; padding-bottom:2;"><img src="https://images.moneycontrol.com/images/stock_track/promo/green_tick.gif" vspace=0 hspace=0 border=0> Breaking News</td>  </tr> <tr>	  <td align=left valign=top class=sms_track_12 style="padding-left:5;padding-right:5; padding-top:2; padding-bottom:2;"><img src="https://images.moneycontrol.com/images/stock_track/promo/green_tick.gif" vspace=0 hspace=0 border=0> Expert views</td>	  </tr>	    <tr>	  <td align=left valign=top class=sms_track_12 style="padding-left:5;padding-right:5; padding-top:2; padding-bottom:2;"><img src="https://images.moneycontrol.com/images/stock_track/promo/green_tick.gif" vspace=0 hspace=0 border=0> Bulk Deals</td>  </tr>	    <tr>	  <td align=left valign=top class=sms_track_12 style="padding-left:5;padding-right:5; padding-top:2; padding-bottom:2;"><img src="https://images.moneycontrol.com/images/stock_track/promo/green_tick.gif" vspace=0 hspace=0 border=0> Dividend alerts</td>	  </tr>	    <tr>  <td align=left valign=top class=sms_track_12 style="padding-left:5;padding-right:5; padding-top:2; padding-bottom:2;"><img src="https://images.moneycontrol.com/images/stock_track/promo/green_tick.gif" vspace=0 hspace=0 border=0> Bonus News</td>	  </tr>	    <tr>  <td align=left valign=top class=sms_track_12 style="padding-left:5;padding-right:5; padding-top:2; padding-bottom:2;"><img src="https://images.moneycontrol.com/images/stock_track/promo/green_tick.gif" vspace=0 hspace=0 border=0> Split News</td>	  </tr>	  <tr><td height=15px><form name="stk_track" id="stk_track" method="post" action="https://www.moneycontrol.com/stock_track/registration_new.php" target="_blank"><INPUT TYPE="hidden" NAME="pricechart_sms_promo" ID="pricechart_sms_promo" value="sms_promo_pc"></td></tr>		<tr><td align=center valign=top><input type="image" src="https://images.moneycontrol.com/images/stock_track/promo/activate_butt.gif" vspace=0 hspace=0 border=0 name="submit"></td></tr>	  <tr><td height=15px></FORM></td></tr>  </table></div>');
			   }
           </script>	
           <div class="CL"></div>
           <div style='padding:10px 0px 7px 0px'><div id='googleAd_dis'></div></div>
           		   <div class="CL"></div>
           		  </div>
      <div class="CL"></div>
    </div>
  </div>
</div>
 <div class="CL"></div>
<footer class="footer_desktop ">
  <div class="main-wrapper">
		<div class="clearfix">
			<div class="FL ic_logofooter MT5"> </div>
			<div class="FL fsoci"> 
				<a href="https://mmb.moneycontrol.com/" title="Forum" onclick="GAEventTracker( 'Footer Social', 'Forum', window.location.href );" target="_blank" rel="noopener" class="ic_forum" style="text-indent:-9999px;">Forum</a> 
				<a href="https://www.facebook.com/moneycontrol" title="Facebook" onclick="GAEventTracker( 'Footer Social', 'Facebook', window.location.href );" target="_blank" rel="noopener" class="ic_fb" style="text-indent:-9999px;">Facebook</a> 
				<a href="https://twitter.com/moneycontrolcom" title="Twitter"  onclick="GAEventTracker( 'Footer Social', 'Twitter', window.location.href );" target="_blank" rel="noopener" class="ic_tweet" style="text-indent:-9999px;">Twitter</a> 
				 
				<a href="https://www.instagram.com/moneycontrolcom/" title="Instagram"  onclick="GAEventTracker( 'Footer Social', 'Instagram', window.location.href );" target="_blank" rel="noopener" class="ic_instagram_mn" style="text-indent:-9999px;">Instagram</a> 
				<a href="https://www.linkedin.com/company/moneycontrol" title="Linkedin"  onclick="GAEventTracker( 'Footer Social', 'Linkedin', window.location.href );" target="_blank" rel="noopener" class="ic_in" style="text-indent:-9999px;">Linkedin</a> 
				 
				<a href="https://www.moneycontrol.com/india/newsarticle/rssfeeds/rssfeeds.php" title="RSS"  onclick="GAEventTracker( 'Footer Social', 'RSS', window.location.href );" target="_blank" class="ic_blg" style="text-indent:-9999px;">RSS</a> 
				<a href="https://t.me/moneycontrolcom" title="Telegram"  onclick="GAEventTracker( 'Footer Social', 'Telegram', window.location.href );" target="_blank" rel="noopener" class="ic_tg"></a>
				 <a href="https://jionews.com/home/articles/moneycontrol/58" title="JioNews"  onclick="GAEventTracker( 'Footer Social', 'JioNews', window.location.href );" target="_blank" rel="noopener" class="ic_jionews"></a>
			</div>
		</div>
    <div class="bgwhite clearfix MT15 PR"> <a href="javascript:void(0);" onclick="go_on_top();" title="Go on top" class="FR gotop"></a>
      <div class="FL footleft">
        <div class="clearfix brd_b PB10">
          <ul class="flinkl1 FL ">
            <li><a href="https://www.moneycontrol.com/india/bestportfoliomanager/investment-tool" title="Portfolio">Portfolio</a></li>
            <li><a href="https://www.moneycontrol.com/stocksmarketsindia/" title="Markets">Markets</a></li>
            <li><a href="https://www.moneycontrol.com/portfolio_demo/stock_watchlist.php" title="Watchlist">Watchlist</a></li>
            <li><a href="https://www.moneycontrol.com/tv/" title="Live TV Show">Live TV Show</a></li>
            <li><a href="https://www.moneycontrol.com/mccode/currencies/" title="Currencies">Currencies</a></li>
            <li><a href="https://www.moneycontrol.com/commodity/" title="Commodities">Commodities</a></li>
            <li><a href="https://www.moneycontrol.com/fixed-income/" title="Fixed Income">Fixed Income</a></li>
            <li><a href="https://www.moneycontrol.com/personal-finance/" title="Personal Finance">Personal Finance</a></li>
          </ul>
          <ul class="flinkl1 FL">
            <li><a href="https://www.moneycontrol.com/mutualfundindia/" title="Mutual Fund">Mutual Fund</a></li>
                        <li><a href="https://www.moneycontrol.com/markets/premarket/" title="Pre-Market">Pre-Market</a></li>
            <li><a href="https://www.moneycontrol.com/ipo/" title="IPO">IPO</a></li>
            <li><a href="https://www.moneycontrol.com/markets/global-indices/" title="Global Market">Global Market</a></li>
						<li><a href="https://www.moneycontrol.com/budget-2022/" title="Budget 2022">Budget 2022</a></li>
            <li><a href="https://www.moneycontrol.com/sensex/bse/sensex-live" title="BSE Sensex">BSE Sensex</a></li>
            <li><a href="https://mmb.moneycontrol.com/" title="Forum" target="_blank" rel="noopener">Forum</a></li>
			<li>
				<a href="https://www.moneycontrol.com/mutual-fund/mc-30" title="MC30 Funds">
				MC 30 <sup class="new_tagtp">
							<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 28 15">
								<g id="Layer_2" data-name="Layer 2">
									<g id="Layer_1-2" data-name="Layer 1">
										<rect class="newtag-1" width="28" height="15" rx="7.5"/>
										<path class="newtag-2" d="M7.42,6.84c0-.4,0-.73,0-1H8l0,.64h0a1.44,1.44,0,0,1,1.28-.72c.54,0,1.37.32,1.37,1.64V9.66H10V7.43c0-.62-.24-1.14-.9-1.14A1,1,0,0,0,8.17,7a1.09,1.09,0,0,0-.05.33V9.66h-.7Z"/>
										<path class="newtag-2" d="M12.25,7.86A1.23,1.23,0,0,0,13.58,9.2,2.6,2.6,0,0,0,14.65,9l.12.5a3,3,0,0,1-1.29.24,1.79,1.79,0,0,1-1.9-1.95,1.87,1.87,0,0,1,1.81-2.08A1.64,1.64,0,0,1,15,7.53c0,.14,0,.26,0,.33Zm2.06-.51a1,1,0,0,0-1-1.14,1.16,1.16,0,0,0-1.08,1.14Z"/>
										<path class="newtag-2" d="M16.14,5.79l.52,2c.11.43.21.83.28,1.23h0a12.5,12.5,0,0,1,.34-1.22l.63-2h.59l.6,1.94c.15.46.26.87.35,1.26h0a12.41,12.41,0,0,1,.3-1.25l.55-1.95H21L19.8,9.66h-.64l-.59-1.84c-.14-.43-.25-.82-.35-1.27h0a12,12,0,0,1-.36,1.28l-.62,1.83h-.64L15.42,5.79Z"/>
									</g>
								</g>
							</svg>
						</sup>
				</a>
			</li>
          </ul>
          <div class="flinkl2 FR">
            <div class="flhd1 PL5">News</div>
            <ul class="flinkl2">
              <li><a href="https://www.moneycontrol.com/news/business" title="Business">Business</a></li>
              <li><a href="https://www.moneycontrol.com/news/business/markets" title="Markets">Markets</a></li>
              <li><a href="https://www.moneycontrol.com/news/business/stocks" title="Stocks">Stocks</a></li>
              <li><a href="https://www.moneycontrol.com/news/business/economy" title="Economy">Economy</a></li>
              <li><a href="https://www.moneycontrol.com/news/business/mutual-funds" title="Mutual Funds">Mutual Funds</a></li>
              <li><a href="https://www.moneycontrol.com/news/business/personal-finance" title="Personal Finance">Personal Finance</a></li>
              <li><a href="https://www.moneycontrol.com/news/business/ipo" title="IPO News">IPO News</a></li>
              <li><a href="https://www.moneycontrol.com/news/business/startups" title="Startups">Startups</a></li>
            </ul>
          </div>
        </div>
        <div class="PB10 brd_b MT5">
          <div class="flS2">
            <span class="tx14_blu"><a href="https://www.moneycontrol.com/india/stockpricequote/" title="Stocks">Stocks</a>:</span> 
                          <a href="https://www.moneycontrol.com/india/stockpricequote/A" title="A"> A</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/B" title="B"> B</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/C" title="C"> C</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/D" title="D"> D</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/E" title="E"> E</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/F" title="F"> F</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/G" title="G"> G</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/H" title="H"> H</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/I" title="I"> I</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/J" title="J"> J</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/K" title="K"> K</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/L" title="L"> L</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/M" title="M"> M</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/N" title="N"> N</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/O" title="O"> O</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/P" title="P"> P</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/Q" title="Q"> Q</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/R" title="R"> R</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/S" title="S"> S</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/T" title="T"> T</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/U" title="U"> U</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/V" title="V"> V</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/W" title="W"> W</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/X" title="X"> X</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/Y" title="Y"> Y</a> |
                          <a href="https://www.moneycontrol.com/india/stockpricequote/Z" title="Z"> Z</a> |
                        <a href="https://www.moneycontrol.com/india/stockpricequote/others" title="Others">Others</a>
          </div>
          <div class="flS2"> 
            <span class="tx14_blu">Mutual Funds:</span> 
                          <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/A" title="A"> A</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/B" title="B"> B</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/C" title="C"> C</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/D" title="D"> D</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/E" title="E"> E</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/F" title="F"> F</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/G" title="G"> G</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/H" title="H"> H</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/I" title="I"> I</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/J" title="J"> J</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/K" title="K"> K</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/L" title="L"> L</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/M" title="M"> M</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/N" title="N"> N</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/O" title="O"> O</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/P" title="P"> P</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/Q" title="Q"> Q</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/R" title="R"> R</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/S" title="S"> S</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/T" title="T"> T</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/U" title="U"> U</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/V" title="V"> V</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/W" title="W"> W</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/X" title="X"> X</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/Y" title="Y"> Y</a> 
             |               <a href="https://www.moneycontrol.com/india/mutualfunds/mutualfundsinfo/snapshot/Z" title="Z"> Z</a> 
                      </div>
        </div>
		<div class="MT10 clearfix brd_b PB10">
			<div class="ic_crn FL"></div>
				<div class="FL ML15">
				<div class="tx14_blu">Visit the App Store to see all our apps:</div>
				<div class="clearfix MT5">
					<a class="FL ic_apple MR10" target="_blank" rel="noopener" title="Download from Google Play" href="https://play.google.com/store/apps/details?id=com.divum.MoneyControl&referrer=utm_source%3DWebAppsPage%26utm_medium%3DInstallButton" style="text-indent:-9999px;">Download from Google Play</a>
					<a class="FL ic_apGl MR10" target="_blank" rel="noopener" title="Download from APP Store" href="https://itunes.apple.com/app/apple-store/id408654600?pt=433541&ct=WebAppsPage_Install&mt=8" style="text-indent:-9999px;">Download from APP Store</a>
					<a class="FL ic_apwin" target="_blank" rel="noopener" title="Download from Windows Phone" href="https://apps.microsoft.com/windows/en-in/app/a4555fed-7225-4159-8569-8cfac5e412e0" style="text-indent:-9999px;">Download from Windows Phone</a>
				</div>
			</div>
        </div>

					<div class="MT10 clearfix">
								<a target="_blank" title="ISO 27001 - BSI Assurance Mark" href="https://images.moneycontrol.com/pdffiles/IS-739420-I.pdf" rel="noopener">
					<img width="137" height="70" src="https://images.moneycontrol.com/images/common/headfoot/bsi-cert2b.png" alt="ISO 27001 - BSI Assurance Mark" title="ISO 27001 - BSI Assurance Mark" />
				</a>
			</div>
		      </div>
      <div class="FR clearfix footright">
        <div class="FL w170">
          <div class="flinkl2">
            <div class="flhd1 PL5">Tools</div>
            <ul>
              <li><a href="https://www.moneycontrol.com/personal-finance/tools/retirement-planning-calculator.html" title="Retirement Planning">Retirement Planning</a></li>
              <li><a href="https://www.moneycontrol.com/personal-finance/tools/emi-calculator.html" title="EMI Calculator">EMI Calculator</a></li>
              <li><a href="https://www.moneycontrol.com/mf/sipcalculator.php" title="SIP Calculator">SIP Calculator</a></li>
              <li><a href="https://www.moneycontrol.com/mf/sipplanner.php" title="SIP Planner">SIP Planner</a></li>
				            </ul>
          </div>
			<div class="flinkl2 MT20">
				<div class="flhd1 PL5"> Useful Links</div>
				<ul>
																																			<li><a href="https://www.moneycontrol.com/cryptocurrency/" title="Crypto News">Crypto News</a></li>
					<li><a href="https://www.moneycontrol.com/news/bank-holidays/" title="Bank Holidays in India">Bank Holidays in India</a></li>
					<li><a href="https://www.moneycontrol.com/news/gold-rates-today/" title="Gold Rate Today">Gold Rate Today</a></li>
					<li><a href="https://www.moneycontrol.com/news/trends/" title="Trending News">Trending News</a></li>
					<li><a href="https://www.moneycontrol.com/news/technology-startups/" title="Startups">Startups</a></li>
					<li><a href="https://www.moneycontrol.com/news/" title="National News">National News</a></li>
										<li><a href="https://www.moneycontrol.com/video-shows/" title="MC Videos">MC Videos</a></li>
					<li><a href="https://www.youtube.com/user/moneycontrol/featured" title="MC You Tube" target="_blank" rel="noopener">MC You Tube</a></li>
					<li><a href="https://www.moneycontrol.com/news/house-purchase-affordability-in-top-affordable-cities-in-india/" title="House Purchase Index">House Purchase Index</a></li>
										<li><a href="https://www.moneycontrol.com/india/bestportfoliomanager/investment-tool" title="Best Portfolio Manager">Best Portfolio Manager</a></li>
					<li><a href="https://www.moneycontrol.com/fixed-income/small-savings-schemes/" title="Small Savings Schemes">Small Savings Schemes</a></li>
					<li><a href="https://www.moneycontrol.com/fixed-income/bonds/listed-bonds/" title="Bonds">Bonds</a></li>
					<li><a href="https://www.topperlearning.com/" title="TopperLearning" target="_blank" rel="noopener">TopperLearning</a></li>
																									<li><a href="https://www.topperlearning.com/doubts-solutions/all-questions/" title="Clear Study Doubts" target="_blank" rel="noopener">Clear Study Doubts</a></li>
					<li>
						<a href="https://www.topperlearning.com/become-partner" title="Education Franchisee Opportunity" target="_blank" rel="noopener" style="display: inline-block;padding: 1px 5px;">Education Franchisee Opportunity</a>
					</li>
																			</ul>
			</div>
        </div>
        <div class="FR w170">
          <div class="flinkl2">
            <div class="flhd1 PL5">Specials</div>
            <ul>
              <li><a href="https://www.moneycontrol.com/master-your-money/?utm_source=specials" title="Master Your Money" target="_blank">Master Your Money</a></li>
              <li><a href="https://www.moneycontrol.com/gamechangers/" title="Game Changers" target="_blank">Game Changers</a></li>
												              <li><a href="https://investmentwatch.moneycontrol.com/" title="Investment Watch" target="_blank" rel="noopener">Investment Watch</a></li>
              <li><a href="https://poweryourtrade.moneycontrol.com/" title="PowerYourTrade" target="_blank" rel="noopener">PowerYourTrade</a></li>
              <li><a href="https://moneybhai.moneycontrol.com/" title="MoneyBhai" target="_blank" rel="noopener">MoneyBhai</a></li>
            </ul>
          </div>
          <div class="flinkl2 MT15">
            <div class="flhd1 PL5">Focus</div>
            <ul>
												<li><a href="https://www.moneycontrol.com/sme/" title="SME Step Up" target="_blank">SME Step Up</a></li>
            </ul>
          </div>
			<div class="flinkl2 MT15">
				<div class="flhd1 PL5">Network 18 Sites</div>
				<ul>
					<li><a href="https://www.news18.com/" title="News18" target="_blank">News18</a></li>
					<li><a href="https://www.firstpost.com/" title="Firstpost" target="_blank" rel="noopener">Firstpost</a></li>
					<li><a href="https://www.cnbctv18.com/" title="CNBC TV18" target="_blank" rel="noopener">CNBC TV18</a></li>
										<li><a href="https://hindi.news18.com/" title="News18 Hindi" target="_blank" rel="noopener">News18 Hindi</a></li>
					<li><a href="https://www.news18.com/cricketnext/" title="Cricketnext" target="_blank" rel="noopener">Cricketnext</a></li>
					<li><a href="https://overdrive.in/" title="Overdrive" target="_blank" rel="noopener">Overdrive</a></li>
					<li><a href="https://www.topperlearning.com/" title="Topper Learning" target="_blank" rel="noopener">Topper Learning</a></li>
				</ul>
			</div>
        </div>
      </div>
    </div>
    <div class="ftCopy">
      <div class="flastLInk MT10">
        <a href="https://www.moneycontrol.com/cdata/aboutus.php" title="About us">About us</a> | 
        <a href="https://www.moneycontrol.com/cdata/contact.php" title="Contact Us">Contact Us</a> | 
		<a href="https://www.moneycontrol.com/advertise-on-moneycontrol.html" title="Advertise with Us">Advertise with Us</a> | 
        		        <a href="javascript:;" title="Support" onclick="javascript:openVerloopWidget();">Support</a> |
        <a href="https://www.moneycontrol.com/cdata/disclaim.php" title="Disclaimer">Disclaimer</a> | 
        <a href="https://www.moneycontrol.com/cdata/privacypolicy.php" title="Privacy Policy">Privacy Policy</a> | 
		<a href="https://www.moneycontrol.com/cdata/gdpr_cookiepolicy.php" title="Cookie Policy">Cookie Policy</a> | 
        <a href="https://www.moneycontrol.com/cdata/termsofuse.php" title="Terms & Conditions">Terms & Conditions</a> | 
        <a href="https://www.moneycontrol.com/career/" title="Careers">Careers</a> | 
        <a href="https://www.moneycontrol.com/glossary/" title="Financial Terms (Glossary)">Financial Terms (Glossary)</a> | 
        <a href="https://www.moneycontrol.com/faqs/" title="FAQs"> FAQs</a> | 
                <a href="https://www.moneycontrol.com/sitemap.php" title="Sitemap"> Sitemap</a> | 
        <a href="https://www.moneycontrol.com/india/newsarticle/rssfeeds/rssfeeds.php" title="RSS Feed">RSS Feed</a>
      </div>
      <p class="copyright MT10"> Copyright © e-Eighteen.com Ltd. All rights reserved. Reproduction of news articles, photos, videos or any other content in whole or in part in any form 
        or medium without express writtern permission of moneycontrol.com is prohibited.</p>
    </div>
	  </div>
<style>
			.adfloat{width:160px; margin-left: -165px; position: absolute; top: 250px; z-index: 99999;}
		.posfixadd{position:fixed; top:0;}
	@media only screen and (max-width:1279px){
	  .adfloat{display: none;}
	}
</style>
<script>
if($('.adfloat').length) {
	var scradd = $(".adfloat").eq(0).offset().top;
	$(window).scroll(function(){
		if ($(window).scrollTop() > scradd){
			$('.adfloat').addClass('posfixadd');
		} else {
			$('.adfloat').removeClass('posfixadd');   
		}
	});
}
</script>
</footer>
<input type="hidden" id="is_news_module" name="is_news_module" class="is_news_module" value="0" style="width:15px;" readonly />

<!-- Bottom Menu -> Start -->
<ul class="footer_navigation_list hide_in_desktop">
		<li class="">
		<a href="https://www.moneycontrol.com/" title="Home" onclick="GAEventTracker( 'Navigation', 'Bottom', 'Home' );">
			<div class="wap_ic_home">
				<svg xmlns="https://www.w3.org/2000/svg" width="23.53" height="18" viewBox="0 0 23.53 18">
					<g id="Group_4" data-name="Group 4" transform="translate(-220.953 -435.525)" opacity="0.5">
						<path id="Path_15" data-name="Path 15" d="M221.453,453.025V436.284h2.88a1.1,1.1,0,0,1,1.14.838l.255.905a8.765,8.765,0,0,1,.81-.8,5.176,5.176,0,0,1,.907-.63,4.861,4.861,0,0,1,1.051-.42,4.694,4.694,0,0,1,1.237-.154,3.478,3.478,0,0,1,2.332.784,4.876,4.876,0,0,1,1.4,2.09,4.935,4.935,0,0,1,.952-1.324,5.109,5.109,0,0,1,1.215-.887,5.569,5.569,0,0,1,1.381-.5,6.591,6.591,0,0,1,1.447-.163,6.16,6.16,0,0,1,2.37.428,4.5,4.5,0,0,1,1.732,1.243,5.484,5.484,0,0,1,1.058,2,9.253,9.253,0,0,1,.36,2.689v10.638h-4.65V442.387q0-2.6-2.07-2.6a2.049,2.049,0,0,0-1.568.669,2.733,2.733,0,0,0-.622,1.93v10.638h-4.65V442.387a3.013,3.013,0,0,0-.525-2.018,1.972,1.972,0,0,0-1.545-.581,2.44,2.44,0,0,0-1.192.307,4.33,4.33,0,0,0-1.058.822v12.108Z" fill="#fff" stroke="#333" stroke-width="1"></path>
					</g>
				</svg>
			</div>
			<div class="wap_ic_home_active">
				<svg xmlns="https://www.w3.org/2000/svg" width="22.53" height="17" viewBox="0 0 22.53 17">
					<path id="Path_15" data-name="Path 15" d="M221.453,453.025V436.284h2.88a1.1,1.1,0,0,1,1.14.838l.255.905a8.765,8.765,0,0,1,.81-.8,5.176,5.176,0,0,1,.907-.63,4.861,4.861,0,0,1,1.051-.42,4.694,4.694,0,0,1,1.237-.154,3.478,3.478,0,0,1,2.332.784,4.876,4.876,0,0,1,1.4,2.09,4.935,4.935,0,0,1,.952-1.324,5.109,5.109,0,0,1,1.215-.887,5.569,5.569,0,0,1,1.381-.5,6.591,6.591,0,0,1,1.447-.163,6.16,6.16,0,0,1,2.37.428,4.5,4.5,0,0,1,1.732,1.243,5.484,5.484,0,0,1,1.058,2,9.253,9.253,0,0,1,.36,2.689v10.638h-4.65V442.387q0-2.6-2.07-2.6a2.049,2.049,0,0,0-1.568.669,2.733,2.733,0,0,0-.622,1.93v10.638h-4.65V442.387a3.013,3.013,0,0,0-.525-2.018,1.972,1.972,0,0,0-1.545-.581,2.44,2.44,0,0,0-1.192.307,4.33,4.33,0,0,0-1.058.822v12.108Z" transform="translate(-221.453 -436.025)"></path>
				</svg>
			</div>
			<div>Home</div>
		</a>
	</li>
		<li class="active">
		<a href="https://www.moneycontrol.com/stocksmarketsindia/" title="Markets" onclick="GAEventTracker( 'Navigation', 'Bottom', 'Markets' );">
			<div class="wap_ic_markets">
				<svg xmlns="https://www.w3.org/2000/svg" width="21.599" height="18.648" viewBox="0 0 21.599 18.648">
					<g id="Group_1" data-name="Group 1" transform="translate(-326.403 -41.222)" opacity="0.5">
						<line id="Line_1" data-name="Line 1" x2="20.599" transform="translate(326.903 59.37)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></line>
						<path id="Path_1" data-name="Path 1" d="M328.611,59.73h2.754v5.818h-2.754V59.73Z" transform="translate(-0.59 -6.219)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></path>
						<path id="Path_2" data-name="Path 2" d="M336.558,51.793h2.754V62.808h-2.754V51.793Z" transform="translate(-3.334 -3.478)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></path>
						<path id="Path_3" data-name="Path 3" d="M344.506,58.88h2.754v6.375h-2.754V58.88Z" transform="translate(-6.079 -5.925)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></path>
						<path id="Path_4" data-name="Path 4" d="M352.453,55.2h2.754v8.788h-2.754V55.2Z" transform="translate(-8.823 -4.652)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></path>
						<path id="Path_5" data-name="Path 5" d="M329.876,49.792a1.588,1.588,0,1,0,1.588,1.588,1.588,1.588,0,0,0-1.588-1.588Z" transform="translate(-0.478 -2.787)" fill="none" stroke="#333" stroke-miterlimit="22.926" stroke-width="1"></path>
						<path id="Path_6" data-name="Path 6" d="M337.823,41.722a1.588,1.588,0,1,0,1.588,1.588,1.589,1.589,0,0,0-1.588-1.588Z" transform="translate(-3.223)" fill="none" stroke="#333" stroke-miterlimit="22.926" stroke-width="1"></path>
						<path id="Path_7" data-name="Path 7" d="M345.771,48.94a1.588,1.588,0,1,0,1.588,1.588,1.589,1.589,0,0,0-1.588-1.588Z" transform="translate(-5.967 -2.493)" fill="none" stroke="#333" stroke-miterlimit="22.926" stroke-width="1"></path>
						<path id="Path_8" data-name="Path 8" d="M353.718,45.269a1.588,1.588,0,1,0,1.588,1.588,1.588,1.588,0,0,0-1.588-1.588Z" transform="translate(-8.711 -1.225)" fill="none" stroke="#333" stroke-miterlimit="22.926" stroke-width="1"></path>
						<line id="Line_2" data-name="Line 2" y1="2.423" x2="2.455" transform="translate(330.819 44.728)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></line>
						<line id="Line_3" data-name="Line 3" x2="2.478" y2="2.268" transform="translate(336.035 44.608)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></line>
						<line id="Line_4" data-name="Line 4" y1="0.908" x2="1.867" transform="translate(341.368 46.451)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></line>
					</g>
				</svg>
			</div>
			<div class="wap_ic_markets_active">
				<svg xmlns="https://www.w3.org/2000/svg" width="21.599" height="18.148" viewBox="0 0 21.599 18.148">
					<g id="Group_1" data-name="Group 1" transform="translate(-326.403 -41.722)" opacity="0.999">
						<line id="Line_1" data-name="Line 1" x2="20.599" transform="translate(326.903 59.37)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></line>
						<path id="Path_1" data-name="Path 1" d="M328.611,59.73h2.754v5.818h-2.754V59.73Z" transform="translate(-0.59 -6.219)"></path>
						<path id="Path_2" data-name="Path 2" d="M336.558,51.793h2.754V62.808h-2.754V51.793Z" transform="translate(-3.334 -3.478)"></path>
						<path id="Path_3" data-name="Path 3" d="M344.506,58.88h2.754v6.375h-2.754V58.88Z" transform="translate(-6.079 -5.925)"></path>
						<path id="Path_4" data-name="Path 4" d="M352.453,55.2h2.754v8.788h-2.754V55.2Z" transform="translate(-8.823 -4.652)"></path>
						<path id="Path_5" data-name="Path 5" d="M329.876,49.792a1.588,1.588,0,1,0,1.588,1.588,1.588,1.588,0,0,0-1.588-1.588Z" transform="translate(-0.478 -2.787)"></path>
						<path id="Path_6" data-name="Path 6" d="M337.823,41.722a1.588,1.588,0,1,0,1.588,1.588,1.589,1.589,0,0,0-1.588-1.588Z" transform="translate(-3.223)"></path>
						<path id="Path_7" data-name="Path 7" d="M345.771,48.94a1.588,1.588,0,1,0,1.588,1.588,1.589,1.589,0,0,0-1.588-1.588Z" transform="translate(-5.967 -2.493)"></path>
						<path id="Path_8" data-name="Path 8" d="M353.718,45.269a1.588,1.588,0,1,0,1.588,1.588,1.588,1.588,0,0,0-1.588-1.588Z" transform="translate(-8.711 -1.225)"></path>
						<line id="Line_2" data-name="Line 2" y1="2.423" x2="2.455" transform="translate(330.819 44.728)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></line>
						<line id="Line_3" data-name="Line 3" x2="2.478" y2="2.268" transform="translate(336.035 44.608)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></line>
						<line id="Line_4" data-name="Line 4" y1="0.908" x2="1.867" transform="translate(341.368 46.451)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></line>
					</g>
				</svg>
			</div>
			<div>Markets</div>
		</a>
	</li>
	<li class="pro_circle">
		<a href="https://www.moneycontrol.com/promos/pro.php" title="Be a Pro" onclick="GAEventTracker( 'Navigation', 'Bottom', 'Be a Pro' );">
			<div class="bea">Be a</div> <div class="Pro">Pro</div>
		</a>
	</li>
		<li class="">
		<a href="https://www.moneycontrol.com/news/" title="News" onclick="GAEventTracker( 'Navigation', 'Bottom', 'News' );">
			<div class="wap_ic_news">
				<svg xmlns="https://www.w3.org/2000/svg" width="22.881" height="18.65" viewBox="0 0 22.881 18.65">
					<g id="Group_3" data-name="Group 3" transform="translate(-184.673 -628.809)" opacity="0.5">
						<line id="Line_10" data-name="Line 10" x2="12.468" transform="translate(191.856 632.714)" fill="none" stroke="#333" stroke-width="1"></line>
						<line id="Line_11" data-name="Line 11" x2="12.468" transform="translate(191.856 635.351)" fill="none" stroke="#333" stroke-width="1"></line>
						<line id="Line_12" data-name="Line 12" x2="5.421" transform="translate(191.856 638.029)" fill="none" stroke="#333" stroke-width="1"></line>
						<line id="Line_13" data-name="Line 13" x2="5.421" transform="translate(191.856 640.707)" fill="none" stroke="#333" stroke-width="1"></line>
						<line id="Line_14" data-name="Line 14" x2="5.421" transform="translate(191.856 643.385)" fill="none" stroke="#333" stroke-width="1"></line>
						<g id="Rectangle_5" data-name="Rectangle 5" transform="translate(199 637.855)" fill="none" stroke="#333" stroke-width="1">
						  <rect width="6" height="6" stroke="none"></rect>
						  <rect x="0.5" y="0.5" width="5" height="5" fill="none"></rect>
						</g>
						<path id="Path_14" data-name="Path 14" d="M104.174,557.118v11.521a2.075,2.075,0,0,0,2.052,2.229,2.113,2.113,0,0,0,2.087-2.229V553.218h17.741v17.65H106.226" transform="translate(81 76.091)" fill="none" stroke="#333" stroke-width="1"></path>
					</g>
				</svg>
			</div>
			<div class="wap_ic_news_active">
				<svg xmlns="https://www.w3.org/2000/svg" width="22.881" height="18.65" viewBox="0 0 22.881 18.65">
					<g id="Group_231" data-name="Group 231" transform="translate(-188.499 -628.809)">
						<rect id="Rectangle_40" data-name="Rectangle 40" width="18" height="18" transform="translate(193 629)"></rect>
						<line id="Line_10" data-name="Line 10" x2="12.468" transform="translate(195.682 632.714)" fill="none" stroke="#fff" stroke-width="1"></line>
						<line id="Line_11" data-name="Line 11" x2="12.468" transform="translate(195.682 635.351)" fill="none" stroke="#fff" stroke-width="1"></line>
						<line id="Line_12" data-name="Line 12" x2="5.421" transform="translate(195.682 638.029)" fill="none" stroke="#fff" stroke-width="1"></line>
						<line id="Line_13" data-name="Line 13" x2="5.421" transform="translate(195.682 640.707)" fill="none" stroke="#fff" stroke-width="1"></line>
						<line id="Line_14" data-name="Line 14" x2="5.421" transform="translate(195.682 643.385)" fill="none" stroke="#fff" stroke-width="1"></line>
						<rect id="Rectangle_5" data-name="Rectangle 5" width="6" height="6" transform="translate(202.826 637.855)" fill="#fff"></rect>
						<path id="Path_14" data-name="Path 14" d="M104.174,557.118v11.521a2.075,2.075,0,0,0,2.052,2.229,2.113,2.113,0,0,0,2.087-2.229V553.218h17.741v17.65H106.226" transform="translate(84.826 76.091)" fill="none" stroke="#000" stroke-width="1"></path>
					</g>
				</svg>
			</div>
			<div>News</div>
		</a>
	</li>
		<li class="">
		<a href="https://m.moneycontrol.com/portfolio.php?type=today" title="Portfolio" onclick="GAEventTracker( 'Navigation', 'Bottom', 'Portfolio' );">
			<div class="wap_ic_portfolio">
				<svg xmlns="https://www.w3.org/2000/svg" width="20" height="19.567" viewBox="0 0 20 19.567">
					<g id="Group_2" data-name="Group 2" transform="translate(-261.704 -295.118)" opacity="0.5">
						<path id="Path_9" data-name="Path 9" d="M276.572,312.986a8.428,8.428,0,1,1-5.943-14.406v8.346h0v.083l5.94,5.978Z" transform="translate(0 -1.25)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></path>
						<path id="Path_10" data-name="Path 10" d="M288.927,312.746v.083a8.4,8.4,0,0,1-2.487,5.978l-5.94-5.978v-.083Z" transform="translate(-7.724 -7.231)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></path>
						<path id="Path_11" data-name="Path 11" d="M279.393,295.618a8.428,8.428,0,0,1,8.427,8.345h-8.43v-8.345Z" transform="translate(-7.256)" fill="none" stroke="#333" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"></path>
					</g>
				</svg>
			</div>
			<div class="wap_ic_portfolio_active">
				<svg xmlns="https://www.w3.org/2000/svg" width="19" height="18.567" viewBox="0 0 19 18.567">
					<g id="Group_2" data-name="Group 2" transform="translate(-262.204 -295.618)">
						<path id="Path_9" data-name="Path 9" d="M276.572,312.986a8.428,8.428,0,1,1-5.943-14.406v8.346h0v.083l5.94,5.978Z" transform="translate(0 -1.25)"></path>
						<path id="Path_10" data-name="Path 10" d="M288.927,312.746v.083a8.4,8.4,0,0,1-2.487,5.978l-5.94-5.978v-.083Z" transform="translate(-7.724 -7.231)"></path>
						<path id="Path_11" data-name="Path 11" d="M279.393,295.618a8.428,8.428,0,0,1,8.427,8.345h-8.43v-8.345Z" transform="translate(-7.256)"></path>
					</g>
				</svg>
			</div>
			<div>Portfolio</div>
		</a>
	</li>
</ul>

<script type="text/javascript">
	$(document).ready( function( e ) {
		if( $( '.footer_navigation_list' ).length ) {

			if( $(window).width() < 767 ) {

				var mcpro = readCookieFooter( 'mcpro' );
				if( $( '.pro_circle' ).length ) {
					if( readCookieFooter( 'token-normal' ) != '' ) {	/* For Logged-in Users */
						if( mcpro == '1' ) {	/* For MC PRO Users */

							$( '.footer_navigation_list .pro_circle .bea' ).hide();

							$( '.footer_navigation_list .pro_circle a' ).attr({
								href: 'https://www.moneycontrol.com/pro-top-stories',
								title: 'Pro',
								onclick: "GAEventTracker( 'Navigation', 'Bottom', 'Pro' );"
							});

						} else {	/* For Non-MC PRO Users */

							$( '.footer_navigation_list .pro_circle a' ).attr({
								href: 'https://www.moneycontrol.com/pro-top-stories',
								title: 'Be a Pro',
								onclick: "GAEventTracker( 'Navigation', 'Bottom', 'Be a Pro' );"
							});
						}
					} else {	/* For Non-Log in Users */

						$( '.footer_navigation_list .pro_circle a' ).attr({
							href: 'javascript:;',
							title: 'Be a Pro',
							class: 'linkSignIn',
							'data-toggle': 'modal',
							'data-target': '#LoginModal',
							onclick: "GAEventTracker( 'Navigation', 'Bottom', 'Be a Pro' );"
						});

					}
				}

				if( $( '#sticky-footer' ).length ) {	/* For Bottom Ads */
					$( '#sticky-footer' ).addClass( 'close_ad_div' );

					if( $( '.app_btn_container' ).length ) {	/* For News Pages */
						$( '.app_btn_container' ).css( 'bottom', '95px' );
					}
				}

				if( $( '.scroll-paginate' ).length ) {	/* For News Consumption Pages */
					/* $( '.scroll-paginate' ).addClass( 'close_ad_div' ); */

					if( $( '.app_btn_container' ).length ) {
						$( '.app_btn_container' ).css( 'bottom', '110px' );
					}
				}

				if( $( '#scroll' ).length ) {	/* For Live blog Pages */
					$( '#scroll' ).css( 'bottom', '50px' );
				}

				var lastScrollTop = 0;
				$(window).scroll( function( event ) {
					var element_top = $( '#fixedheader' ).offset().top;
					var window_scroll_top = $(this).scrollTop();

					if( element_top > 0 && window_scroll_top > 0 ) {
						var st = $(this).scrollTop();

						if( st > lastScrollTop ) {
							$( '#fixedheader' ).addClass( 'open_div' );
						} else {
							$( '#fixedheader' ).removeClass( 'open_div' );
						}
						lastScrollTop = st;
					}

				});
			}
		}
	});
</script>
<!-- End <- Bottom Menu -->

<div class="footerMobile respons_foot_mob ">
	    
    <div class="PA10  whbg">
    	<div class="fresub_title">Sections</div>
        
        <div class="footermobilink clearfix">
        <ul class="flinklist clearfix">
        	<li><a href="https://m.moneycontrol.com/" title="Home">&raquo; Home</a></li>
			           <li><a href="https://m.moneycontrol.com/mmb/" title="Forum" target="_blank" rel="noopener">&raquo; Forum</a></li>
            <li><a href="https://m.moneycontrol.com/ipo/" title="IPO">&raquo; IPO</a></li>
            <li><a href="https://m.moneycontrol.com/stocksmarketsindia/" title="Markets">&raquo; Markets</a></li>
            <li><a href="https://m.moneycontrol.com/mutualfundindia/" title="Mutual Funds">&raquo; Mutual Funds</a></li>
			<li><a href="https://www.moneycontrol.com/budget-2022/" title="Budget 2022">&raquo; Budget 2022</a></li>
			<li><a href="https://www.moneycontrol.com/news/assembly-elections/" title="Assembly Elections 2022">&raquo; Assembly Elections 2022</a></li>
						<li><a href="https://www.moneycontrol.com/news/tags/coronavirus.html" title="Coronavirus">&raquo; Coronavirus</a></li>
            <li><a href="https://m.moneycontrol.com/commodity/" title="Commodities">&raquo; Commodities</a></li>
            <li><a href="https://m.moneycontrol.com/property/real-assets.html" title="Real Asset">&raquo; Real Asset</a></li>
            <li><a href="https://www.moneycontrol.com/news/" title="News">&raquo; News</a></li>
            <li><a href="https://m.moneycontrol.com/mccode/currencies/" title="Currencies">&raquo; Currencies</a></li>
						<li><a href="https://m.moneycontrol.com/india/bestportfoliomanager/investment-tool" title="Portfolio">&raquo; Portfolio</a></li>
            <li><a href="https://m.moneycontrol.com/fixed-income/" title="Fixed Income">&raquo; Fixed Income</a></li>
            <li><a href="https://m.moneycontrol.com/portfolio_demo/stock_watchlist.php" title="Watchlist">&raquo; Watchlist</a></li>
            <li><a href="https://www.moneycontrol.com/real-estate-property/" title="Property">&raquo; Property</a></li>
            <li><a href="https://m.moneycontrol.com/news/business/stocks" title="Stock List">&raquo; Stock List</a></li>
            <li><a href="https://m.moneycontrol.com/" title="MF List">&raquo; MF List</a></li>
            <li><a href="https://m.moneycontrol.com/glossary/" title="Glossary">&raquo; Glossary</a></li>
                        <li><a href="https://www.moneycontrol.com/sitemap.php" title="Sitemap">&raquo; Sitemap</a></li>
            <li><a href="https://m.moneycontrol.com/tv/" title="Live TV & Shows">&raquo; Live TV & Shows</a></li>
            <li><a href="https://m.moneycontrol.com/personal-finance/" title="Personal Finance">&raquo; Personal Finance</a></li>
            <li><a href="https://m.poweryourtrade.com/" title="PowerYourTrade">&raquo; PowerYourTrade</a></li>
        </ul>
        </div>
    </div>
    
    <div class="PA10 whbg MT10">
    	<div class="clearfix brd_b PB10"> 
        	<a href="https://m.moneycontrol.com/gotomcweb.php?url=http%3A%2F%2Fwww.moneycontrol.com%2F%3Fclassic" title="Desktop Version" class="txtlonk_blue FR MT5">Desktop Version &raquo;</a>
        </div>

		<div class="PA15 brd_b">
			<div class="CTR txt14">Follow us on</div>
			<div class="CTR MT10">
				<a href="https://www.facebook.com/moneycontrol" title="Facebook" onclick="GAEventTracker( 'Footer Social', 'Facebook', window.location.href );" target="_blank" rel="noopener" class="ic_fbfter" style="text-indent:-9999px;">Facebook</a> 
				<a href="https://twitter.com/moneycontrolcom" title="Twitter" onclick="GAEventTracker( 'Footer Social', 'Twitter', window.location.href );" target="_blank" rel="noopener" class="ic_twtr" style="text-indent:-9999px;">Twitter</a> 
				 
				<a href="https://www.instagram.com/moneycontrolcom/" title="Instagram" onclick="GAEventTracker( 'Footer Social', 'Instagram', window.location.href );" target="_blank" rel="noopener" class="ic_instagram_mn" style="text-indent:-9999px;">Instagram</a> 
				<a href="https://t.me/moneycontrolcom" title="Telegram" onclick="GAEventTracker( 'Footer Social', 'Teglegram', window.location.href );" target="_blank" rel="noopener" class="ic_tg" style="text-indent:-9999px;">Teglegram</a>
				<a href="https://jionews.com/home/articles/moneycontrol/58" title="JioNews" onclick="GAEventTracker( 'Footer Social', 'JioNews', window.location.href );" target="_blank" rel="noopener" class="ic_jio_news" style="text-indent:-9999px;">Jio News</a>
			</div>
		</div>

		<div class="PA10 brd_b PB10">
			<div class="CTR txt14">Available On</div>
			<div class="CTR MT10">
				<a href="https://play.google.com/store/apps/details?id=com.divum.MoneyControl&referrer=utm_source%3DWebAppsPage%26utm_medium%3DInstallButton" title="Download from Google Play" target="_blank" rel="noopener" class="ic_fapgpl" style="text-indent:-9999px;">Download from Google Play</a>
				<a href="https://itunes.apple.com/app/apple-store/id408654600?pt=433541&ct=WebAppsPage_Install&mt=8" title="Download from App Stoer" target="_blank" rel="noopener" class="ic_fapapstr" style="text-indent:-9999px;">Download from App Stoer</a>
				<a href="https://apps.microsoft.com/windows/en-in/app/a4555fed-7225-4159-8569-8cfac5e412e0" title="Download from Windows Phone" target="_blank" rel="noopener" class="ic_fapwin" style="text-indent:-9999px;">Download from Windows Phone</a>
			</div>
		</div>

					<div class="PA10 CTR">
								<a target="_blank" title="ISO 27001 - BSI Assurance Mark" href="https://images.moneycontrol.com/pdffiles/IS-739420-I.pdf" rel="noopener">
					<img width="100" height="51" src="https://images.moneycontrol.com/images/common/headfoot/bsi-cert2b.png" alt="ISO 27001 - BSI Assurance Mark" title="ISO 27001 - BSI Assurance Mark" />
				</a>
			</div>
		
    </div>
	<div class="ftCopy CTR">
		<div class="flastLInk MT10 brd_b PB10 "> 
			<a href="https://m.moneycontrol.com/cdata/disclaim.php" title="Disclaimer">Disclaimer</a> | 
			<a href="https://m.moneycontrol.com/cdata/termsofuse.php" title="Terms & Conditions">Terms & Conditions</a>  | 
			<a href="https://www.moneycontrol.com/cdata/privacypolicy.php" title="Privacy Policy">Privacy Policy</a> | 
			<a href="https://www.moneycontrol.com/cdata/gdpr_cookiepolicy.php" title="Cookie Policy">Cookie Policy</a> | 
			<a href="https://www.moneycontrol.com/faqs/" title="FAQs"> FAQs</a> | 
						<a href="https://www.moneycontrol.com/sitemap.php" title="Sitemap"> Sitemap</a> | 
						<a href="https://www.moneycontrol.com/cdata/contact.php?classic=true" title="Contact Us">Contact Us</a> | 
			<a href="https://www.moneycontrol.com/advertise-on-moneycontrol.html" title="Advertise with Us">Advertise with Us</a>
		</div>
		<div class="flastLInk MT10 brd_b PB10 "> 
			<b>Network 18 Sites: </b>
			<a href="https://www.news18.com/" title="News18" rel="noopener" target="_blank">News18</a> | 
			<a href="https://www.firstpost.com/" title="Firstpost" rel="noopener" target="_blank">Firstpost</a> | 
			<a href="https://www.cnbctv18.com/" title="CNBC TV18" rel="noopener" target="_blank">CNBC TV18</a> | 
			<a href="https://www.in.com/" title="In.com" target="_blank" rel="noopener">In.com</a> | 
			<a href="https://www.news18.com/cricketnext/" title="Cricketnext" target="_blank" rel="noopener">Cricketnext</a> | 
			<a href="https://overdrive.in/" title="Overdrive" target="_blank" rel="noopener">Overdrive</a> |
			<a href="https://www.topperlearning.com/" title="Topper Learning" target="_blank" rel="noopener">Topper Learning</a>
		</div>
		<p class="copyright MT10">
			<span class="copymmv"> Copyright &copy; e-Eighteen.com Ltd</span> All rights resderved. Reproduction of news articles, photos, videos or any other content in whole or in part in any form or medium without express writtern permission of moneycontrol.com is prohibited.
		</p>
	</div>
</div>
<!-- Moneycontrol Footer end here -->
<!-- Arjun Tracking - Start -->
<!-- End - Arjun Tracking --><!-- Gutter Slot -> Start -->
<!-- End <- Gutter Slot -->

<!-- SEO Event Tracking -> Start  -->
<script type="text/javascript">
  $(document).ready(function() {
    $( "a" ).click(function() {
      var href = $.trim( $(this).attr( 'href' ) );

      /* Module = MoneySavers -> Start */
      if( href.indexOf( "moneysavers" ) >= 0 ) {
        if( $(this).parent().parent().hasClass( 'headbotmmenus1' ) ) {
          ga( 'send', 'event', 'MC_WEB', 'Web_Navigation_Link', 'WEB_NAV_RMF_MoneySavers' );
        } else if( $(this).parent().parent().hasClass( 'splist' ) ) {
          ga( 'send', 'event', 'MC_WEB', 'Special_Section', 'WEB_Special_MoneySavers' );
        }
      }
      /* End <- Module = MoneySavers */

    });
  });
</script>
<!-- End <- SEO Event Tracking -->
<script type="text/javascript">
	$(document).ready(function() {
		/* Hide Close Add div for MC Pro Users */
		if( $( '.ad_google_shhide' ).length ) {
			var is_dfp_ads_visible = $.trim( $( '.is_dfp_ads_visible' ).val() );
			if( is_dfp_ads_visible == false || is_dfp_ads_visible === 'false' ) {	/* is_dfp_ads_visible is declared while initialization of DFP */
				$( '.closeadpr' ).css( 'display', 'none' );
			}
		}
	});

	</script>

		 <!-- IO analytic implementation -> Start -->
			<script async src="https://cdn.onthe.io/io.js/8qckTULJP2pt"></script>
			<script>
				var is_user_logged = '0';
				if( readCookieFooter( 'token-normal' ) != '' ) {
					is_user_logged = '1';
				}

				window._io_config = window._io_config || {};
				window._io_config["0.2.0"] = window._io_config["0.2.0"] || [];
				window._io_config["0.2.0"].push({
					page_url: window.location.href ,
					page_title: document.title,
					page_type: "default",
					page_language: "en",
					user_status: is_user_logged //if user logged in/ or not send 1/0
				});
			</script>
		<!-- End <- IO analytic implementation --> 

<!-- Tradenow popup -> Start -->
<link rel="stylesheet" href="https://stat2.moneycontrol.com/mccss/tradenow/tradenow.css?v=1.12" type="text/css">
<script type="text/javascript" src="https://stat2.moneycontrol.com/mcjs/tradenow/tradenow_revamp.js?v=4"></script>
<!-- End <- Tradenow popup -->


<!-- Login signup popup -> Start -->
	<input type="hidden" name="ip" value="" readonly="readonly" />
<script src="https://accounts.moneycontrol.com/assets/js/mclogin/popupinclude.js?v=20210518"></script>
<div id="mcloginpopup"></div><!-- End <- Login signup popup -->

<!-- Verloop Chatbot -> Start -->
			<style>
			.verloop-button{display:none;}
			@media only screen and (max-width: 980px){
				.verloop-button { bottom: 65px !important; }
			}
		</style>
		<script type="text/javascript">
		function getVerloopCookie( cname ) {
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for( var i = 0; i < ca.length; i++ ) {
				var c = ca[i];
				while( c.charAt(0) == ' ' ) {
					c = c.substring( 1 );
				}
				if( c.indexOf( name ) == 0 ) {
					return c.substring( name.length, c.length );
				}
			}
			return "";
		}

		(
			function( w, d, s, u ) {
				w.Verloop = function(c) { w.Verloop._.push(c) }; 
				w.Verloop._ = []; 
				w.Verloop.url = u;
				var h = d.getElementsByTagName(s)[0], j = d.createElement(s); j.async = true;
				j.src = 'https://moneycontrol.verloop.io/livechat/script.min.js';
				h.parentNode.insertBefore( j, h );
				/* Verloop( function() { this.setRecipe( "pz44nQqMye8i9x4Nt" ); }); */
			}
		)
		( window, document, 'script', 'https://moneycontrol.verloop.io/livechat' );

		function openVerloopWidget() {
			let verloop_user_token = getVerloopCookie( 'token-normal' );	/* Get Cookie Value */

			/* Checks for Cookie is exists OR not? */
			if( verloop_user_token == undefined || verloop_user_token == '' ) {
				window.Verloop( function() { 
					this.setWidgetColor( '#0065a1' );
					this.setRecipe( "Lc5LCz4k2mFxc62Xc" );  //  sets the recipe when chat is initiated
					this.openWidget(); //  opens the chat widget
				});
			} else {

				let ajax_link = 'https://www.moneycontrol.com/verloop-apis/overall/user-details/?classic=true&token=' + verloop_user_token;
				let opts = {
					method: 'GET',
					headers: {}
				};
				fetch( ajax_link, opts ).then( function ( response ) {
					return response.json();
				})
				.then( function ( json_obj ) {
					if( json_obj.message == 'success' ) {
						window.Verloop( function() {
							this.setWidgetColor( '#0065a1' );
							this.setUserId( json_obj.data.user_email );
							this.setCustomField( "token", verloop_user_token, { scope: "user" } );
							this.setRecipe( "Lc5LCz4k2mFxc62Xc" );  //  sets the recipe when chat is initiated
							this.openWidget(); //  opens the chat widget
						});
					} else {
						window.Verloop( function() { 
							this.setWidgetColor( '#0065a1' );
							this.setRecipe( "Lc5LCz4k2mFxc62Xc" );  //  sets the recipe when chat is initiated
							this.openWidget(); //  opens the chat widget
						});
					}
				});
			}
		}

		let verloop_user_token = getVerloopCookie( 'token-normal' );	/* Get Cookie Value */
		/* Checks for Cookie is exists OR not? */
		if( verloop_user_token == undefined || verloop_user_token == '' ) {
			window.Verloop(function () {
				this.setWidgetColor( '#0065a1' );
				this.setUserId();
				this.setUserParams( { name: 'userName', } );
			});
		} else {
			window.Verloop(function () {
				this.setWidgetColor( '#0065a1' );
				this.setCustomField( "token", verloop_user_token, { scope: "user" } );
			});
		}
	</script>
<!-- End <- Verloop Chatbot --><!-- Clevertap Script -> Start -->
	<script key="cleverTap" type="text/javascript" >
		let clevertap = { event: [], profile: [], region: "in1", account: [], onUserLogin: [], notifications: [], privacy: [] };
		clevertap.account.push({ id: "86Z-5ZR-RK6Z" });	/* TEST-9RZ-67K-Z46Z */
		clevertap.privacy.push({ optOut: false });
		clevertap.privacy.push({ useIP: false });
		(
			function () {
				let wzrk = document.createElement( "script" );
				wzrk.type = "text/javascript";
				wzrk.async = true;
				wzrk.src = ( "https:" == document.location.protocol ? "https://d2r1yp2w7bby2u.cloudfront.net" : "http://static.clevertap.com" ) + "/js/a.js";
				let s = document.getElementsByTagName( "script" )[0];
				s.parentNode.insertBefore( wzrk, s );
			}
		)();
		clevertap.notifications.push(
			{
				titleText : "Would you like to receive Push Notifications?",
				bodyText : "We promise to only send you relevant content and give you updates on your transactions",
				okButtonText : "Allow",
				rejectButtonText : "No thanks",
				okButtonColor : "#005493",
				/*
				askAgainTimeInSeconds : 5,
				skipDialog : true,
				*/
				serviceWorkerPath : "https://www.moneycontrol.com/news/js/clevertap_sw.js?v=0.1"
			}
		);
	</script>
<!-- End <- Clevertap Script --><!-- Check Ad Blocker -> Start -->
<script>
	var IS_VISIBLE_WEB_BLOCKER;
</script>
<script type="text/javascript" src="https://stat2.moneycontrol.com/mcjs/ads.js?vss"></script>
<script>
$(window).load(function(e) {
	var width = window.innerWidth || document.documentElement.clientWidth;

	if( IS_VISIBLE_WEB_BLOCKER != undefined ) {
		if( !$.cookie( "WEBADBLOCKER_REPORT" ) ) {
			$.cookie( "WEBADBLOCKER_REPORT", "Active", { expires: 30, path: "/", domain: ".moneycontrol.com" } );

			if( width >= 768 ) {	/* Runs Only for WEB */
				$( "body" ).append( '<img src="https://www.moneycontrol.com/monitoring/mc_process_build.php?platform=1&type=2" style="display:none !important;" width="0" height="0" />' );
			} else {	/* Runs Only for WAP */
				$( "body" ).append( '<img src="https://www.moneycontrol.com/monitoring/mc_process_build.php?platform=2&type=2" style="display:none !important;" width="0" height="0" />' );
			}
		}
	} else {
		if( !$.cookie( "WEBADBLOCKER" ) ) {
			$.cookie( "WEBADBLOCKER", "Active", { expires: 30, path: "/", domain: ".moneycontrol.com" } );

			if( $.cookie( "mcpro" ) != undefined && $.cookie( "mcpro" ) == 1 ) {
				$( "body" ).append( '<img src="https://www.moneycontrol.com/mccode/common/moneycontrol_mcpro.php" style="display:none !important;" width="0" height="0" />' );
			} else {
				$( "body" ).append( '<img src="https://www.moneycontrol.com/mccode/common/moneycontrol_non_mcpro.php" style="display:none !important;" width="0" height="0" />' );
			}
		}

		/* Generate Counter Report */
		if( !$.cookie( "WEBADBLOCKER_REPORT" ) ) {
			$.cookie( "WEBADBLOCKER_REPORT", "Active", { expires: 30, path: "/", domain: ".moneycontrol.com" } );

			if( $.cookie( "mcpro" ) != undefined && $.cookie( "mcpro" ) == 1 ) {
				if( width >= 768 ) {	/* Runs Only for WEB */
					$( "body" ).append( '<img src="https://www.moneycontrol.com/monitoring/mc_process_build.php?platform=1&type=3" style="display:none !important;" width="0" height="0" />' );
				} else {	/* Runs Only for WAP */
					$( "body" ).append( '<img src="https://www.moneycontrol.com/monitoring/mc_process_build.php?platform=2&type=3" style="display:none !important;" width="0" height="0" />' );
				}
			} else {
				if( width >= 768 ) {	/* Runs Only for WEB */
					$( "body" ).append( '<img src="https://www.moneycontrol.com/monitoring/mc_process_build.php?platform=1&type=1" style="display:none !important;" width="0" height="0" />' );
				} else {	/* Runs Only for WAP */
					$( "body" ).append( '<img src="https://www.moneycontrol.com/monitoring/mc_process_build.php?platform=2&type=1" style="display:none !important;" width="0" height="0" />' );
				}
			}
		}
	}
});
</script>
<!-- End <- Check Ad Blocker --><!-- End < - Moneycontrol Common Footer -->